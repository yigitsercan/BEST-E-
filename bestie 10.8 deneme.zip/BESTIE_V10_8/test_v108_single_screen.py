"""Regression: /offline inline application script must not be blocked by CSP."""
import asyncio
import base64
import hashlib
import re
from pathlib import Path

import httpx
from server import app


async def test():
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url='http://testserver') as client:
        page = await client.get('/offline')
        assert page.status_code == 200
        assert 'id="root"' in page.text
        scripts = re.findall(r'<script>(.*?)</script>', page.text, re.DOTALL)
        assert len(scripts) == 1, 'Offline app must have a single inline script'
        expected = "'sha256-" + base64.b64encode(hashlib.sha256(scripts[0].encode()).digest()).decode() + "'"
        csp = page.headers['Content-Security-Policy']
        assert expected in csp, 'Browser would refuse to execute offline game JavaScript'
        assert "'unsafe-inline'" not in csp.split('script-src', 1)[1].split(';', 1)[0], 'Do not disable script CSP'
        home = await client.get('/')
        assert home.status_code == 200
        assert expected not in home.headers['Content-Security-Policy'], 'Offline exception must not affect main game'
        direct = await client.get('/static/Bestie_V10_Cevrimdisi.html')
        assert direct.status_code == 200
        assert expected in direct.headers['Content-Security-Policy']
        print('PASS: /offline, direct static page, exact inline script CSP hash, main page restriction')


if __name__ == '__main__':
    asyncio.run(test())
