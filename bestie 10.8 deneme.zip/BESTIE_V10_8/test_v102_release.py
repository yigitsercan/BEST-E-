"""Release hardening smoke checks using isolated SQLite and FastAPI TestClient."""
import os, tempfile
from pathlib import Path
with tempfile.TemporaryDirectory() as d:
    os.environ['BESTIE_DB_PATH']=str(Path(d)/'test.sqlite3')
    from fastapi.testclient import TestClient
    import server
    with TestClient(server.app) as client:
        response=client.get('/')
        assert response.status_code==200
        assert response.headers['x-content-type-options']=='nosniff'
        assert response.headers['x-frame-options']=='DENY'
        assert "object-src 'none'" in response.headers['content-security-policy']
        assert 'strict-transport-security' not in response.headers
        response=client.get('/health')
        assert response.status_code==200 and response.headers['cache-control']=='no-store'
        response=client.get('/api/admin/reports')
        assert response.status_code in (401,503)
        assert response.headers['cache-control']=='no-store'
        response=client.get('/',headers={'x-forwarded-proto':'https'})
        assert 'max-age=' in response.headers['strict-transport-security']
    print('PASS V10.2: security headers, no-cache sensitive paths, admin fails closed, local HTTP HSTS off')
