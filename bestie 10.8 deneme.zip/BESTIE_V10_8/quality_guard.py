"""Data checks and conservative repair for BESTIE? trivia cards.

This script detects direct answer disclosure in hints, invalid answer options,
repeated answer entities and missing original image assets. It does not claim
that human factual verification or unique question authoring has been done.
"""
import json, re, collections, argparse
from pathlib import Path

ROOT=Path(__file__).resolve().parent
DATA=ROOT/'data/questions.json'
SAFE_CLUE={
 'footballer':'Profesyonel futbol kariyerinde uluslararası düzeyde tanınmıştır.',
 'footballclub':'Ulusal futbol müsabakalarında yer alan köklü kulüplerden biridir.',
 'basketballer':'Profesyonel basketbol kariyeriyle tanınan bir sporcudur.',
 'basketballclub':'Profesyonel basketbol müsabakalarında mücadele eden bir takımdır.',
 'volleyballer':'Üst düzey voleybol müsabakalarında yer alan bir sporcudur.',
 'volleyballclub':'Profesyonel voleybol liglerinde mücadele eden kulüplerden biridir.',
 'history':'Tarihsel etkileri farklı kaynaklarda ele alınan bir olay ya da dönemdir.',
 'geography':'Dünya coğrafyası hakkında bilgi gerektiren bir konudur.',
 'movie':'Sinema veya televizyon dünyasında tanınan bir yapımdır.',
 'music':'Müzik dünyasında iz bırakmış bir isim veya eserdir.',
}

def leaked(answer, hint):
    a=answer.strip().casefold()
    # Match entire words/phrases; avoid substring false positives.
    return bool(a and re.search(r'(?<!\w)'+re.escape(a)+r'(?!\w)',hint.casefold()))

def scan(data):
    report={'categories':{},'issues':collections.Counter(),'examples':collections.defaultdict(list)}
    for category,qs in data['trivia'].items():
        seen_ids=set(); entities=collections.Counter(); hints=collections.Counter()
        for q in qs:
            entities[q.get('entity','').casefold()]+=1
            hints[tuple(q.get('hints',[]))]+=1
            problems=[]
            opts=q.get('options',[])
            if len(opts)!=4 or len(set(x.casefold() for x in opts))!=4 or q.get('answer') not in opts:problems.append('invalid_choices')
            if len(q.get('hints',[]))!=3:problems.append('invalid_hint_count')
            for i,h in enumerate(q.get('hints',[])):
                if leaked(q.get('answer',''),h):problems.append('answer_disclosed_in_hint_'+str(i+1))
            if q['id'] in seen_ids:problems.append('duplicate_id')
            seen_ids.add(q['id'])
            if q.get('image') and not (ROOT/q['image'].lstrip('/')).exists():problems.append('missing_image')
            for issue in problems:
                report['issues'][issue]+=1
                if len(report['examples'][issue])<8:report['examples'][issue].append(q['id'])
        report['categories'][category]={'cards':len(qs),'distinct_answers':len(entities), 'repeated_answer_cards':sum(n-1 for n in entities.values()),'duplicate_hint_cards':sum(n-1 for n in hints.values()),'images':sum(bool(q.get('image')) for q in qs)}
    report['issues']=dict(report['issues']);report['examples']=dict(report['examples'])
    report['totals']={'cards':sum(c['cards'] for c in report['categories'].values()),'images':sum(c['images'] for c in report['categories'].values()),'unique_answer_category_pairs':sum(c['distinct_answers'] for c in report['categories'].values())}
    return report

def repair(data):
    count=0
    for category,qs in data['trivia'].items():
        for q in qs:
            for i,h in enumerate(q['hints']):
                if not leaked(q['answer'],h):continue
                # Preserve location information if it can be retained without naming the answer.
                location=h.split(',')[0].strip().rstrip('.')
                if category.endswith('club') and ',' in h and location and not leaked(q['answer'],location) and len(location)<45:
                    q['hints'][i]=location+' merkezli bir spor kulübüdür.'
                else:
                    q['hints'][i]=SAFE_CLUE[category]
                q['editorial_status']='otomatik ipucu düzeltildi - uzman editör onayı gerekli'
                count+=1
    return count

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--fix-leaks',action='store_true');a=p.parse_args()
    data=json.loads(DATA.read_text('utf-8'))
    before=scan(data)
    if a.fix_leaks:
        n=repair(data)
        DATA.write_text(json.dumps(data,ensure_ascii=False,separators=(',',':')),'utf-8')
        print('Düzeltilen doğrudan cevap ifşası:',n)
    after=scan(data)
    (ROOT/'KALITE_KONTROL_V9_2.json').write_text(json.dumps({'before':before,'after':after,'note':'Bu otomatik yapısal kontroldür; olgusal doğruluk ve ipucu özgünlüğü insan tarafından ayrıca doğrulanmalıdır.'},ensure_ascii=False,indent=2),'utf-8')
    print(json.dumps(after['issues'],ensure_ascii=False))
