@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>&1
if %errorlevel%==0 (set "PY=py -3") else (set "PY=python")
if not exist .venv\Scripts\python.exe (
  %PY% -m venv .venv || goto :failed
)
.venv\Scripts\python.exe -m pip install -r requirements.txt || goto :failed
start "" "http://127.0.0.1:8000"
.venv\Scripts\python.exe -m uvicorn server:app --host 127.0.0.1 --port 8000 --workers 1
pause
exit /b 0
:failed
echo Kurulum basarisiz. Python 3.12 veya daha yenisini kur ve tekrar dene.
pause
exit /b 1
