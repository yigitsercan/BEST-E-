"""Bestie? V7 real-time room server. Prototype: single process, in-memory rooms, SQLite KP.

Room timing, votes and trivia answers are authoritative on the server.
Never ship service credentials to the client; none are required in this prototype.
"""
import asyncio
from collections import defaultdict
from contextlib import asynccontextmanager
import json
from datetime import datetime
from zoneinfo import ZoneInfo
import os
from pathlib import Path
import random
import secrets
import hmac
import hashlib
import sqlite3
import time
import uuid
from urllib.parse import urlsplit

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException, Header, Depends, Request
from fastapi.responses import FileResponse, JSONResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles

HERE = Path(__file__).resolve().parent
DB_PATH = Path(os.environ.get('BESTIE_DB_PATH', str(HERE/'data'/'bestie.sqlite3')))
DB_PATH.parent.mkdir(parents=True, exist_ok=True)
with sqlite3.connect(DB_PATH, timeout=5) as c:
    c.execute('PRAGMA busy_timeout=5000')
    c.execute('PRAGMA journal_mode=WAL')
    c.execute('CREATE TABLE IF NOT EXISTS health_probe (probe_id INTEGER PRIMARY KEY, ts REAL NOT NULL)')
    c.execute('CREATE TABLE IF NOT EXISTS profiles (id TEXT PRIMARY KEY, secret TEXT UNIQUE NOT NULL, nickname TEXT NOT NULL, avatar TEXT NOT NULL, kp INTEGER NOT NULL DEFAULT 0)')
    c.execute('CREATE TABLE IF NOT EXISTS recovery_codes (profile_id TEXT PRIMARY KEY, code_hash TEXT UNIQUE NOT NULL, created_at REAL NOT NULL)')
    c.execute('CREATE TABLE IF NOT EXISTS active_room_snapshots (code TEXT PRIMARY KEY, data TEXT NOT NULL, updated_at REAL NOT NULL)')
    c.execute('CREATE TABLE IF NOT EXISTS moderation_audit (id TEXT PRIMARY KEY, action TEXT NOT NULL, target TEXT NOT NULL, detail TEXT NOT NULL, created_at REAL NOT NULL)')
    c.execute("CREATE TABLE IF NOT EXISTS sanction_appeals (id TEXT PRIMARY KEY, profile_id TEXT NOT NULL, text TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending', created_at REAL NOT NULL, reviewed_at REAL, review_note TEXT)")
    c.execute('CREATE TABLE IF NOT EXISTS player_reports (id TEXT PRIMARY KEY, reporter_id TEXT, target_id TEXT, room_code TEXT NOT NULL, reason TEXT NOT NULL, created_at REAL NOT NULL)')
    c.execute('CREATE INDEX IF NOT EXISTS idx_reports_reporter_time ON player_reports(reporter_id,created_at)')
    c.execute('CREATE TABLE IF NOT EXISTS player_blocks (blocker_id TEXT NOT NULL, blocked_id TEXT NOT NULL, created_at REAL NOT NULL, PRIMARY KEY (blocker_id,blocked_id))')
    c.execute('CREATE INDEX IF NOT EXISTS idx_blocks_blocked ON player_blocks(blocked_id)')
    c.execute('CREATE TABLE IF NOT EXISTS room_creation_events (profile_id TEXT NOT NULL, created_at REAL NOT NULL)')
    c.execute('CREATE INDEX IF NOT EXISTS idx_room_creation_events ON room_creation_events(profile_id,created_at)')
    c.execute('CREATE TABLE IF NOT EXISTS player_sanctions (profile_id TEXT PRIMARY KEY, reason TEXT NOT NULL, expires_at REAL NOT NULL, created_at REAL NOT NULL)')
    c.execute('CREATE TABLE IF NOT EXISTS leaderboard_optin (profile_id TEXT PRIMARY KEY, enabled INTEGER NOT NULL DEFAULT 0)')
    c.execute('CREATE TABLE IF NOT EXISTS daily_results (profile_id TEXT NOT NULL, day TEXT NOT NULL, question_index INTEGER NOT NULL, answer TEXT NOT NULL, correct INTEGER NOT NULL, PRIMARY KEY(profile_id,day,question_index))')
    c.execute('CREATE TABLE IF NOT EXISTS kp_ledger (id TEXT PRIMARY KEY,profile_id TEXT NOT NULL, room_code TEXT NOT NULL, earned INTEGER NOT NULL, created_at REAL NOT NULL)')
    c.execute('CREATE INDEX IF NOT EXISTS idx_kp_ledger_player_time ON kp_ledger(profile_id,created_at)')
    report_cols={x[1] for x in c.execute('PRAGMA table_info(player_reports)')}
    if 'status' not in report_cols:c.execute("ALTER TABLE player_reports ADD COLUMN status TEXT NOT NULL DEFAULT 'pending'")
    if 'reviewed_at' not in report_cols:c.execute('ALTER TABLE player_reports ADD COLUMN reviewed_at REAL')
    if 'review_note' not in report_cols:c.execute('ALTER TABLE player_reports ADD COLUMN review_note TEXT')
# Immutable question assets must NOT live under the mounted persistent DB volume.
# The Docker image installs these at /app/content; local development keeps /data.
QUESTIONS_PATH = Path(os.environ.get('BESTIE_QUESTIONS_PATH',
    str(HERE/'content'/'questions.json' if (HERE/'content'/'questions.json').is_file() else HERE/'data'/'questions.json')))
QUESTIONS = json.loads(QUESTIONS_PATH.read_text(encoding='utf-8'))
assert all(QUESTIONS.get(name) for name in ('kim_daha', 'trivia', 'truth_dare')), 'Eksik soru bankası'
LABELS = {
 'KIM_DAHA':'Klasik Kim Daha?', 'FLORT_RADAR':'Flört Radar', 'SOSYAL_MEDYA_DM':'Sosyal Medya & DM',
 'ARKADASLIK_SADAKAT':'Arkadaşlık & Sadakat', 'RED_GREEN_FLAG':'Red / Green Flag',
 'ILK_IZLENIM_ITIRAFLAR':'İlk İzlenim & İtiraflar', 'GRUP_ICI_EGLENCE':'Grup İçi Eğlence',
 'OKUL_UNIVERSITE':'Okul & Üniversite', 'GECE_HAYATI':'Gece Hayatı', 'GELECEK_HAYALLER':'Gelecek & Hayaller',
 'footballer':'Futbolcu', 'footballclub':'Futbol Takımı', 'basketballer':'Basketbolcu',
 'basketballclub':'Basketbol Takımı', 'volleyballer':'Voleybolcu', 'volleyballclub':'Voleybol Takımı',
 'history':'Tarih', 'geography':'Coğrafya', 'movie':'Film & Dizi', 'music':'Müzik & Sanatçı',
 'MIXED':'Karışık Meydan Okuma', 'truth_dare':'Doğruluk mu Cesaret mi?'
}
ROOMS = {}                 # keyed by six-character room code
SOCKETS = {}               # websocket -> {'profile': ..., 'room': ..., 'player': ...}
MATCH_QUEUE = defaultdict(list)
state_lock = asyncio.Lock()
ROOM_MAX_IDLE = 2 * 3600
ROUND_RESULT_SECONDS = 7
HINTS_PER_MATCH = 5  # Her oyuncu için, 10 soruluk Tahmin Et! oyunu boyunca
MAX_ACTIVE_ROOMS = int(os.environ.get('BESTIE_MAX_ACTIVE_ROOMS', '500'))
MAX_NEW_ROOMS_PER_HOUR = int(os.environ.get('BESTIE_MAX_NEW_ROOMS_PER_HOUR', '20'))
ROOM_CREATIONS = defaultdict(list)  # compatibility cache; SQLite is the persistent source
ADMIN_TOKEN = os.environ.get('BESTIE_ADMIN_TOKEN','')


def save_room(room):
    """Durable single-process room snapshot. Never serialize WebSocket objects."""
    copy = dict(room)
    copy['players'] = {pid: {k:v for k,v in player.items() if k!='ws'}
                       for pid,player in room['players'].items()}
    copy['scores'] = dict(room['scores'])
    copy['kp_earned'] = dict(room['kp_earned'])
    copy['hints_used'] = dict(room['hints_used'])
    with sqlite3.connect(DB_PATH) as db:
        db.execute('INSERT INTO active_room_snapshots(code,data,updated_at) VALUES (?,?,?) '
                   'ON CONFLICT(code) DO UPDATE SET data=excluded.data,updated_at=excluded.updated_at',
                   (room['code'],json.dumps(copy,ensure_ascii=False),time.time()))


def delete_room_snapshot(code):
    with sqlite3.connect(DB_PATH) as db:
        db.execute('DELETE FROM active_room_snapshots WHERE code=?',(code,))


def restore_rooms(now=None):
    """Recover rooms after process restart; sockets remain detached until rejoining."""
    now=time.time() if now is None else now
    restored=0
    with sqlite3.connect(DB_PATH) as db:
        rows=db.execute('SELECT code,data FROM active_room_snapshots').fetchall()
        for code,data in rows:
            try:
                room=json.loads(data)
                if not isinstance(room,dict) or room.get('code')!=code or now-float(room['touched'])>ROOM_MAX_IDLE:
                    db.execute('DELETE FROM active_room_snapshots WHERE code=?',(code,))
                    continue
                for player in room['players'].values():
                    player['ws']=None
                    player['online']=False
                for name in ('scores','kp_earned','hints_used'):
                    room[name]=defaultdict(int,room.get(name,{}))
                room['votes']=room.get('votes',{})
                room['hint_levels']=room.get('hint_levels',{})
                # A restored running round remains time-bound; normal ticker advances it.
                ROOMS[code]=room
                restored+=1
            except (ValueError,TypeError,KeyError,IndexError):
                db.execute('DELETE FROM active_room_snapshots WHERE code=?',(code,))
    return restored


def recovery_digest(code):
    # This code is randomly generated at 256 bits and never stored in plaintext.
    return hashlib.sha256(('bestie-recovery-v1:' + code).encode()).hexdigest()


def create_recovery_code(profile_id):
    code = secrets.token_urlsafe(32)
    with sqlite3.connect(DB_PATH) as db:
        db.execute('INSERT INTO recovery_codes(profile_id,code_hash,created_at) VALUES (?,?,?) '
                   'ON CONFLICT(profile_id) DO UPDATE SET code_hash=excluded.code_hash,created_at=excluded.created_at',
                   (profile_id, recovery_digest(code), time.time()))
    return code


def redeem_recovery_code(code):
    # Single-use, rotated credential. Process atomically so concurrent redemptions fail.
    if not isinstance(code,str) or not 32 <= len(code) <= 100:
        return None
    digest = recovery_digest(code)
    new_secret = secrets.token_urlsafe(40)
    with sqlite3.connect(DB_PATH) as db:
        db.row_factory=sqlite3.Row
        db.execute('BEGIN IMMEDIATE')
        row=db.execute('SELECT p.id,p.nickname,p.avatar,p.kp FROM profiles p JOIN recovery_codes r '
                       'ON r.profile_id=p.id WHERE r.code_hash=?',(digest,)).fetchone()
        if row is None:return None
        db.execute('DELETE FROM recovery_codes WHERE profile_id=?',(row['id'],))
        db.execute('UPDATE profiles SET secret=? WHERE id=?',(new_secret,row['id']))
        return dict(row, secret=new_secret)


def audit_moderation(action,target,detail):
    with sqlite3.connect(DB_PATH) as db:
        db.execute('INSERT INTO moderation_audit VALUES (?,?,?,?,?)',
                   (uuid.uuid4().hex,action,target,str(detail)[:500],time.time()))


def same_origin_or_nonbrowser(origin, host):
    """Reject foreign web origins. Non-browser clients without Origin remain supported."""
    if not origin:
        return True
    try:
        u=urlsplit(origin)
        return (u.scheme in ('http','https') and u.hostname is not None
                and u.netloc.lower() == host.lower() and not (u.username or u.password))
    except ValueError:
        return False


def creation_allowed(profile_id, now=None):
    """Persistent sliding-window throttle, including across process restarts."""
    now=time.time() if now is None else now
    with sqlite3.connect(DB_PATH) as db:
        n=db.execute('SELECT COUNT(*) FROM room_creation_events WHERE profile_id=? AND created_at>?',
                     (profile_id,now-3600)).fetchone()[0]
    return n < MAX_NEW_ROOMS_PER_HOUR


def record_room_creation(profile_id, when):
    with sqlite3.connect(DB_PATH) as db:
        db.execute('INSERT INTO room_creation_events VALUES (?,?)',(profile_id,when))
        # Prune old rows; avoid retaining unnecessary player usage data.
        db.execute('DELETE FROM room_creation_events WHERE created_at<?',(when-3600,))


def is_sanctioned(profile_id, now=None):
    now=time.time() if now is None else now
    with sqlite3.connect(DB_PATH) as db:
        return db.execute('SELECT 1 FROM player_sanctions WHERE profile_id=? AND expires_at>?',
                          (profile_id,now)).fetchone() is not None




def sql_one(query, args=()):
    with sqlite3.connect(DB_PATH) as c:
        c.row_factory = sqlite3.Row
        r = c.execute(query,args).fetchone()
        return dict(r) if r else None


def profile_info(profile_id):
    row = sql_one('SELECT id,nickname,avatar,kp FROM profiles WHERE id=?',(profile_id,))
    return row


def mutually_blocked(first, second):
    """A block in either direction prevents future room sharing/matchmaking."""
    if first == second:
        return False
    return sql_one('SELECT 1 AS yes FROM player_blocks WHERE (blocker_id=? AND blocked_id=?) OR (blocker_id=? AND blocked_id=?) LIMIT 1',
                   (first, second, second, first)) is not None


def can_join_unblocked(room, pid):
    return all(not mutually_blocked(pid, other) for other in room['players'] if other != pid)


def level_of(kp):
    # Minimum cumulative KP for level L is 250 * L * (L-1).
    result = 1
    while 250*(result+1)*result <= kp: result += 1
    return result


def clean_name(s):
    result=''.join(ch for ch in str(s or '') if ch.isprintable() and ch not in '\u202e\u202d\u200b').strip()
    result=' '.join(result.split())[:22]
    return result or 'Bestie Oyuncusu'


def clean_avatar(s):
    return str(s or '😎')[:12]


def rand_code():
    alphabet = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ'
    while True:
        code=''.join(secrets.choice(alphabet) for _ in range(6))
        if code not in ROOMS: return code


def choose_deck(mode, category, adult_mode=False):
    if mode == 'kim_daha':
        src = QUESTIONS['kim_daha']
        pool = [q for deck in src.values() for q in deck] if category=='MIXED' else src[category]
        return random.sample(pool, 10)
    if mode == 'trivia':
        src=QUESTIONS['trivia']
        pool=[q for deck in src.values() for q in deck] if category=='MIXED' else src[category]
        # A ten-round game contains at most 3 illustrated questions and avoids
        # repeating the same entity or placing illustrated rounds consecutively.
        # Choose a random variant for each answer, rather than always reusing
        # the final card in JSON. Never repeat the same answer within a match.
        by_entity={}
        for q in pool:
            by_entity.setdefault(q['entity'].casefold(),[]).append(q)
        # Illustrated rounds use only cards backed by a real source image.
        illustrated_candidates=[random.choice([q for q in cards if q.get('image')])
                                for cards in by_entity.values() if any(q.get('image') for q in cards)]
        random.shuffle(illustrated_candidates)
        image_count=min(len(illustrated_candidates),random.choice([2,3]))
        illustrated=illustrated_candidates[:image_count]
        used={q['entity'].casefold() for q in illustrated}
        text_pool=[random.choice([q for q in cards if not q.get('image')] or cards)
                   for entity,cards in by_entity.items() if entity not in used]
        # Do not silently fall back to fewer questions or duplicate answers.
        if len(text_pool)<10-image_count:raise ValueError('Yeterince farklı soru bulunamadı.')
        random.shuffle(text_pool)
        deck=text_pool[:10-image_count]
        chosen_slots=random.sample([1,4,7],image_count)
        for slot,q in sorted(zip(chosen_slots,illustrated)):
            deck.insert(slot,q)
        assert len(deck)==10 and len({q['entity'].casefold() for q in deck})==10
        assert sum(bool(q.get('image')) for q in deck)<=3
        return deck
    if mode == 'truth_dare':
        def sample_cards(kind):
            regular=QUESTIONS['truth_dare'][kind]
            adult=QUESTIONS['truth_dare'].get('adult_'+kind,[]) if adult_mode else []
            count=min(len(adult),2) if adult else 0
            return random.sample(regular,5-count)+random.sample(adult,count)
        a=sample_cards('truth')
        b=sample_cards('dare')
        random.shuffle(a);random.shuffle(b)
        result=[]
        for i in range(5):
            result.append(dict(a[i], card_type='truth'))
            result.append(dict(b[i], card_type='dare'))
        return result
    raise ValueError('Geçersiz oyun modu')


def daily_deck(day):
    """Same five questions for everyone on a given Istanbul calendar day."""
    seed=int(day.replace('-',''))
    rng=random.Random(seed)
    selected=[]
    for category in ('footballer','history','geography','movie','music'):
        # Use one entity once and keep the selection deterministic without global RNG.
        choices={q['entity'].casefold():q for q in QUESTIONS['trivia'][category] if not q.get('image')}
        selected.append(rng.choice(list(choices.values())))
    return selected


def daily_status(pid):
    day=datetime.now(ZoneInfo('Europe/Istanbul')).date().isoformat()
    with sqlite3.connect(DB_PATH) as db:
        rows=db.execute('SELECT question_index,correct FROM daily_results WHERE profile_id=? AND day=? ORDER BY question_index',
                        (pid,day)).fetchall()
    count=len(rows)
    return day,count,sum(r[1] for r in rows)*100,daily_deck(day)


def valid_config(mode, category):
    if mode=='kim_daha':return category in QUESTIONS['kim_daha'] or category=='MIXED'
    if mode=='trivia':return category in QUESTIONS['trivia'] or category=='MIXED'
    if mode=='truth_dare':return category=='truth_dare'
    return False


def new_room(profile, ws, mode, category, max_players=4, bottle='digital', adult_mode=False):
    if is_sanctioned(profile['id']):raise ValueError('Hesabına geçici oyun kısıtlaması uygulanmış.')
    if not valid_config(mode,category):raise ValueError('Oyun veya kategori seçimi geçersiz.')
    if len(ROOMS)>=MAX_ACTIVE_ROOMS:raise ValueError('Sunucu dolu, biraz sonra tekrar dene.')
    if not creation_allowed(profile['id']):raise ValueError('Çok fazla oda açtın. Bir süre sonra tekrar dene.')
    if not isinstance(max_players,int) or not 2<=max_players<=12:raise ValueError('Oda kapasitesi 2 ile 12 arasında olmalı.')
    if bottle not in ('digital','physical','none'):raise ValueError('Şişe modu geçersiz.')
    adult_mode=bool(adult_mode) and mode=='truth_dare'
    code=rand_code(); now=time.time(); pid=profile['id']
    room={'code':code,'mode':mode,'category':category,'bottle':bottle,'adult_mode':adult_mode,'max_players':max_players,
          'host':pid,'players':{},'phase':'lobby','index':0,'deck':choose_deck(mode,category,adult_mode=adult_mode),
          'votes':{},'hint_levels':{},'hints_used':defaultdict(int),'scores':defaultdict(int),'kp_earned':defaultdict(int),'start_at':0,
          'deadline':0,'result_until':0,'target':None,'finished_awarded':False,'created':now,'touched':now}
    ROOMS[code]=room
    ROOM_CREATIONS[pid].append(now)
    record_room_creation(pid,now)
    attach(room,profile,ws)
    save_room(room)
    return room


def attach(room, profile, ws):
    pid=profile['id']; now=time.time()
    if is_sanctioned(pid):raise ValueError('Hesabına geçici oyun kısıtlaması uygulanmış.')
    if room['phase']!='lobby' and pid not in room['players']:
        raise ValueError('Bu oyun başladı; yeni oyuncu katılamaz.')
    if pid not in room['players']:
        if not can_join_unblocked(room,pid):raise ValueError('Bu odada engellediğin veya seni engelleyen bir oyuncu var.')
        if len(room['players'])>=room['max_players']:raise ValueError('Oda dolu.')
        names={p['nickname'].casefold() for p in room['players'].values()}
        if profile['nickname'].casefold() in names:
            raise ValueError('Bu takma ad odada kullanılıyor. Başka bir ad seç.')
        room['players'][pid]={'id':pid,'nickname':profile['nickname'],'avatar':profile['avatar'],
                              'ready':False,'age_confirmed':False,'online':True,'ws':ws,'last_seen':now}
    else:
        old=room['players'][pid]['ws']
        if old and old is not ws:
            SOCKETS.pop(old,None)
            asyncio.create_task(old.close(code=4001,reason='Yeni bağlantıyla devam edildi.'))
        room['players'][pid]['ws']=ws
        room['players'][pid]['online']=True
        room['players'][pid]['last_seen']=now
        room['players'][pid]['nickname']=profile['nickname']
        room['players'][pid]['avatar']=profile['avatar']
    SOCKETS[ws]={'profile':profile,'room':room['code'],'player':pid}
    room['touched']=now


def current_hint_index(room, viewer):
    # Hint requests, not elapsed time, determine points for each player.
    return min(2,max(0,room['hint_levels'].get(viewer,0)))


def present(room, viewer):
    players=[]
    for pid,p in room['players'].items():
        prof=profile_info(pid)
        players.append({'id':pid,'nickname':p['nickname'],'avatar':p['avatar'],
                        'online':p['online'],'ready':p['ready'],'level':level_of(prof['kp'] if prof else 0),
                        'kp':prof['kp'] if prof else 0,'score':room['scores'].get(pid,0)})
    state={'code':room['code'],'mode':room['mode'],'category':room['category'],
           'category_label': LABELS.get(room['category'],room['category']), 'bottle':room['bottle'], 'adult_mode':room['adult_mode'],
           'max_players':room['max_players'],'host':room['host'],'players':players,
           'phase':room['phase'],'round':room['index']+1,'round_total':len(room['deck']),
           'server_now':time.time(),'ends_at':room['deadline'],'answered_count':len(room['votes']),
           'my_id':viewer,'my_answer':room['votes'].get(viewer),
           'my_kp_earned':room['kp_earned'].get(viewer,0)}
    if room['mode']=='trivia':
        used=room['hints_used'].get(viewer,0)
        state['hint_total']=HINTS_PER_MATCH
        state['hint_remaining']=max(0,HINTS_PER_MATCH-used)
        state['hint_used']=used
    if room['phase'] in ('question','result','finished') and room['index']<len(room['deck']):
        q=room['deck'][room['index']]
        state['question']={'id':q['id'],'text':q['text']}
        if q.get('image'):
            state['question']['image']=q['image']
            state['question']['image_alt']=q.get('image_alt','Bu soruya ait özgün illüstrasyon.')
        if room['mode']=='trivia':
            idx=current_hint_index(room,viewer) if room['phase']=='question' else 2
            state['question'].update(options=q['options'],hints=q['hints'][:idx+1],available_points=[100,70,40][idx])
        if room['mode']=='truth_dare':
            state['question'].update(card_type=q['card_type'],target=room['target'])
    if room['phase']=='result':
        q=room['deck'][room['index']]
        state['result_until']=room['result_until']
        if room['mode']=='kim_daha':
            tally=defaultdict(int)
            for target in room['votes'].values():
                if target in room['players']: tally[target]+=1
            state['results']={'votes':dict(tally)}
        if room['mode']=='trivia':
            state['results']={'correct_answer':q['answer'],'scores':{pid:room['scores'][pid] for pid in room['players']}}
        if room['mode']=='truth_dare':
            state['results']={'target':room['target'],'card_type':q['card_type']}
    if room['phase']=='finished':
        state['final_scores']={pid:room['scores'][pid] for pid in room['players']}
        state['final_kp']={pid:room['kp_earned'][pid] for pid in room['players']}
    return state


async def publish_room(room):
    for pid,p in list(room['players'].items()):
        ws=p['ws']
        if ws and p['online']:
            try:
                await ws.send_json({'type':'room','data':present(room,pid)})
                if room['phase']=='finished':
                    prof=profile_info(pid)
                    if prof:
                        secret=sql_one('SELECT secret FROM profiles WHERE id=?',(pid,))['secret']
                        await ws.send_json({'type':'profile','data':dict(prof,secret=secret,level=level_of(prof['kp']))})
            except (RuntimeError,OSError,WebSocketDisconnect):
                p['online']=False;p['ws']=None


def start_round(room):
    room['votes']={};room['hint_levels']={};room['phase']='question';room['start_at']=time.time()
    room['deadline']=room['start_at']+ (30 if room['mode']=='trivia' else 45 if room['mode']=='truth_dare' else 25)
    if room['mode']=='truth_dare':
        if room['bottle']=='digital':
            room['target']=random.choice(list(room['players']))
        elif room['bottle']=='none':
            room['target']=list(room['players'])[room['index']%len(room['players'])]
        else:
            room['target']=None  # The physical bottle determines the target; host chooses manually.


def finish_round(room):
    if room['phase']!='question':return
    room['phase']='result'
    room['result_until']=time.time()+ROUND_RESULT_SECONDS
    # KP accrual and match scores use data accepted by the server only.
    if room['mode']=='kim_daha':
        for pid,target in room['votes'].items():
            room['kp_earned'][pid]+=10
            if target in room['players']:room['scores'][target]+=1
    elif room['mode']=='trivia':
        for pid,submission in room['votes'].items():
            room['kp_earned'][pid]+=5
            if submission['answer']==room['deck'][room['index']]['answer']:
                room['kp_earned'][pid]+=5
                room['scores'][pid]+=submission['points']
    else:
        for pid,p in room['players'].items():
            if p['online']:room['kp_earned'][pid]+=10


def finish_game(room):
    room['phase']='finished';room['deadline']=0
    if room['finished_awarded']:return
    room['finished_awarded']=True
    with sqlite3.connect(DB_PATH) as c:
        for pid,p in room['players'].items():
            earned=room['kp_earned'][pid]
            if earned>0:
                earned+=20
                room['kp_earned'][pid]=earned
                # Unique per-room ledger entry prevents double KP grants on retry.
                inserted=c.execute('INSERT OR IGNORE INTO kp_ledger(id,profile_id,room_code,earned,created_at) VALUES (?,?,?,?,?)',
                    (room['code']+':'+pid,pid,room['code'],earned,time.time()))
                if inserted.rowcount: c.execute('UPDATE profiles SET kp=kp+? WHERE id=?',(earned,pid))


async def room_ticker():
    while True:
        await asyncio.sleep(.5)
        async with state_lock:
            now=time.time()
            to_send=[]
            for code,room in list(ROOMS.items()):
                if now-room['touched']>ROOM_MAX_IDLE:
                    # Expired room must also release socket memberships; otherwise
                    # clients remain stuck in an inaccessible room forever.
                    ROOMS.pop(code,None)
                    delete_room_snapshot(code)
                    for player in room['players'].values():
                        ws=player.get('ws')
                        if ws in SOCKETS:
                            SOCKETS[ws]['room']=None
                            try:await ws.send_json({'type':'left','reason':'Odanın süresi doldu.'})
                            except (RuntimeError,OSError,WebSocketDisconnect):pass
                    continue
                if room['phase']=='question' and now>=room['deadline']:
                    finish_round(room);to_send.append(room)
                elif room['phase']=='result' and now>=room['result_until']:
                    room['index']+=1
                    if room['index']>=len(room['deck']):finish_game(room)
                    else:start_round(room)
                    to_send.append(room)
            for room in to_send:
                save_room(room)
                await publish_room(room)


@asynccontextmanager
async def lifespan(app):
    restore_rooms()
    t=asyncio.create_task(room_ticker())
    yield
    t.cancel()
    try:await t
    except asyncio.CancelledError:pass

# Browser blocks inline scripts under the global CSP, which previously caused a
# completely blank /offline (Tekli Oyna) screen. Whitelist only this exact script.
import base64
OFFLINE_PAGE = HERE / 'static' / 'Bestie_V10_Cevrimdisi.html'
def offline_script_hash():
    html = OFFLINE_PAGE.read_text(encoding='utf-8')
    if html.count('<script>') != 1 or html.count('</script>') != 1:
        raise RuntimeError('Offline page must contain exactly one inline script')
    code = html.split('<script>', 1)[1].split('</script>', 1)[0]
    digest = base64.b64encode(hashlib.sha256(code.encode('utf-8')).digest()).decode('ascii')
    return "'sha256-" + digest + "'"
OFFLINE_SCRIPT_CSP_HASH = offline_script_hash()

app=FastAPI(title='Bestie? Canlı Oda',lifespan=lifespan)
app.mount('/static',StaticFiles(directory=str(HERE/'static')),name='static')

@app.middleware('http')
async def security_headers(request: Request, call_next):
    response = await call_next(request)
    # HTTPS is terminated by the production reverse proxy; do not emit HSTS on local HTTP.
    if request.url.scheme == 'https' or request.headers.get('x-forwarded-proto','').lower() == 'https':
        response.headers['Strict-Transport-Security'] = 'max-age=31536000; includeSubDomains'
    response.headers['X-Content-Type-Options'] = 'nosniff'
    response.headers['Referrer-Policy'] = 'strict-origin-when-cross-origin'
    response.headers['X-Frame-Options'] = 'DENY'
    response.headers['Permissions-Policy'] = 'camera=(), microphone=(), geolocation=()'
    # Allow only the exact, bundled offline game's inline script. This page
    # runs as a standalone file as well as at /offline, so use a CSP SHA-256 hash.
    offline_paths = ('/offline', '/static/Bestie_V10_Cevrimdisi.html')
    script_policy = "script-src 'self'"
    if request.url.path in offline_paths:
        script_policy += ' ' + OFFLINE_SCRIPT_CSP_HASH
    response.headers['Content-Security-Policy'] = (
        "default-src 'self'; img-src 'self' data: blob:; media-src 'self'; "
        "style-src 'self' 'unsafe-inline'; " + script_policy + "; "
        "connect-src 'self' ws: wss:; object-src 'none'; frame-ancestors 'none'; base-uri 'self'")
    if request.url.path.startswith('/api/') or request.url.path in ('/moderasyon','/health'):
        response.headers['Cache-Control']='no-store'
    return response


@app.get('/')
async def home():return FileResponse(HERE/'static'/'index.html')

@app.get('/offline')
async def offline():return FileResponse(HERE/'static'/'Bestie_V10_Cevrimdisi.html')

def require_admin(authorization: str | None = Header(default=None)):
    if not ADMIN_TOKEN or len(ADMIN_TOKEN)<24:
        raise HTTPException(status_code=503, detail='Moderasyon paneli yapılandırılmadı.')
    candidate=(authorization or '').removeprefix('Bearer ').strip()
    if not hmac.compare_digest(candidate,ADMIN_TOKEN):
        raise HTTPException(status_code=401, detail='Yetkisiz erişim.')
    return True


@app.get('/moderasyon',response_class=HTMLResponse)
async def moderation_page():
    if not ADMIN_TOKEN or len(ADMIN_TOKEN)<24:raise HTTPException(status_code=404)
    return FileResponse(HERE/'static'/'moderasyon.html',headers={'Cache-Control':'no-store'})


@app.get('/api/admin/reports')
async def admin_reports(status: str = 'pending', limit: int = 100, admin=Depends(require_admin)):
    if status not in ('pending','reviewed','dismissed','all'):raise HTTPException(400,'Geçersiz filtre.')
    limit=min(200,max(1,limit))
    with sqlite3.connect(DB_PATH) as db:
        db.row_factory=sqlite3.Row
        query='SELECT id,room_code,reason,status,created_at,reviewed_at,review_note,reporter_id,target_id FROM player_reports'
        args=[]
        if status!='all':query+=' WHERE status=?';args.append(status)
        query+=' ORDER BY created_at DESC LIMIT ?';args.append(limit)
        rows=[dict(x) for x in db.execute(query,args)]
    return JSONResponse({'reports':rows},headers={'Cache-Control':'no-store'})


@app.post('/api/admin/reports/{report_id}/review')
async def admin_review(report_id:str, payload:dict, admin=Depends(require_admin)):
    status=payload.get('status')
    note=str(payload.get('note','')).strip()[:500]
    if status not in ('reviewed','dismissed'):raise HTTPException(400,'Geçersiz karar.')
    with sqlite3.connect(DB_PATH) as db:
        result=db.execute('UPDATE player_reports SET status=?,reviewed_at=?,review_note=? WHERE id=?',
                          (status,time.time(),note,report_id))
    if result.rowcount!=1:raise HTTPException(404,'Şikâyet bulunamadı.')
    audit_moderation('report_review',report_id,status+': '+note)
    return {'ok':True,'status':status}


@app.post('/api/admin/sanctions')
async def admin_sanction(payload:dict, admin=Depends(require_admin)):
    profile_id=str(payload.get('profile_id',''))
    hours=payload.get('hours')
    reason=str(payload.get('reason','')).strip()[:200]
    if not isinstance(hours,int) or isinstance(hours,bool) or not 1<=hours<=720 or not reason:
        raise HTTPException(400,'Süre 1–720 saat olmalı ve gerekçe girilmeli.')
    if profile_info(profile_id) is None:raise HTTPException(404,'Oyuncu bulunamadı.')
    now=time.time()
    with sqlite3.connect(DB_PATH) as db:
        db.execute('INSERT OR REPLACE INTO player_sanctions VALUES (?,?,?,?)',
                   (profile_id,reason,now+hours*3600,now))
    audit_moderation('sanction',profile_id,reason+' ('+str(hours)+'h)')
    return {'ok':True,'expires_at':now+hours*3600}


@app.delete('/api/admin/sanctions/{profile_id}')
async def admin_unsanction(profile_id:str, admin=Depends(require_admin)):
    with sqlite3.connect(DB_PATH) as db:
        db.execute('DELETE FROM player_sanctions WHERE profile_id=?',(profile_id,))
    audit_moderation('unsanction',profile_id,'Kısıtlama kaldırıldı')
    return {'ok':True}


@app.get('/api/admin/appeals')
async def admin_appeals(status:str='pending',admin=Depends(require_admin)):
    if status not in ('pending','reviewed','dismissed','all'):raise HTTPException(400,'Geçersiz filtre.')
    query='SELECT id,profile_id,text,status,created_at,reviewed_at,review_note FROM sanction_appeals'
    args=[]
    if status!='all':query+=' WHERE status=?';args.append(status)
    query+=' ORDER BY created_at DESC LIMIT 100'
    with sqlite3.connect(DB_PATH) as db:
        db.row_factory=sqlite3.Row
        rows=[dict(x) for x in db.execute(query,args)]
    return JSONResponse({'appeals':rows},headers={'Cache-Control':'no-store'})


@app.post('/api/admin/appeals/{appeal_id}/review')
async def admin_review_appeal(appeal_id:str,payload:dict,admin=Depends(require_admin)):
    status=payload.get('status')
    if status not in ('reviewed','dismissed'):raise HTTPException(400,'Geçersiz karar.')
    note=str(payload.get('note','')).strip()[:500]
    with sqlite3.connect(DB_PATH) as db:
        result=db.execute('UPDATE sanction_appeals SET status=?,reviewed_at=?,review_note=? WHERE id=? AND status=?',
                          (status,time.time(),note,appeal_id,'pending'))
    if result.rowcount!=1:raise HTTPException(404,'Bekleyen itiraz bulunamadı.')
    audit_moderation('appeal_review',appeal_id,status+': '+note)
    return {'ok':True,'status':status}


@app.get('/api/admin/audit')
async def admin_audit(limit:int=50,admin=Depends(require_admin)):
    with sqlite3.connect(DB_PATH) as db:
        db.row_factory=sqlite3.Row
        rows=[dict(x) for x in db.execute('SELECT action,target,detail,created_at FROM moderation_audit ORDER BY created_at DESC LIMIT ?', (max(1,min(limit,200)),))]
    return JSONResponse({'events':rows},headers={'Cache-Control':'no-store'})


@app.get('/live')
async def liveness():
    # A separate liveness check avoids hiding a stuck/missing dependency behind a 200.
    return {'status':'alive'}


@app.get('/health')
async def health():
    # Readiness must detect a read-only/unwritable SQLite volume, not just SELECT 1.
    try:
        if not QUESTIONS_PATH.is_file():
            raise RuntimeError('Soru bankası bulunamadı')
        with sqlite3.connect(DB_PATH, timeout=2) as db:
            db.execute('PRAGMA busy_timeout=2000')
            db.execute('BEGIN IMMEDIATE')
            try:
                db.execute('INSERT OR REPLACE INTO health_probe (probe_id,ts) VALUES (1,?)',(time.time(),))
            finally:
                db.rollback()  # No permanent writes or growth from health checks.
    except (sqlite3.Error, OSError, RuntimeError):
        return JSONResponse({'status':'unavailable'},status_code=503,headers={'Cache-Control':'no-store'})
    return JSONResponse({'status':'ok','active_rooms':len(ROOMS),
       'online_connections':sum(1 for x in SOCKETS.values() if x['room'])},headers={'Cache-Control':'no-store'})


async def error(ws,message):await ws.send_json({'type':'error','message':str(message)[:300]})


async def process(ws,msg):
    action=msg.get('action')
    data=msg.get('data') or {}
    if not isinstance(data,dict):raise ValueError('Geçersiz veri.')
    state=SOCKETS.get(ws)
    if action=='recover_account':
        # Recovery can be initiated from a fresh WebSocket without an active account.
        if state and state.get('room'):raise ValueError('Önce odadan ayrılmalısın.')
        recovered=redeem_recovery_code(data.get('code'))
        if not recovered:raise ValueError('Kurtarma kodu geçersiz veya daha önce kullanılmış.')
        # Force existing sockets for this account to reauthenticate.
        for other, session in list(SOCKETS.items()):
            if other is not ws and session.get('profile',{}).get('id')==recovered['id']:
                SOCKETS.pop(other,None)
                try:await other.close(code=1008,reason='Oturum yenilendi')
                except Exception:pass
        SOCKETS[ws]={'profile':recovered,'room':None,'player':recovered['id']}
        await ws.send_json({'type':'profile','data':dict(recovered,level=level_of(recovered['kp']))})
        await ws.send_json({'type':'recovery_success','message':'Hesabın kurtarıldı. Eski oturum anahtarın iptal edildi. Yeni kurtarma kodu oluştur.'})
        return
    if action=='init':
        if state and state.get('profile'):
            prof=profile_info(state['profile']['id'])
            if prof:
                state['profile'].update(prof)
                await ws.send_json({'type':'profile','data':dict(prof,secret=state['profile']['secret'],level=level_of(prof['kp']))})
            return
        secret=str(data.get('secret') or '')
        row=sql_one('SELECT id,secret,nickname,avatar,kp FROM profiles WHERE secret=?',(secret,)) if len(secret)>=48 else None
        if not row:
            row={'id':uuid.uuid4().hex,'secret':secrets.token_urlsafe(40),'nickname':clean_name(data.get('nickname') or 'Bestie Oyuncusu'),
                 'avatar':clean_avatar(data.get('avatar')),'kp':0}
            with sqlite3.connect(DB_PATH) as c:c.execute('INSERT INTO profiles VALUES (?,?,?,?,?)',(row['id'],row['secret'],row['nickname'],row['avatar'],0))
        SOCKETS[ws]={'profile':row,'room':None,'player':row['id']}
        await ws.send_json({'type':'profile','data':{'id':row['id'],'secret':row['secret'],'nickname':row['nickname'],'avatar':row['avatar'],'kp':row['kp'],'level':level_of(row['kp'])}})
        return
    if not state:raise ValueError('Önce profil oluşturulmalı.')
    profile=state['profile'];pid=profile['id']
    if action=='create_recovery_code':
        if state['room']:raise ValueError('Oda içindeyken kurtarma kodu oluşturulamaz.')
        code=create_recovery_code(pid)
        await ws.send_json({'type':'recovery_code','data':{'code':code},
            'message':'Bu kodu güvenli yerde sakla. Yeni kod oluşturursan önceki geçersiz olur. Kod yalnızca bir kez kullanılabilir.'})
        return
    if action=='profile_update':
        if state['room']:raise ValueError('Oyun içindeyken profili değiştiremezsin.')
        profile['nickname']=clean_name(data.get('nickname'))
        profile['avatar']=clean_avatar(data.get('avatar'))
        with sqlite3.connect(DB_PATH) as c:c.execute('UPDATE profiles SET nickname=?, avatar=? WHERE id=?',(profile['nickname'],profile['avatar'],pid))
        await ws.send_json({'type':'profile','data':dict(profile_info(pid),secret=profile['secret'],level=level_of(profile_info(pid)['kp']))})
        return
    if action=='appeal_sanction':
        if not is_sanctioned(pid):raise ValueError('Aktif bir kısıtlaman bulunmuyor.')
        reason=str(data.get('reason','')).strip()
        if not 15<=len(reason)<=500:raise ValueError('İtiraz gerekçesi 15–500 karakter olmalı.')
        now=time.time()
        with sqlite3.connect(DB_PATH) as db:
            existing=db.execute('SELECT 1 FROM sanction_appeals WHERE profile_id=? AND created_at>?',
                                (pid,now-7*86400)).fetchone()
            if existing:raise ValueError('7 gün içinde bir itiraz gönderdin.')
            db.execute('INSERT INTO sanction_appeals(id,profile_id,text,status,created_at) VALUES (?,?,?,?,?)',
                       (uuid.uuid4().hex,pid,reason,'pending',now))
        await ws.send_json({'type':'appeal_received','message':'İtirazın kaydedildi; inceleme sonrası işlem uygulanabilir.'})
        return
    if action=='export_profile':
        # Export own minimally necessary personal data; never expose account secret in exports.
        with sqlite3.connect(DB_PATH) as db:
            reports=db.execute('SELECT room_code,reason,created_at,status FROM player_reports WHERE reporter_id=?',(pid,)).fetchall()
            ledger=db.execute('SELECT room_code,earned,created_at FROM kp_ledger WHERE profile_id=?',(pid,)).fetchall()
            blocked=db.execute('SELECT blocked_id,created_at FROM player_blocks WHERE blocker_id=?',(pid,)).fetchall()
            appeals=db.execute('SELECT text,status,created_at,reviewed_at,review_note FROM sanction_appeals WHERE profile_id=?',(pid,)).fetchall()
        await ws.send_json({'type':'profile_export','data':{'profile':profile_info(pid),
            'reports':[dict(zip(('room_code','reason','created_at','status'),r)) for r in reports],
            'kp_history':[dict(zip(('room_code','earned','created_at'),r)) for r in ledger],
            'blocks':[dict(zip(('blocked_id','created_at'),r)) for r in blocked],
            'appeals':[dict(zip(('text','status','created_at','reviewed_at','review_note'),r)) for r in appeals]}})
        return
    if action=='delete_profile':
        # Requires an authenticated socket with its existing opaque profile secret.
        # Do not allow removal while participating in a match.
        if state['room']:raise ValueError('Hesabını silmek için önce odadan ayrılmalısın.')
        with sqlite3.connect(DB_PATH) as db:
            db.execute('DELETE FROM player_reports WHERE reporter_id=? OR target_id=?',(pid,pid))
            db.execute('DELETE FROM player_blocks WHERE blocker_id=? OR blocked_id=?',(pid,pid))
            db.execute('DELETE FROM daily_results WHERE profile_id=?',(pid,))
            db.execute('DELETE FROM leaderboard_optin WHERE profile_id=?',(pid,))
            db.execute('DELETE FROM kp_ledger WHERE profile_id=?',(pid,))
            db.execute('DELETE FROM room_creation_events WHERE profile_id=?',(pid,))
            db.execute('DELETE FROM player_sanctions WHERE profile_id=?',(pid,))
            db.execute('DELETE FROM sanction_appeals WHERE profile_id=?',(pid,))
            db.execute('DELETE FROM recovery_codes WHERE profile_id=?',(pid,))
            db.execute('DELETE FROM profiles WHERE id=?',(pid,))
        for queue in MATCH_QUEUE.values():
            if ws in queue:queue.remove(ws)
        SOCKETS.pop(ws,None)
        ROOM_CREATIONS.pop(pid,None)
        await ws.send_json({'type':'profile_deleted'})
        return
    if action=='daily':
        day,count,score,deck=daily_status(pid)
        q=deck[count] if count<len(deck) else None
        card=({'text':q['text'],'options':q['options'],'hints':q['hints'][:1],
                'image':q.get('image')} if q else None)
        await ws.send_json({'type':'daily','data':{'day':day,'index':count,'total':len(deck),'score':score,'question':card}})
        return
    if action=='daily_answer':
        day,count,score,deck=daily_status(pid)
        if count>=len(deck):raise ValueError('Günlük görev tamamlandı.')
        answer=str(data.get('answer',''))
        q=deck[count]
        if answer not in q['options']:raise ValueError('Geçersiz cevap.')
        correct=answer==q['answer']
        with sqlite3.connect(DB_PATH) as db:
            try:db.execute('INSERT INTO daily_results VALUES (?,?,?,?,?)',(pid,day,count,answer,int(correct)))
            except sqlite3.IntegrityError:raise ValueError('Bu soruyu zaten cevapladın.')
        await ws.send_json({'type':'daily_answered','data':{'correct':correct,'answer':q['answer']}})
        return
    if action=='leaderboard':
        # No historical backfill: this weekly leaderboard starts with V9.9's KP ledger.
        from datetime import datetime, timezone, timedelta
        now=datetime.now(timezone.utc)
        monday=(now-timedelta(days=now.weekday())).replace(hour=0,minute=0,second=0,microsecond=0)
        with sqlite3.connect(DB_PATH) as db:
            db.row_factory=sqlite3.Row
            rows=[dict(r) for r in db.execute("""SELECT p.nickname,p.avatar, SUM(k.earned) AS points
                FROM kp_ledger k JOIN profiles p ON p.id=k.profile_id
                JOIN leaderboard_optin o ON o.profile_id=p.id AND o.enabled=1
                WHERE k.created_at >= ? GROUP BY k.profile_id ORDER BY points DESC LIMIT 20""",(monday.timestamp(),))]
            mine=db.execute('SELECT enabled FROM leaderboard_optin WHERE profile_id=?',(pid,)).fetchone()
        await ws.send_json({'type':'leaderboard','data':{'players':rows,'enabled':bool(mine and mine['enabled']),
                'week_start':monday.date().isoformat()}})
        return
    if action=='leaderboard_optin':
        enabled=data.get('enabled')
        if not isinstance(enabled,bool):raise ValueError('Sıralama tercihi geçersiz.')
        with sqlite3.connect(DB_PATH) as db:
            db.execute('INSERT INTO leaderboard_optin(profile_id,enabled) VALUES (?,?) ON CONFLICT(profile_id) DO UPDATE SET enabled=excluded.enabled',
                       (pid,int(enabled)))
        await ws.send_json({'type':'leaderboard_saved','message':'Haftalık sıralama tercihin kaydedildi.'})
        return
    if action=='list_blocks':
        with sqlite3.connect(DB_PATH) as db:
            db.row_factory=sqlite3.Row
            blocks=[dict(row) for row in db.execute('''''''''SELECT b.blocked_id AS id, COALESCE(p.nickname,'Silinmiş kullanıcı') AS nickname
                    FROM player_blocks b LEFT JOIN profiles p ON p.id=b.blocked_id
                    WHERE b.blocker_id=? ORDER BY b.created_at DESC LIMIT 100''''''''' ,(pid,))]
        await ws.send_json({'type':'blocked_list','data':blocks})
        return
    if action=='unblock_player':
        target=str(data.get('target',''))
        with sqlite3.connect(DB_PATH) as db:
            result=db.execute('DELETE FROM player_blocks WHERE blocker_id=? AND blocked_id=?',(pid,target))
        if result.rowcount==0:raise ValueError('Bu kişi engelli listende değil.')
        await ws.send_json({'type':'block_removed','message':'Engel kaldırıldı.'})
        return
    if action=='block_player':
        code=state['room'];room=ROOMS.get(code) if code else None
        if not room or pid not in room['players']:
            raise ValueError('Engellemek için oyuncuyla aynı odada olmalısın.')
        target=str(data.get('target',''))
        if target==pid or target not in room['players']:
            raise ValueError('Engellenecek geçerli bir oyuncu seç.')
        with sqlite3.connect(DB_PATH) as db:
            db.execute('INSERT OR IGNORE INTO player_blocks(blocker_id,blocked_id,created_at) VALUES (?,?,?)',(pid,target,time.time()))
        await ws.send_json({'type':'block_received','message':'Oyuncu engellendi. Bir sonraki oda ve rastgele eşleşmede birlikte olmayacaksınız. Devam eden oyun etkilenmez.'})
        return
    if action=='report_player':
        code=state['room'];room=ROOMS.get(code) if code else None
        if not room or pid not in room['players']:
            raise ValueError('Şikâyet göndermek için oyuncuyla aynı odada olmalısın.')
        target=str(data.get('target',''))
        reason=str(data.get('reason','')).strip()
        allowed={'hakaret','taciz','uygunsuz_icerik','hile','diger'}
        if target==pid or target not in room['players']:raise ValueError('Geçerli bir oyuncu seç.')
        if reason not in allowed:raise ValueError('Şikâyet nedeni seç.')
        now=time.time()
        with sqlite3.connect(DB_PATH) as db:
            n=db.execute('SELECT COUNT(*) FROM player_reports WHERE reporter_id=? AND created_at>?',(pid,now-86400)).fetchone()[0]
            if n>=5:raise ValueError('Günlük şikâyet sınırına ulaştın.')
            db.execute('INSERT INTO player_reports(id,reporter_id,target_id,room_code,reason,created_at) VALUES (?,?,?,?,?,?)',
                (uuid.uuid4().hex,pid,target,room['code'],reason,now))
        await ws.send_json({'type':'report_received','message':'Bildirimin kaydedildi. Otomatik ceza uygulanmaz.'})
        return
    if action=='create':
        if state['room']:raise ValueError('Zaten bir odadasın.')
        room=new_room(profile,ws,str(data.get('mode','kim_daha')),str(data.get('category','KIM_DAHA')),
                      data.get('max_players',4),str(data.get('bottle','digital')),bool(data.get('adult_mode',False)))
        await publish_room(room)
        return
    if action=='join':
        if state['room']:raise ValueError('Zaten bir odadasın.')
        code=str(data.get('code','')).upper().strip()
        room=ROOMS.get(code)
        if not room:raise ValueError('Oda bulunamadı. Kodu kontrol et.')
        attach(room,profile,ws)
        save_room(room)
        await publish_room(room)
        return
    if action=='matchmake':
        if is_sanctioned(pid):raise ValueError('Hesabına geçici oyun kısıtlaması uygulanmış.')
        if state['room']:raise ValueError('Zaten bir odadasın.')
        mode=str(data.get('mode','trivia'));category=str(data.get('category','MIXED'))
        if not valid_config(mode,category):raise ValueError('Geçersiz eşleşme kategorisi.')
        key=(mode,category)
        q=MATCH_QUEUE[key]
        q[:]=[w for w in q if w in SOCKETS and SOCKETS[w]['room'] is None]
        other=None
        for candidate in list(q):
            if candidate is not ws and not mutually_blocked(pid,SOCKETS[candidate]['profile']['id']):
                other=candidate
                q.remove(candidate)
                break
        if other is None:
            if ws not in q:q.append(ws)
            await ws.send_json({'type':'matching','data':{'waiting':True,'mode':mode,'category':category}})
        else:
            opponent=SOCKETS[other]['profile']
            room=new_room(opponent,other,mode,category,2,'none')
            attach(room,profile,ws)
            for p in room['players'].values():p['ready']=True
            start_round(room)
            save_room(room)
            await publish_room(room)
        return
    if action=='cancel_match':
        for q in MATCH_QUEUE.values():
            if ws in q:q.remove(ws)
        await ws.send_json({'type':'matching','data':{'waiting':False}})
        return
    code=state['room'];room=ROOMS.get(code) if code else None
    if not room or pid not in room['players']:raise ValueError('Önce bir odaya katıl.')
    room['touched']=time.time()
    if action=='ready':
        if room['phase']!='lobby':raise ValueError('Oyun başladı.')
        ready=bool(data.get('ready'))
        if ready and room['adult_mode'] and data.get('age_confirmed') is not True:
            raise ValueError('Yetişkin modu için 18 yaşını doldurduğunu onaylaman gerekir.')
        room['players'][pid]['age_confirmed']=bool(data.get('age_confirmed')) if ready else False
        room['players'][pid]['ready']=ready
    elif action=='start':
        if pid!=room['host']:raise ValueError('Yalnızca oda kurucusu başlatabilir.')
        if room['phase']!='lobby':raise ValueError('Oyun zaten başladı.')
        if not 2<=len(room['players'])<=room['max_players']:raise ValueError('En az 2 kişi gerekli.')
        if any(not p['ready'] or not p['online'] for p in room['players'].values()):raise ValueError('Herkesin hazır ve bağlı olması gerekiyor.')
        start_round(room)
    elif action=='hint':
        if room['mode']!='trivia' or room['phase']!='question' or time.time()>=room['deadline']:
            raise ValueError('Şu anda yeni ipucu alamazsın.')
        if pid in room['votes']:raise ValueError('Cevap verdikten sonra ipucu alınamaz.')
        if current_hint_index(room,pid)>=2:raise ValueError('Bu sorudaki tüm ipuçlarını açtın.')
        if room['hints_used'].get(pid,0)>=HINTS_PER_MATCH:
            raise ValueError('Bu oyundaki 5 ipucu hakkını kullandın.')
        room['hint_levels'][pid]=current_hint_index(room,pid)+1
        room['hints_used'][pid]+=1
    elif action=='answer':
        if room['phase']!='question' or time.time()>=room['deadline']:raise ValueError('Bu turun süresi doldu.')
        if room['mode']=='kim_daha':
            target=str(data.get('answer'))
            if target not in room['players']:raise ValueError('Lütfen odadaki bir oyuncuyu seç.')
            room['votes'][pid]=target
        elif room['mode']=='trivia':
            if pid in room['votes']:raise ValueError('Bu soruya zaten cevap verdin.')
            answer=str(data.get('answer'))
            if answer not in room['deck'][room['index']]['options']:raise ValueError('Geçersiz seçenek.')
            idx=current_hint_index(room,pid)
            room['votes'][pid]={'answer':answer,'points':(100,70,40)[idx]}
        else:raise ValueError('Bu modda seçenekli oy yok.')
        # Early results only when everybody answered; server still verifies all submissions.
        if room['mode']!='truth_dare' and len(room['votes'])==len(room['players']):finish_round(room)
    elif action=='target':
        if room['mode']!='truth_dare' or room['phase']!='question' or room['bottle']!='physical':raise ValueError('Fizikî şişe modunda değilsiniz.')
        if pid!=room['host']:raise ValueError('Kişiyi kurucu seçebilir.')
        target=str(data.get('target'))
        if target not in room['players']:raise ValueError('Oyuncu seç.')
        room['target']=target
    elif action=='complete_round':
        if room['mode']!='truth_dare' or room['phase']!='question':raise ValueError('Tur zaten kapandı.')
        if pid not in (room['host'],room['target']):raise ValueError('Kurucu veya seçilen oyuncu sonraki tura geçebilir.')
        finish_round(room)
    elif action=='leave':
        if room['phase'] in ('lobby','finished'):
            if room['phase']=='lobby':
                room['players'].pop(pid)
                if pid==room['host'] and room['players']:room['host']=next(iter(room['players']))
                if not room['players']:ROOMS.pop(code,None)
            else:
                room['players'][pid]['ws']=None
                room['players'][pid]['online']=False
            state['room']=None
            await ws.send_json({'type':'left'})
        else:raise ValueError('Oyun sırasında ayrılmak yerine bağlantıyı kapatabilirsin; yeniden katılman mümkün.')
    else:raise ValueError('Bilinmeyen işlem.')
    if code in ROOMS:
        save_room(room)
        await publish_room(room)
    else:delete_room_snapshot(code)


@app.websocket('/ws')
async def ws_entry(ws:WebSocket):
    if not same_origin_or_nonbrowser(ws.headers.get('origin'),ws.headers.get('host','')):
        await ws.close(code=1008,reason='İzin verilmeyen bağlantı kaynağı.')
        return
    await ws.accept()
    last_messages=[]
    try:
        while True:
            raw=await ws.receive_text()
            if len(raw)>16000:
                await error(ws,'İleti çok uzun.');continue
            now=time.time()
            last_messages=[x for x in last_messages if now-x<5]
            last_messages.append(now)
            if len(last_messages)>40:
                await error(ws,'Çok hızlı işlem yapılıyor.');continue
            try:
                obj=json.loads(raw)
                if not isinstance(obj,dict):raise ValueError('Geçersiz istek.')
                async with state_lock:await process(ws,obj)
            except (ValueError,KeyError,TypeError) as exc:await error(ws,str(exc))
    except WebSocketDisconnect:pass
    except (RuntimeError,OSError):pass
    finally:
        async with state_lock:
            context=SOCKETS.pop(ws,None)
            for q in MATCH_QUEUE.values():
                if ws in q:q.remove(ws)
            if context and context['room'] in ROOMS:
                room=ROOMS[context['room']]
                p=room['players'].get(context['player'])
                if p and p['ws'] is ws:
                    p['online']=False;p['ws']=None;p['last_seen']=time.time()
                    if room['phase']=='lobby':
                        active=[z['id'] for z in room['players'].values() if z['online']]
                        if active and room['host']==context['player']:room['host']=active[0]
                    save_room(room)
                    await publish_room(room)
