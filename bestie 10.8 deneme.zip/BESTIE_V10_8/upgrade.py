from pathlib import Path
import json, random, textwrap, re, os, math
from PIL import Image, ImageDraw, ImageFont, ImageEnhance
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
BASE=Path(__file__).parent
server_path=BASE/'server.py'; js_path=BASE/'static'/'index.html'; data_path=BASE/'data'/'questions.json'
def repl(s,a,b,label):
    n=s.count(a)
    if n!=1: raise RuntimeError(f'{label}: expected one matching section, found {n}')
    return s.replace(a,b)
server=server_path.read_text('utf-8')
server=repl(server,"def choose_deck(mode, category):","def choose_deck(mode, category, adult_mode=False):",'choose signature')
server=repl(server,"""        random.shuffle(pool := list(pool))
        result=[]; seen=set()
        for q in pool:
            if q['entity'].casefold() not in seen:
                result.append(q); seen.add(q['entity'].casefold())
            if len(result)==10: return result
        raise ValueError('Bu kategoride yeterince benzersiz soru bulunamadı.')""","""        # A ten-round game contains at most 3 illustrated questions and avoids
        # repeating the same entity or placing illustrated rounds consecutively.
        illustrations=list({q['entity'].casefold(): q for q in pool if q.get('image')}.values())
        random.shuffle(illustrations)
        image_count=min(len(illustrations), random.choice([2, 3]))
        illustrated=illustrations[:image_count]
        used={q['entity'].casefold() for q in illustrated}
        text_pool=list({q['entity'].casefold(): q for q in pool if not q.get('image') and q['entity'].casefold() not in used}.values())
        random.shuffle(text_pool)
        if len(text_pool)<10-image_count:raise ValueError('Yeterince farklı soru bulunamadı.')
        deck=text_pool[:10-image_count]
        chosen_slots=random.sample([1,4,7],image_count)
        for slot,q in sorted(zip(chosen_slots,illustrated)):
            deck.insert(slot,q)
        assert len(deck)==10 and len({q['entity'].casefold() for q in deck})==10
        assert sum(bool(q.get('image')) for q in deck)<=3
        return deck""",'deck replacement')
server=repl(server,"""        a=random.sample(QUESTIONS['truth_dare']['truth'],5)
        b=random.sample(QUESTIONS['truth_dare']['dare'],5)""","""        def sample_cards(kind):
            regular=QUESTIONS['truth_dare'][kind]
            adult=QUESTIONS['truth_dare'].get('adult_'+kind,[]) if adult_mode else []
            count=min(len(adult),2) if adult else 0
            return random.sample(regular,5-count)+random.sample(adult,count)
        a=sample_cards('truth')
        b=sample_cards('dare')
        random.shuffle(a);random.shuffle(b)""",'adult decks')
server=repl(server,"def new_room(profile, ws, mode, category, max_players=4, bottle='digital'):","def new_room(profile, ws, mode, category, max_players=4, bottle='digital', adult_mode=False):",'room signature')
server=repl(server,"    if bottle not in ('digital','physical','none'):raise ValueError('Şişe modu geçersiz.')","    if bottle not in ('digital','physical','none'):raise ValueError('Şişe modu geçersiz.')\n    adult_mode=bool(adult_mode) and mode=='truth_dare'",'adult guard')
server=repl(server,"'bottle':bottle,'max_players':max_players,","'bottle':bottle,'adult_mode':adult_mode,'max_players':max_players,",'room adult attr')
server=repl(server,"'index':0,'deck':choose_deck(mode,category),","'index':0,'deck':choose_deck(mode,category,adult_mode=adult_mode),",'choose adult')
server=repl(server,"'votes':{},'scores':defaultdict(int)","'votes':{},'hint_levels':{},'scores':defaultdict(int)",'hint_levels')
server=repl(server,"'ready':False,'online':True,'ws':ws,'last_seen':now}","'ready':False,'age_confirmed':False,'online':True,'ws':ws,'last_seen':now}",'age confirmed')
server=repl(server,"""def current_hint_index(room):
    return min(2,max(0,int((time.time()-room['start_at'])//10)))""","""def current_hint_index(room, viewer):
    # Hint requests, not elapsed time, determine points for each player.
    return min(2,max(0,room['hint_levels'].get(viewer,0)))""",'manual hints')
server=repl(server,"'category_label': LABELS.get(room['category'],room['category']), 'bottle':room['bottle'],","'category_label': LABELS.get(room['category'],room['category']), 'bottle':room['bottle'], 'adult_mode':room['adult_mode'],",'present adult')
server=repl(server,"state['question']={'id':q['id'],'text':q['text']}","state['question']={'id':q['id'],'text':q['text']}\n        if q.get('image'):\n            state['question']['image']=q['image']\n            state['question']['image_alt']=q.get('image_alt','Bu soruya ait özgün illüstrasyon.')",'present image')
server=repl(server,"idx=current_hint_index(room) if room['phase']=='question' else 2","idx=current_hint_index(room,viewer) if room['phase']=='question' else 2",'viewer hints')
server=repl(server,"room['votes']={};room['phase']='question';room['start_at']=time.time();room['last_hint']=0","room['votes']={};room['hint_levels']={};room['phase']='question';room['start_at']=time.time()",'start hints')
server=repl(server,"""                elif room['phase']=='question' and room['mode']=='trivia':
                    idx=current_hint_index(room)
                    if idx!=room.get('last_hint'):
                        room['last_hint']=idx
                        to_send.append(room)
""","",'remove auto hints')
server=repl(server,"""        room=new_room(profile,ws,str(data.get('mode','kim_daha')),str(data.get('category','KIM_DAHA')),
                      data.get('max_players',4),str(data.get('bottle','digital')))""","""        room=new_room(profile,ws,str(data.get('mode','kim_daha')),str(data.get('category','KIM_DAHA')),
                      data.get('max_players',4),str(data.get('bottle','digital')),bool(data.get('adult_mode',False)))""",'room construct')
server=repl(server,"""    if action=='ready':
        if room['phase']!='lobby':raise ValueError('Oyun başladı.')
        room['players'][pid]['ready']=bool(data.get('ready'))""","""    if action=='ready':
        if room['phase']!='lobby':raise ValueError('Oyun başladı.')
        ready=bool(data.get('ready'))
        if ready and room['adult_mode'] and data.get('age_confirmed') is not True:
            raise ValueError('Yetişkin modu için 18 yaşını doldurduğunu onaylaman gerekir.')
        room['players'][pid]['age_confirmed']=bool(data.get('age_confirmed')) if ready else False
        room['players'][pid]['ready']=ready""",'age ready')
server=repl(server,"""    elif action=='answer':
        if room['phase']!='question' or time.time()>=room['deadline']:raise ValueError('Bu turun süresi doldu.')""","""    elif action=='hint':
        if room['mode']!='trivia' or room['phase']!='question' or time.time()>=room['deadline']:
            raise ValueError('Şu anda yeni ipucu alamazsın.')
        if pid in room['votes']:raise ValueError('Cevap verdikten sonra ipucu alınamaz.')
        if current_hint_index(room,pid)>=2:raise ValueError('Tüm ipuçlarını açtın.')
        room['hint_levels'][pid]=current_hint_index(room,pid)+1
    elif action=='answer':
        if room['phase']!='question' or time.time()>=room['deadline']:raise ValueError('Bu turun süresi doldu.')""",'hint action')
server=repl(server,"            if target==pid:raise ValueError('Kendine oy veremezsin.')\n","",'self voting')
server=repl(server,"            idx=current_hint_index(room)\n", "            idx=current_hint_index(room,pid)\n",'score hints')
server_path.write_text(server,'utf-8')

js=js_path.read_text('utf-8')
js=repl(js,"offset:0};","offset:0,adult_mode:false};",'adult UI state')
js=repl(js,"function chooseBottle(){return S.mode==='truth_dare'?","function chooseBottle(){return S.mode==='truth_dare'?",'choose bottle keep') if False else js
# Set separate toggle, no prechecked, only selected from room creation screen.
js=repl(js,"${modeChoices()}${chooseBottle()}<div class=\"divider\"></div><label class=\"label\">Oda kapasitesi</label>","${modeChoices()}${chooseBottle()}${adultModeChoice()}<div class=\"divider\"></div><label class=\"label\">Oda kapasitesi</label>",'adult config slot')
js=repl(js,"function chooseBottle(){return S.mode==='truth_dare'?", "function adultModeChoice(){return S.mode==='truth_dare'?`<div class=\"gap\"></div><button class=\"choice ${S.adult_mode?'chosen':''}\" data-action=\"adult_toggle\" type=\"button\"><span class=\"emoji\">🔞</span><span><strong>Yetişkinlere Özel (18+): ${S.adult_mode?'Açık':'Kapalı'}</strong><small>Gönüllü, imalı sohbet kartları. Yalnızca 18 yaşını dolduranlar seçmelidir.</small></span></button>`:''}\nfunction chooseBottle(){return S.mode==='truth_dare'?",'adult control function')
js=repl(js,"function roomParams(){return {mode:S.mode,category:S.category,bottle:S.bottle,max_players:S.cap}}", "function roomParams(){return {mode:S.mode,category:S.category,bottle:S.bottle,max_players:S.cap,adult_mode:S.mode==='truth_dare'&&S.adult_mode}}",'room adult payload')
js=repl(js," if(['mode','avatar','bottle'].includes(a))", " if(a==='adult_toggle'){S.adult_mode=!S.adult_mode;render();return}\n if(['mode','avatar','bottle'].includes(a))",'adult click')
js=repl(js,"send('ready',{ready:!me?.ready});return", "send('ready',{ready:!me?.ready,age_confirmed:!me?.ready && S.room.adult_mode?window.confirm('18 yaşını doldurduğunu ve yetişkinlere yönelik sohbet içeriğini gönüllü olarak seçtiğini onaylıyor musun?'):!S.room.adult_mode});return",'age ready payload')
js=repl(js,"${btn(my?.ready?'HAZIRLIĞI KALDIR':'BEN HAZIRIM ✅','toggle_ready'", "${r.adult_mode?'<div class=\"status warn\">🔞 18+ oda: Yetişkin olduğunu beyan ederek ve gönüllü olarak katılabilirsin. Pas geçmek serbesttir.</div>':''}${btn(my?.ready?'HAZIRLIĞI KALDIR':'BEN HAZIRIM ✅','toggle_ready'",'ready 18 statement')
js=repl(js,"choices=r.players.filter(p=>p.id!==r.my_id).map", "choices=r.players.map",'self vote button')
js=repl(js,"${escapeHtml(p.avatar)} ${escapeHtml(p.nickname)}</button>`).join('')+", "${escapeHtml(p.avatar)} ${escapeHtml(p.nickname)}${p.id===r.my_id?' (Ben)':''}</button>`).join('')+",'self vote label')
js=repl(js,"""choices=`<div class="panel">${(q.hints||[]).map((h,i)=>`<div class="small" style="margin:6px 0;color:#f9d2f0">💡 ${i+1}. ${escapeHtml(h)}</div>`).join('')}</div><div class="cols2">${(q.options||[]).map(a=>`<button class="answer ${S.selected===a?'sel':''}" data-action="pick" data-value="${escapeHtml(a)}" ${r.my_answer?'disabled':''}>${escapeHtml(a)}</button>`).join('')}</div>${btn(r.my_answer?'CEVABIN GÖNDERİLDİ ✓':'CEVABIMI GÖNDER','answer','btn',!S.selected||!!r.my_answer)}`;""","""choices=`<div class="panel"><div class="small" style="color:#f9d2f0">${(q.hints||[]).map((h,i)=>`<div class="quiz-hint">💡 ${i+1}. ipucu: ${escapeHtml(h)}</div>`).join('')}</div>${btn((q.hints||[]).length>=3?'TÜM İPUÇLARI AÇILDI':'💡 İPUCU AL · Yeni bilgi göster','hint','btn secondary',(q.hints||[]).length>=3||!!r.my_answer)}</div><div class="cols2">${(q.options||[]).map((a,i)=>`<button class="answer ${S.selected===a?'sel':''}" data-action="pick" data-value="${escapeHtml(a)}" ${r.my_answer?'disabled':''}><strong>${'ABCD'[i]}.</strong> ${escapeHtml(a)}</button>`).join('')}</div>${btn(r.my_answer?'CEVABIN GÖNDERİLDİ ✓':'CEVABIMI GÖNDER','answer','btn',!S.selected||!!r.my_answer)}`;""",'trivia UI')
js=repl(js," if(a==='answer'){if(!S.selected", " if(a==='hint'){send('hint');return}\n if(a==='answer'){if(!S.selected",'hint click')
js=repl(js,"<h2>${escapeHtml(q.text||'Soru hazırlanıyor...')}</h2></div>", "<h2>${escapeHtml(q.text||'Soru hazırlanıyor...')}</h2>${q.image?`<img class=\"quiz-art\" src=\"${escapeHtml(q.image)}\" alt=\"${escapeHtml(q.image_alt||'Özgün soru illüstrasyonu')}\" loading=\"eager\"/>`:''}</div>",'quiz art render')
js=repl(js,"${r.mode==='trivia'?`Bu ipucunda doğru cevap: ${escapeHtml(q.available_points||40)} maç puanı. `:''}", "${r.mode==='trivia'?`Yanıt verirsen kazanabileceğin puan: <strong>${escapeHtml(q.available_points||40)}</strong>. Dört şık her zaman görünür; ipucu alırsan yeni bilgi eklenir. `:''}",'points label')
js=repl(js,"</style></head>", ".quiz-art{display:block;width:100%;height:220px;object-fit:cover;border-radius:17px;border:1px solid #8c468c;margin:14px auto 0;max-width:390px}.quiz-hint{padding:9px 0;border-bottom:1px solid #74498188;line-height:1.5}.quiz-hint:last-child{border-bottom:0}@media(max-width:350px){.quiz-art{height:175px}}\n</style></head>",'quiz art css')
js_path.write_text(js,'utf-8')
print('Patched server and online interface')
