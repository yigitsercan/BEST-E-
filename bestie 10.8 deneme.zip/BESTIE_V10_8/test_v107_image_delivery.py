"""End-to-end image transport checks, using ASGI HTTP stack (no external hosting)."""
import asyncio
import json
import unittest
from pathlib import Path
import httpx
import server

ROOT=Path(__file__).resolve().parent

class ImageDeliveryTests(unittest.TestCase):
    def test_online_offline_render_fallbacks(self):
        online=(ROOT/'static'/'bestie.js').read_text(encoding='utf-8')
        offline=(ROOT/'static'/'Bestie_V10_Cevrimdisi.html').read_text(encoding='utf-8')
        self.assertIn('questionArt(q.image',online)
        self.assertIn("addEventListener('error'",online)
        self.assertIn('picture-error',offline)
        self.assertIn("addEventListener('error'",offline)

    def test_entire_illustration_catalog_via_http(self):
        cards=[q for deck in server.QUESTIONS['trivia'].values() for q in deck if q.get('image')]
        self.assertEqual(len(cards),1442)
        async def run():
            transport=httpx.ASGITransport(app=server.app)
            async with httpx.AsyncClient(transport=transport,base_url='http://testserver',timeout=10) as client:
                for q in cards:
                    r=await client.get(q['image'])
                    self.assertEqual(r.status_code,200,(q['id'],q['image'],r.status_code))
                    self.assertTrue(r.headers['content-type'].startswith(('image/svg+xml','image/webp','image/png','image/jpeg')),(q['id'],r.headers['content-type']))
                    self.assertGreater(len(r.content),30,q['id'])
        asyncio.run(run())

if __name__=='__main__': unittest.main()
