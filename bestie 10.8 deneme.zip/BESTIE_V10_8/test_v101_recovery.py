"""Isolated test for account recovery code rotation and single-use semantics."""
import asyncio
import os
import sqlite3
import tempfile
from pathlib import Path

with tempfile.TemporaryDirectory() as tmp:
    os.environ['BESTIE_DB_PATH'] = str(Path(tmp) / 'test.sqlite3')
    import server

    pid = 'test-profile'
    with sqlite3.connect(server.DB_PATH) as db:
        db.execute('INSERT INTO profiles VALUES (?,?,?,?,?)', (pid,'old-secret-'+'x'*55,'Test','😎',90))

    first = server.create_recovery_code(pid)
    with sqlite3.connect(server.DB_PATH) as db:
        stored = db.execute('SELECT code_hash FROM recovery_codes WHERE profile_id=?',(pid,)).fetchone()[0]
    assert first not in stored and len(first) >= 40
    second = server.create_recovery_code(pid)
    assert first != second
    assert server.redeem_recovery_code(first) is None, 'replaced code must be invalid'
    assert server.redeem_recovery_code('bad') is None
    recovered = server.redeem_recovery_code(second)
    assert recovered is not None and recovered['id'] == pid and recovered['kp'] == 90
    assert recovered['secret'] != 'old-secret-'+'x'*55
    assert server.redeem_recovery_code(second) is None, 'recovery is single-use'
    with sqlite3.connect(server.DB_PATH) as db:
        persisted = db.execute('SELECT secret FROM profiles WHERE id=?',(pid,)).fetchone()[0]
    assert persisted == recovered['secret']
    third = server.create_recovery_code(pid)
    class Socket:
        def __init__(self): self.messages = []
        async def send_json(self,msg): self.messages.append(msg)
        async def close(self,**kw): self.messages.append({'closed':True})
    sock = Socket()
    asyncio.run(server.process(sock, {'action':'recover_account','data':{'code':third}}))
    assert any(x.get('type')=='profile' for x in sock.messages)
    assert any(x.get('type')=='recovery_success' for x in sock.messages)
    assert server.SOCKETS[sock]['profile']['id']==pid
    assert server.redeem_recovery_code(third) is None
    asyncio.run(server.process(sock, {'action':'delete_profile','data':{}}))
    with sqlite3.connect(server.DB_PATH) as db:
        assert db.execute('SELECT COUNT(*) FROM recovery_codes WHERE profile_id=?',(pid,)).fetchone()[0] == 0
        assert db.execute('SELECT COUNT(*) FROM profiles WHERE id=?',(pid,)).fetchone()[0] == 0
    print('PASS V10.1: recovery code rotation, hashed storage, single-use, session refresh, deletion')
