"""Run deterministic tests that do not require a separately running server."""
from pathlib import Path
import subprocess
import sys

root=Path(__file__).resolve().parent
tests=sorted(p.name for p in root.glob('test_*.py') if p.name not in {'test_realtime.py','test_v104_concurrency.py'})
fail=[]
for file in tests:
    print(f'\n=== {file} ===',flush=True)
    result=subprocess.run([sys.executable,file],cwd=root,timeout=90)
    if result.returncode:fail.append(file)
print(f'\nRESULT: {len(tests)-len(fail)}/{len(tests)} passed')
if fail:print('FAILED: '+', '.join(fail));raise SystemExit(1)
