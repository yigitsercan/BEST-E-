"""V9.5 targeted regression tests: origin restrictions, creation throttling, room expiration."""
import asyncio
import os
import sqlite3
import tempfile
import time
import uuid
from pathlib import Path
with tempfile.TemporaryDirectory() as work:
    os.environ['BESTIE_DB_PATH']=str(Path(work)/'profiles.sqlite3')
    import server
    assert server.MAX_NEW_ROOMS_PER_HOUR == 20, 'Varsayılan saatlik oda sınırı 20 olmalı'
    assert server.same_origin_or_nonbrowser('https://bestie.example','bestie.example')
    assert server.same_origin_or_nonbrowser('http://localhost:8899','localhost:8899')
    assert server.same_origin_or_nonbrowser(None,'bestie.example')
    for origin in ('https://attacker.example','https://bestie.example.evil','null','file:///', 'https://bestie.example:81'):
        assert not server.same_origin_or_nonbrowser(origin,'bestie.example'),origin
    print('PASS websocket foreign browser origin rejection')
    class WS:
        def __init__(self):self.sent=[]
        async def send_json(self,obj):self.sent.append(obj)
        async def close(self,**kw):pass
    pid=uuid.uuid4().hex
    prof={'id':pid,'nickname':'Oyuncu','avatar':'😎','kp':0}
    with sqlite3.connect(server.DB_PATH) as db:
        db.execute('INSERT INTO profiles VALUES (?,?,?,?,?)',(pid,'test-secret','Oyuncu','😎',0))
    rooms=[]
    for _ in range(server.MAX_NEW_ROOMS_PER_HOUR):
        rooms.append(server.new_room(prof,WS(),'trivia','history',2))
    assert not server.creation_allowed(pid)
    try:server.new_room(prof,WS(),'trivia','history',2)
    except ValueError as exc:assert 'Çok fazla oda' in str(exc)
    else:raise AssertionError('Creation throttle missing')
    print('PASS profile room creation throttle')
    room=rooms[0]
    ws=room['players'][pid]['ws']
    room['touched']=time.time()-server.ROOM_MAX_IDLE-100
    async def expire():
        task=asyncio.create_task(server.room_ticker())
        await asyncio.sleep(.65)
        task.cancel()
        try:await task
        except asyncio.CancelledError:pass
    asyncio.run(expire())
    assert room['code'] not in server.ROOMS
    assert server.SOCKETS[ws]['room'] is None
    assert any(item['type']=='left' for item in ws.sent)
    print('PASS expired room releases client membership')
