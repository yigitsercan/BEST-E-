# Bestie? V9.1 — Beş İpucu Hakkı

## Uygulanan kural
- 10 soruluk her **Tahmin Et!** oyununda toplam 5 ek ipucu hakkı.
- Başlangıçtaki birinci bilgi ücretsiz; her ek bilgi bir hak tüketir.
- Tek soru başına en çok 2 ek bilgi.
- İpucusuz doğru cevap: 100 maç puanı; 1 ek bilgi: 70 puan; 2 ek bilgi: 40 puan.
- Kullanılmayan haklar sonraki sorulara devreder; yeni maçta sıfırlanıp 5'e çıkar.
- Çevrimiçi çok oyunculu modda haklar oyuncu başına ayrıdır ve sunucu tarafından doğrulanır.
- Çevrimdışı tekli oyunda kişisel, aynı cihazdaki grup oyununda ortak 5 hak vardır.

## Testler
- Sunucu testi: `python test_hint_budget.py`
- Oyun kuralları testi: `python test_rules.py`
- Tarayıcı JS sözdizimi: Node.js ile kontrol edildi.

## Durum
İşlev yerel kaynak paketi üzerinde güncellendi. Canlı site henüz bu paketle yeniden yayımlanmadı. Soru hedefleri: 7.500 toplam / 2.500 resimli. V9 kalite raporundaki mevcut içerik sayıları bu hedefin altındadır.
