# BESTIE? V9.7 — Yapılanlar, testler ve açık işler

## Bu sürümde gerçekleştirilenler
- **Oyuncu bildirimi:** Aynı odadaki başka bir oyuncu hakaret, taciz, uygunsuz içerik, hile veya diğer sebebiyle bildirilebilir. Şikâyet SQLite `player_reports` tablosunda tutulur, oyuncu başına günlük 5 rapor limiti vardır. Otomatik uzaklaştırma/engelleme **yoktur**; manuel inceleme süreci henüz kurulmalıdır.
- **Profil silme:** Oyuncu profili ekranında iki aşamalı silme onayı; profil, KP ve ilgili şikâyet kayıtları veritabanından silinir. Aktif odadayken hesap silme reddedilir. Tarayıcıdaki profil anahtarı kaldırılır. **Yedekleme, altyapı sağlayıcı günlükleri ve üçüncü taraf verileri ayrı değerlendirme gerektirir.**
- **Takma ad temizleme:** Kontrol karakterleri ve bazı görünmez/yön değiştirme karakterleri engellenir; profesyonel moderasyonun yerine geçmez.
- **Oda sınırı:** Oyuncu başına son 60 dakikada 20 yeni oda ve toplam 500 aktif oda varsayılan değerleri korunur.
- **Oyun kuralları:** 10 tur, beş ipucu, 100/70/40 puan ve maç başına en fazla üç görsel soru korunmuştur.

## Çalıştırılan yerel testler
- `python test_rules.py` — geçti
- `python test_hint_budget.py` — geçti
- `python test_content_quality.py` — 1.650 simülasyon, yapısal doğrulama geçti
- `python test_v95_hardening.py` — geçti
- `python test_v97_privacy_reports.py` — geçti
- `node` ile HTML içindeki JavaScript söz dizimi — geçti
- `python test_realtime.py` — yerel sunucuda geçti

## Yayına alınmadan önce mutlaka çözülmesi gerekenler
1. **Kalıcı gerçek zamanlı altyapı:** Odalar ve oda yaratma limiti tek işlem belleğindedir. Çoklu worker, sunucu yeniden başlatma, kapasite ve altyapı geçişi için Redis/PostgreSQL gibi kalıcı/dağıtık state gereklidir.
2. **Kalıcı, güvenli kimlik:** SQLite verisinin Render Free geçici diskte kaybolma riski vardır. Gerçek Auth, kullanıcı hesap kurtarma, oturum güvenliği ve veritabanı yedekleri gereklidir.
3. **Moderasyon operasyonu:** Şikâyetler toplanıyor, ama yönetici paneli, şikâyet inceleme politikası, engelleme/ban ve acil güvenlik müdahalesi YOK.
4. **Çocuk ve yetişkin koruması:** 18+ beyana dayalıdır; yaşa uygunluk, genç kullanıcılar için kısıtlar ve politika incelemesi gereklidir.
5. **KVKK ve hukuki süreç:** Hukukçu onaylı aydınlatma, saklama süreleri, kullanıcı hakları başvuru süreci ve olay müdahale planı gerekli. Hesap silme özelliği tek başına KVKK uyumu anlamına gelmez.
6. **Soru editörlüğü ve telif:** 3.500 trivia kartı yalnızca 743 kategori/cevap eşleşmesini kapsar; 1.442 resimli kartın çoğu vektörel ipucudur. Factual doğrulama ve görsel hak incelemesi tamamlanmadı.
7. **Offline sürüm:** `/offline` eski V6 sürümüdür ve canlı V9.7 özelliklerini yansıtmaz.
8. **Ürün & viral büyüme:** Resimli sonuç paylaşımı, gerçek günlük görevler, arkadaş sıralaması, analitik, gerçek cihaz/erişilebilirlik testi ve 100–300 kişilik beta henüz yapılmadı.
9. **Altyapı güvenliği:** Origin denetimi tek başına auth değildir, rate-limit tek worker RAM'dedir; gerçek yük, sızma ve abuse testleri gerekiyor.

**Bu paket çalışan prototip iyileştirmesidir; yayın onayı veya tüm yasal risklerin giderildiği anlamına gelmez.**
