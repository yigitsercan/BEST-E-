"""Tahmin Et! 10 turluk oyunda oyuncu başına 5 ipucu ve tur başına 2 ipucu testi."""
import asyncio
import os
import sqlite3
import tempfile
import uuid
from pathlib import Path

async def run():
    with tempfile.TemporaryDirectory() as temp:
        os.environ['BESTIE_DB_PATH']=str(Path(temp)/'test.sqlite3')
        import server

        class FakeWS:
            def __init__(self): self.out=[]
            async def send_json(self,obj): self.out.append(obj)
            async def close(self,**kwargs): pass

        player=[];ws=[]
        for i in range(2):
            pid=uuid.uuid4().hex
            data={'id':pid,'secret':uuid.uuid4().hex+uuid.uuid4().hex,
                  'nickname':f'Kontrol {i+1}','avatar':'😎','kp':0}
            with sqlite3.connect(server.DB_PATH) as con:
                con.execute('INSERT INTO profiles VALUES (?,?,?,?,?)',
                    (pid,data['secret'],data['nickname'],data['avatar'],0))
            player.append(data);ws.append(FakeWS())

        room=server.new_room(player[0],ws[0],'trivia','footballer',2)
        server.attach(room,player[1],ws[1])
        server.start_round(room)

        async def hint(k):
            await server.process(ws[k],{'action':'hint','data':{}})
        assert server.present(room,player[0]['id'])['hint_remaining']==5
        assert len(server.present(room,player[0]['id'])['question']['hints'])==1
        await hint(0)
        assert server.present(room,player[0]['id'])['hint_remaining']==4
        assert server.present(room,player[0]['id'])['question']['available_points']==70
        await hint(0)
        assert server.present(room,player[0]['id'])['hint_remaining']==3
        assert server.present(room,player[0]['id'])['question']['available_points']==40
        try:
            await hint(0)
            raise AssertionError('Üçüncü ipucu aynı soruda reddedilmeliydi.')
        except ValueError as err:
            assert 'Bu sorudaki' in str(err)
        assert server.present(room,player[1]['id'])['hint_remaining']==5

        server.finish_round(room);room['index']+=1;server.start_round(room)
        assert server.present(room,player[0]['id'])['hint_remaining']==3
        await hint(0);await hint(0)
        assert server.present(room,player[0]['id'])['hint_remaining']==1

        server.finish_round(room);room['index']+=1;server.start_round(room)
        await hint(0)
        assert server.present(room,player[0]['id'])['hint_remaining']==0
        assert server.present(room,player[0]['id'])['question']['available_points']==70
        try:
            await hint(0)
            raise AssertionError('Altıncı ipucu reddedilmeliydi.')
        except ValueError as err:
            assert '5 ipucu' in str(err)
        assert room['hints_used'][player[0]['id']]==5
        assert server.present(room,player[1]['id'])['hint_remaining']==5
        await hint(1)
        assert server.present(room,player[1]['id'])['hint_remaining']==4
        print('PASS: 10 turda kişi başı 5 ipucu, tur başına 2, bağımsız sayaç, 100/70/40')

if __name__=='__main__':
    asyncio.run(run())
