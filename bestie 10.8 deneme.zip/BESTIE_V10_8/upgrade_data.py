from pathlib import Path
import json, random, re, math, collections
from PIL import Image,ImageDraw,ImageFont,ImageEnhance,ImageFilter
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
ROOT=Path(__file__).parent
p=ROOT/'data'/'questions.json';data=json.loads(p.read_text('utf-8'))

# A stronger distractor is another plausible answer from the same subject,
# selected by semantic similarity of existing factual clues. Always retain
# exactly one correct answer; no fabricated facts are added.
for category,questions in data['trivia'].items():
    by_entity={}
    for q in questions:
        if q['entity'] not in by_entity:by_entity[q['entity']]=q
    names=list(by_entity)
    corpus=[]
    for name in names:
        hints=by_entity[name]['hints']
        text=' '.join(hints[:2])
        corpus.append(text)
    matrix=TfidfVectorizer(ngram_range=(1,2), analyzer='word',strip_accents='unicode',min_df=1).fit_transform(corpus)
    similarity=cosine_similarity(matrix)
    ranks={}
    for i,name in enumerate(names):
        # Similarity > 0; when no shared facts exist fall back to same category.
        others=[(j,round(float(similarity[i,j]),6)) for j in range(len(names)) if j!=i]
        others.sort(key=lambda a:(-a[1],abs(a[0]-i),a[0]))
        ranks[name]=[names[j] for j,_ in others]
    for q in questions:
        distractors=ranks[q['entity']][:3]
        options=[q['entity']]+distractors
        assert len(options)==4 and len(set(options))==4
        rng=random.Random(str(q['id']))
        rng.shuffle(options)
        q['options']=options
        q['difficulty']='orta-zor' if category in ('footballer','footballclub','basketballer','basketballclub','volleyballer','volleyballclub') else 'zor'
        q['editorial_status']='taslak - doğruluk ve ayırt edicilik kontrolü gerekli'

# Newly drafted 18+ conversational cards. They ask, not compel; participation
# and any interaction always require each person's voluntary consent.
truths=[
"Birinde romantik çekim hissettiğini ilk hangi davranışından anlarsın?",
"Flört ederken söylediğin en cesur ama sonradan utandığın cümle neydi?",
"Bir ilişkide öpüşme konusunda seni en rahat hissettiren şey nedir?",
"Şu ana kadar yaşadığın en beklenmedik romantik yakınlaşma neydi? Anlatmak istemezsen pas geç.",
"İlişkide tensel yakınlık hakkında konuşmak sana kolay mı, zor mu gelir?",
"Birinin sana çekici geldiğini belli etmek için yaptığın en belirgin hareket ne?",
"Bir flörtünün sana sorduğu en cesur soru neydi?",
"İlişkilerde fiziksel çekim mi, duygusal yakınlık mı senin için daha belirleyici?",
"Romantik bir ortamda kulağına fısıldanmasını isteyeceğin bir cümle var mı?",
"Bir ilişkide yakınlaşmadan önce mutlaka konuşmak istediğin sınır nedir?",
"Karşılıklı çekimi hissettiğin bir anı paylaşmak ister misin?",
"Birini ilk kez öpmeye karar verirken seni en çok ne etkiler?",
"Seni en çok etkileyen flört iltifatı hangisiydi?",
"Gizli bir hoşlantını itiraf etmen için hangi koşulların oluşması gerekir?",
"Bir flörtünle yaşadığın en heyecanlı göz göze gelme anı neydi?",
"Bir ilişkide kişisel alan ve fiziksel yakınlık dengesini nasıl kurarsın?",
"Partnerinle cinsellik hakkında dürüstçe konuşmayı önemli buluyor musun? Neden?",
"Seni en çok utandıran romantik yanlış anlaşılma neydi?",
"Romantik bir gecede seni en çok etkileyen atmosfer nasıl olur?",
"Birinden hoşlandığını arkadaşlarından gizlediğin oldu mu?",
"Flörtleşirken hiç yanlış kişiye iddialı bir mesaj gönderdiğin oldu mu?",
"Bir ilişkide kıskançlığı açıkça konuşmak için en iyi yol sence nedir?",
"Yetişkin bir ilişkide karşılıklı rıza hakkında konuşmak sana ne hissettiriyor?",
"Birinin çekici olduğunu ilk bakışta düşünmene sebep olan şey genellikle nedir?",
"Özel hayatınla ilgili hangi konuların yalnızca sana ait kalmasını istersin?"
]
dares=[
"Tamamen hayalî birine yönelik iddialı bir flört cümlesi kur.",
"Karşında biri varmış gibi, çekici bulduğun bir özelliğe zarif bir iltifat et.",
"En etkileyici romantik film repliğini kendi sözlerinle yeniden oluştur.",
"Bir yakınlaşmada rızayı nasıl soracağını canlandır; kimseye dokunman gerekmiyor.",
"Hayalî bir flört uygulaması biyografisi yaz ve yüksek sesle oku.",
"Birinin dikkatini çekmek için kullanabileceğin üç nazik ama cesur cümle söyle.",
"Gruptan gönüllü bir kişiyle beş saniye göz teması kur; ikinizden biri istemezse pas geçin.",
"Telefonuna göndermeyeceğin, tamamen kurmaca bir romantik mesaj yaz.",
"Bir aşk filmindeki klişe tanışma sahnesini komik biçimde canlandır.",
"Gönüllü bir kişiyle yalnızca sözlü olarak kısa bir flört diyaloğu canlandırın.",
"Birini övmek için üç özgün cümle bul; isim vermek zorunda değilsin.",
"Kendi hayatının romantik komedisinin tanıtım konuşmasını yap.",
"Çekici bulduğun bir davranışı, kimsenin adını söylemeden anlat.",
"Bir buluşmaya davet cümlesini ciddi, utangaç ve esprili üç farklı tonda söyle.",
"Sana göre romantik bir buluşma için üç şarkı adı söyle.",
"Gruptaki kimseyi hedef göstermeden komik bir kıskançlık sahnesi canlandır.",
"Kurmaca bir çiftin ilk tanışmasına ilişkin üç cümlelik bir hikâye uydur.",
"Reddedilmeye saygı gösteren örnek bir flört diyaloğu canlandır.",
"Bir romantik itirafı yalnızca mimiklerinle anlat; sonra istersen açıkla.",
"Bir flört mesajına üç farklı, karşı tarafın sınırlarına saygılı yanıt üret.",
"En yaratıcı 'ilk buluşma' planını 20 saniyede anlat.",
"Romantik bir dizinin fragmanını sesinle canlandır.",
"Gönüllü bir arkadaşınla randevu planını konuşuyormuş gibi rol yap.",
"Kendine gönderilmiş hayalî bir iltifata en komik cevabı ver.",
"Dört satırlık, tamamen özgün ve imalı ama saygılı bir aşk şiiri yaz."
]
data['truth_dare']['adult_truth']=[{'id':f'AD-{i:03d}','text':x,'age_min':18,'editorial_status':'taslak'} for i,x in enumerate(truths,1)]
data['truth_dare']['adult_dare']=[{'id':f'AC-{i:03d}','text':x,'age_min':18,'editorial_status':'taslak','requires_consent':True} for i,x in enumerate(dares,1)]

# Start the original, explicitly licensed illustration workflow (NOT scraped
# celebrities, team crests, posters, copyrighted footage or album artwork).
source=Path('/mnt/data/a_cinematic_neon_lit_illustration_collage_in_a_5x.png')
if not source.exists():
    matches=list(Path('/mnt/data').glob('*cinematic*illustration*collage*.png'))
    source=matches[0] if matches else None
if source:
    sheet=Image.open(source).convert('RGB')
    print('image sheet',sheet.size)
    out=ROOT/'static'/'trivia-img';out.mkdir(exist_ok=True)
    categories=list(data['trivia'])
    font_path='/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf'
    try:
        font_small=ImageFont.truetype(font_path,24)
        font_title=ImageFont.truetype(font_path,32)
    except OSError:
        font_small=ImageFont.load_default();font_title=font_small
    for col,category in enumerate(categories):
        # One of ten theme visuals, purposefully generic and independently created.
        sx=col%5;sy=col//5;w,h=sheet.size
        art=sheet.crop((round(sx*w/5),round(sy*h/2),round((sx+1)*w/5),round((sy+1)*h/2)))
        q_by_entity={}
        for q in data['trivia'][category]:
            if q['entity'] not in q_by_entity:q_by_entity[q['entity']]=q
        for n,q in enumerate(list(q_by_entity.values())[:3],1):
            canvas=art.resize((640,410),Image.Resampling.LANCZOS)
            overlay=Image.new('RGBA',canvas.size,(0,0,0,0))
            d=ImageDraw.Draw(overlay)
            d.rounded_rectangle((20,267,620,390),radius=19,fill=(15,9,30,208),outline=(255,125,215,130),width=2)
            d.text((40,281),'GÖRSEL KART · İPUCU',font=font_small,fill=(255,177,230))
            hint=q['hints'][0]
            # Preserve Turkish Unicode and avoid truncating the clue silently.
            lines=[];line=''
            for word in hint.split():
                if d.textbbox((0,0),(line+' '+word).strip(),font=font_small)[2] > 545:
                    lines.append(line);line=word
                else: line=(line+' '+word).strip()
            if line:lines.append(line)
            for k,line in enumerate(lines[:2]):d.text((40,315+k*31),line,font=font_small,fill=(255,255,255))
            canvas=Image.alpha_composite(canvas.convert('RGBA'),overlay).convert('RGB')
            filename=f'{category}-{n:02d}.webp'
            canvas.save(out/filename,'WEBP',quality=85)
            q['image']=f'/static/trivia-img/{filename}'
            q['image_alt']='Oyun için üretilmiş özgün, tematik illüstrasyon ve birinci bilgi ipucu.'
            q['visual_rights']='original_generated_artwork'
            q['visual_source']='Bestie? özgün illüstrasyon paketi; üçüncü taraf fotoğrafı değildir.'

p.write_text(json.dumps(data,ensure_ascii=False,separators=(',',':')),'utf-8')
counts={k:{'total':len(v),'illustrated':sum(bool(q.get('image')) for q in v),'distinct_answers':len({q['entity'].casefold() for q in v})} for k,v in data['trivia'].items()}
report={'current_counts':counts,'target_per_category':750,'target_illustrated_per_category':250,'target_total':7500,'target_illustrated_total':2500,'currently_total':sum(x['total'] for x in counts.values()),'currently_illustrated':sum(x['illustrated'] for x in counts.values()),'adult_truth':len(truths),'adult_dare':len(dares),'important_note':'Hedef sayıların tümü henüz tamamlanmadı; görseller özgün tematik illüstrasyonlardır, gerçek kişi fotoğrafı veya kurum arması değildir. Mevcut soru bilgileri yayın öncesi denetlenmelidir.'}
(ROOT/'KALITE_RAPORU.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),'utf-8')
for k,v in counts.items():print(k,v)
