"""Conservative pre-release checks; report cannot substitute for human verification."""
import json
import os
import secrets
from pathlib import Path

root=Path(__file__).resolve().parent
checks=[]

def check(name, passed, detail, critical=True):
    checks.append({'check':name,'pass':bool(passed),'detail':detail,'critical':critical})

admin=os.environ.get('BESTIE_ADMIN_TOKEN','')
check('Admin credential configured', len(admin)>=32 and len(set(admin))>=12,
      'A non-trivial random administrator token (at least 32 characters) must be configured on the server.')
check('Single server process configured',os.environ.get('BESTIE_DEPLOY_MODE')=='single-process',
      'Exactly one process and one instance are supported by current room state implementation.')
questions_path=Path(os.environ.get('BESTIE_QUESTIONS_PATH',str(root/'content/questions.json' if (root/'content/questions.json').exists() else root/'data/questions.json')))
try:
    questions=json.loads(questions_path.read_text(encoding='utf-8'))
    trivia=questions.get('trivia',{})
    cards=sum(len(group) for group in trivia.values())
    valid=cards==3500 and len(trivia)==10
except (OSError,ValueError,TypeError) as ex:
    valid=False;cards=0
check('Bundled content loads',valid,f'{cards} trivia cards; expected 3,500 across 10 categories. Source: {questions_path}')
manifest=root/'static/manifest.webmanifest'
try:
    m=json.loads(manifest.read_text(encoding='utf-8'))
    icons_ok=all((root/x['src'].lstrip('/')).is_file() for x in m.get('icons',[])) and len(m.get('icons',[]))>=2
except (OSError,ValueError,KeyError,TypeError):icons_ok=False
check('Mobile web manifest icons exist',icons_ok,'PNG icons for common 192 and 512 sizes.')
check('Persistent disk verified in hosting platform',False,
      'Verify with a deployed service and DB write/read through an actual restart.')
check('HTTPS + WSS live round trip',False,'Requires an actual accessible HTTPS deployment and two clients.')
check('Content source + image-license audit',False,'3,500 cards and image rights require independent review.')
check('Privacy, minors, and legal approval',False,'Must be reviewed for the intended release audience and jurisdiction.')
check('Real-device and beta tests',False,'Requires real Android/iOS devices and external beta participants.')
report={'version':'V10.5','ready_for_public_launch':all(c['pass'] for c in checks if c['critical']),
'checks':checks,'note':'Unverified external conditions deliberately fail closed. Do not turn these into environment-variable approvals.'}
report_path=Path(os.environ.get('BESTIE_PREFLIGHT_REPORT',str(root/'PREFLIGHT_REPORT.json')))
report_path.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for row in checks:
    print(('PASS' if row['pass'] else 'BLOCK')+' '+row['check'])
print('PUBLIC LAUNCH READY:',report['ready_for_public_launch'])
