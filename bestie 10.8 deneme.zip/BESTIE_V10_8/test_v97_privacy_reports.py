"""V9.7 reports and account deletion regression tests using isolated DB."""
import asyncio
import os
import tempfile
from pathlib import Path

async def main():
    with tempfile.TemporaryDirectory() as d:
        os.environ['BESTIE_DB_PATH']=str(Path(d)/'db.sqlite3')
        import server
        class WS:
            def __init__(self):self.sent=[]
            async def send_json(self,p):self.sent.append(p)
            async def close(self,**kwargs):pass
        a,b=WS(),WS()
        await server.process(a,{'action':'init','data':{'nickname':'A'}})
        await server.process(b,{'action':'init','data':{'nickname':'B'}})
        pa=server.SOCKETS[a]['profile']['id'];pb=server.SOCKETS[b]['profile']['id']
        await server.process(a,{'action':'create','data':{'mode':'trivia','category':'history','max_players':2}})
        room=server.SOCKETS[a]['room']
        await server.process(b,{'action':'join','data':{'code':room}})
        await server.process(a,{'action':'report_player','data':{'target':pb,'reason':'taciz'}})
        assert a.sent[-1]['type']=='report_received'
        assert server.sql_one('SELECT reporter_id,target_id,reason FROM player_reports WHERE reporter_id=?',(pa,))['reason']=='taciz'
        try:await server.process(a,{'action':'report_player','data':{'target':pa,'reason':'taciz'}})
        except ValueError:pass
        else:raise AssertionError('self report accepted')
        for _ in range(4):await server.process(a,{'action':'report_player','data':{'target':pb,'reason':'diger'}})
        try:await server.process(a,{'action':'report_player','data':{'target':pb,'reason':'diger'}})
        except ValueError as err:assert 'Günlük' in str(err)
        else:raise AssertionError('report limit missing')
        try:await server.process(a,{'action':'delete_profile','data':{}})
        except ValueError as err:assert 'odadan' in str(err)
        else:raise AssertionError('deleted in active room')
        await server.process(a,{'action':'leave','data':{}})
        await server.process(a,{'action':'delete_profile','data':{}})
        assert a.sent[-1]['type']=='profile_deleted'
        assert server.profile_info(pa) is None
        assert server.sql_one('SELECT id FROM player_reports WHERE reporter_id=? OR target_id=?',(pa,pa)) is None
        assert a not in server.SOCKETS
        assert server.MAX_NEW_ROOMS_PER_HOUR==20
        print('PASS V9.7: report validation, rate limit, deletion and 20 rooms/hour')

if __name__=='__main__':asyncio.run(main())
