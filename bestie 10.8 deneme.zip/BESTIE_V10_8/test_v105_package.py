import json
from pathlib import Path
import struct
root=Path(__file__).resolve().parent
manifest=json.loads((root/'static/manifest.webmanifest').read_text(encoding='utf-8'))
for entry in manifest['icons']:
    path=root/entry['src'].lstrip('/')
    assert path.exists(),path
    expected=int(entry['sizes'].split('x')[0]);assert path.read_bytes()[:8]==b"\x89PNG\r\n\x1a\n"
    actual=struct.unpack(">II",path.read_bytes()[16:24])
    assert actual==(expected,expected),actual
assert 'apple-touch-icon' in (root/'static/index.html').read_text(encoding='utf-8')
assert 'plan: starter' in (root/'render.yaml').read_text(encoding='utf-8')
print('V10.5 package checks passed')
