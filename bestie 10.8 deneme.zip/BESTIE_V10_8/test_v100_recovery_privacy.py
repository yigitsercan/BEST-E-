"""V10: process restart room recovery, profile export, admin audit verification."""
import asyncio
import os
import tempfile
import time
from pathlib import Path

async def main():
    with tempfile.TemporaryDirectory() as d:
        os.environ['BESTIE_DB_PATH']=str(Path(d)/'test.sqlite3')
        os.environ['BESTIE_ADMIN_TOKEN']='unit-test-admin-key-not-for-production-123'
        import server
        import httpx
        class WS:
            def __init__(self):self.sent=[]
            async def send_json(self,obj):self.sent.append(obj)
            async def close(self,**kw):pass
        a,b=WS(),WS()
        await server.process(a,{'action':'init','data':{'nickname':'A'}})
        await server.process(b,{'action':'init','data':{'nickname':'B'}})
        pa=server.SOCKETS[a]['profile'];pb=server.SOCKETS[b]['profile']
        await server.process(a,{'action':'create','data':{'mode':'trivia','category':'history','max_players':2}})
        code=server.SOCKETS[a]['room']
        await server.process(b,{'action':'join','data':{'code':code}})
        await server.process(a,{'action':'ready','data':{'ready':True}})
        await server.process(b,{'action':'ready','data':{'ready':True}})
        await server.process(a,{'action':'start','data':{}})
        await server.process(a,{'action':'hint','data':{}})
        before=server.ROOMS[code]
        first_question=before['deck'][0]['id']
        assert before['hints_used'][pa['id']]==1
        assert not server.creation_allowed('unknown') is False
        # Simulate new process by clearing all in-memory state and restoring DB snapshot.
        server.ROOMS.clear();server.SOCKETS.clear();server.MATCH_QUEUE.clear()
        assert server.restore_rooms()==1
        room=server.ROOMS[code]
        assert room['phase']=='question' and room['deck'][0]['id']==first_question
        assert room['hints_used'][pa['id']]==1
        assert all(not p['online'] and p['ws'] is None for p in room['players'].values())
        c=WS()
        await server.process(c,{'action':'init','data':{'secret':pa['secret']}})
        await server.process(c,{'action':'join','data':{'code':code}})
        assert server.SOCKETS[c]['room']==code
        assert server.ROOMS[code]['hints_used'][pa['id']]==1
        await server.process(c,{'action':'export_profile','data':{}})
        export=c.sent[-1]
        assert export['type']=='profile_export'
        assert export['data']['profile']['id']==pa['id']
        assert 'secret' not in str(export)
        # Moderation actions are authenticated and now audit logged.
        transport=httpx.ASGITransport(app=server.app)
        async with httpx.AsyncClient(transport=transport,base_url='http://test') as client:
            assert (await client.get('/api/admin/audit')).status_code==401
            auth={'Authorization':'Bearer '+server.ADMIN_TOKEN}
            assert (await client.post('/api/admin/sanctions',json={'profile_id':pb['id'],'hours':2,'reason':'Kural ihlali'},headers=auth)).status_code==200
            r=await client.get('/api/admin/audit',headers=auth)
            assert r.status_code==200
            assert any(x['action']=='sanction' and x['target']==pb['id'] for x in r.json()['events'])
            # Reauthenticate after simulated process restart.
            await server.process(b,{'action':'init','data':{'secret':pb['secret']}})
            # A sanctioned player can appeal, but only once every seven days.
            await server.process(b,{'action':'appeal_sanction','data':{'reason':'Hatalı bir kısıtlama olduğunu düşünüyorum.'}})
            assert b.sent[-1]['type']=='appeal_received'
            try:
                await server.process(b,{'action':'appeal_sanction','data':{'reason':'Tekrar itiraz etme denemesi yapılacak.'}})
                raise AssertionError('Repeat appeal was accepted')
            except ValueError:
                pass
            appeals=(await client.get('/api/admin/appeals',headers=auth)).json()['appeals']
            assert len(appeals)==1 and appeals[0]['profile_id']==pb['id']
            assert (await client.post('/api/admin/appeals/'+appeals[0]['id']+'/review',headers=auth,json={'status':'reviewed','note':'İncelendi'})).status_code==200
            assert (await client.get('/api/admin/appeals')).status_code==401
        # Stale persisted rooms are pruned and cannot be resurrected.
        room['touched']=time.time()-server.ROOM_MAX_IDLE-10
        server.save_room(room);server.ROOMS.clear()
        assert server.restore_rooms()==0 and code not in server.ROOMS
        with server.sqlite3.connect(server.DB_PATH) as db:
            assert db.execute('SELECT count(*) FROM active_room_snapshots').fetchone()[0]==0
        print('PASS V10: crash recovery/rejoin/hints, stale-room pruning, profile export privacy, admin audit')

if __name__=='__main__':asyncio.run(main())
