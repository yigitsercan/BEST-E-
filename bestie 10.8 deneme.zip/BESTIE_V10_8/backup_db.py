"""Manual consistent SQLite backup. Usage: python backup_db.py /secure/path/backup.sqlite3"""
import os
import sqlite3
import sys
from pathlib import Path
if len(sys.argv)!=2:
    raise SystemExit('Usage: python backup_db.py /path/to/backup.sqlite3')
src=Path(os.environ.get('BESTIE_DB_PATH',str(Path(__file__).parent/'data'/'bestie.sqlite3'))).resolve()
dst=Path(sys.argv[1]).resolve()
if src==dst or not src.exists() or dst.exists():
    raise SystemExit('Source database missing, backup destination exists, or paths match')
dst.parent.mkdir(parents=True,exist_ok=True)
with sqlite3.connect(src) as db, sqlite3.connect(dst) as backup:
    db.backup(backup)
    if backup.execute('PRAGMA integrity_check').fetchone()[0] != 'ok':
        raise RuntimeError('Backup integrity check failed')
print('Backup created:',dst)
