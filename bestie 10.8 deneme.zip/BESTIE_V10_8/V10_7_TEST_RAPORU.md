# BESTIE? V10.7 — Görsel güvenilirliği ve test raporu

## Bu sürümde uygulanan düzeltmeler

- Çevrimiçi Tahmin Et! ve günlük meydan okuma görselleri ortak, güvenli HTML üreticisine bağlandı.
- Görsel sunucudan yüklenemezse bozuk resim simgesi yerine açıklama gösteriliyor ve oyuncu metin ipuçlarıyla devam edebiliyor.
- Çevrimdışı V10 sürümünün resim hata davranışı da düzeltildi. Dosya dizinlerinin `generated_v94/` dâhil korunması devam ediyor.
- Soru görsellerinde `object-fit: contain` kullanılarak görselin kırpılması azaltıldı.
- Çevrimiçi ana menüde bağlantı kesilmesi açıkça gösteriliyor; manuel yeniden dene düğmesi eklendi.
- WebSocket'in önceki bağlantısından gelen geç olayların yeni bağlantının durumunu bozmasını önleyen kimlik kontrolü eklendi.
- Maç içindeyken yanlışlıkla ana menü sıfırlamasını önleyici koruma eklendi.
- Görsel taşıma testi bütün 1.442 resimli kart için `GET` ve MIME tipi denetimi yapıyor (`test_v107_image_delivery.py`).

## Gerçekten gerçekleştirilen testler

- 1.442 / 1.442 görsel URL'si ASGI HTTP üzerinden HTTP 200, uygun MIME tipi ve boş olmayan içerik döndürdü.
- JavaScript sözdizimi: `static/bestie.js` ve çevrimdışı HTML içindeki script Node.js ile kontrol edildi.
- `test_image_paths.py` ve görüntüleme testleri geçti.
- Önceki birim/regresyon testleri (oyun kuralları, 5 ipucu, içerik yapısı, hesap kurtarma, şikâyet, engelleme, güvenlik, yedekleme vb.) geçti.
- Yerel WebSocket sunucusu: gerçek bağlantıyla oda kurma, katılma, hazır, oynama, oylama, sonuç, yeniden bağlanma ve rastgele eşleşme geçti.
- 24 eş zamanlı bağlantı/oda oluşturma yerel duman testi geçti (kapasite testi değildir).
- HTTP ana ekran, çevrimdışı ekran, sağlık, JS ve örnek SVG endpointleri 200 döndü.

## Hâlâ doğrulanmamış olanlar

- Gerçek iPhone/Android tarayıcıları ve bulut dağıtımı bu çalışmada kullanılmadı.
- 3.500 kartın bağımsız kaynaklarla olgusal doğrulaması tamamlanmış değildir; kart varyantları özgün bilgi çeşitliliği olarak sayılamaz.
- Resimli kartların görsel niteliği sınırlı olabilir: SVG kartların bazıları fotoğraf veya silüet değil metin ve sembol içerir.
- Bu sürüm tek sunuculu SQLite/WebSocket mimarisindedir; büyük trafik, veri koruma ve hukuki uygunluk için ek uzman/test gerekir.
- Otomatik testlerin geçmesi, gerçek cihaz veya bütün olası kullanıcı akışlarının kusursuz olduğunu kanıtlamaz.

## Windows'ta test

ZIP'i bütünüyle yeni bir klasöre çıkarın. `BASLAT_WINDOWS.bat` çalıştırın, ardından `http://127.0.0.1:8000` adresini açın. Önceki sürümün açık sunucusu varsa kapatın; aynı portu iki sürüm paylaşamaz. Kırık resim bildirimi veya görünmeyen ekran çıkarsa ekran görüntüsü ve oynanan modu kaydedin.

Bilgi: Oyun kuralı gereği her 10 sorudan yalnızca 2–3'ü görselli olarak seçilir. Bu kural değiştirilmedi.
