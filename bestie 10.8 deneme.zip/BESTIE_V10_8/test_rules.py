import os, tempfile, sqlite3, uuid
from pathlib import Path
with tempfile.TemporaryDirectory() as tmp:
 os.environ['BESTIE_DB_PATH']=tmp+'/profiles.sqlite3'
 import sys
 sys.path.insert(0,str(Path(__file__).parent))
 import server
 class FakeWS:
  async def close(self,**kw):pass
  async def send_json(self,**kw):pass
 for mode,category in [('kim_daha','FLORT_RADAR'),('trivia','footballer'),('truth_dare','truth_dare')]:
  profile=[]
  for n in range(2):
   pid=uuid.uuid4().hex
   p={'id':pid,'secret':uuid.uuid4().hex,'nickname':f'Test_{mode}_{n}', 'avatar':'😎', 'kp':0}
   with sqlite3.connect(server.DB_PATH) as c:c.execute('INSERT INTO profiles VALUES (?,?,?,?,?)',(pid,p['secret'],p['nickname'],p['avatar'],0))
   profile.append(p)
  room=server.new_room(profile[0],FakeWS(),mode,category,max_players=2)
  server.attach(room,profile[1],FakeWS())
  server.start_round(room)
  for i in range(10):
   a,b=[p['id'] for p in profile]
   if mode=='kim_daha':room['votes']={a:b,b:a}
   elif mode=='trivia':
    answer=room['deck'][i]['answer']
    room['votes']={a:{'answer':answer,'points':100},b:{'answer':answer,'points':100}}
   server.finish_round(room)
   room['index']+=1
   if i<9:server.start_round(room)
  server.finish_game(room)
  assert room['phase']=='finished'
  for p in profile:
   kp=server.profile_info(p['id'])['kp']
   assert kp==120,(mode,kp)
  if mode=='trivia':assert room['scores'][profile[0]['id']]==1000
  server.finish_game(room)
  assert server.profile_info(profile[0]['id'])['kp']==120
  print('PASS',mode,'10 rounds / correct KP 120 / no duplicate award')
  server.ROOMS.pop(room['code'])
