"""Small local multi-connection smoke test; NOT a production capacity benchmark."""
import asyncio
import json
import os
import websockets

URL=os.environ.get('BESTIE_TEST_WS_URL','ws://127.0.0.1:8899/ws')

async def recv(ws,kind):
    for _ in range(15):
        d=json.loads(await asyncio.wait_for(ws.recv(),timeout=10))
        if d.get('type')=='error':raise AssertionError(d['message'])
        if d.get('type')==kind:return d.get('data')
    raise AssertionError('Expected message missing: '+kind)

async def participant(i):
    async with websockets.connect(URL,open_timeout=10) as ws:
        await ws.send(json.dumps({'action':'init','data':{'nickname':'Smoke '+str(i)}}))
        profile=await recv(ws,'profile')
        assert profile['id']
        await ws.send(json.dumps({'action':'create','data':{'mode':'kim_daha','category':'KIM_DAHA','max_players':2}}))
        room=await recv(ws,'room')
        assert room['code'] and room['phase']=='lobby'
        return room['code']

async def main():
    rooms=await asyncio.gather(*(participant(i) for i in range(24)))
    assert len(set(rooms))==24, 'Duplicate room code created'
    print('PASS 24 concurrent connections / 24 unique rooms (local smoke only)')

if __name__=='__main__':asyncio.run(main())
