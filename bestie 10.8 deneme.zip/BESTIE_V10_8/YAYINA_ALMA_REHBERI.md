# Bestie? V8 — Tarayıcıda gerçek zamanlı arkadaş oyunu

## En hızlı yol: Windows'ta geçici internet bağlantısı (GitHub / hesap gerekmez)

1. ZIP dosyasını sağ tıklayıp **Tümünü ayıkla** ile klasöre çıkarın. ZIP içindeyken dosyayı çalıştırmayın.
2. [Python 3.10+](https://www.python.org/downloads/windows/) bilgisayarınızda kurulu değilse önce kurun (Windows'ta `py -3 --version` ile kontrol edilebilir).
3. **BESTIE_ONLINE_BASLAT.bat** dosyasına çift tıklayın. İlk çalıştırmada Python paketleri kurulacak ve Cloudflare'ın resmi GitHub sürümünden `cloudflared.exe` indirilecek.
4. Açılan siyah pencerede `https://....trycloudflare.com` bağlantısı göründüğünde bu **geçici internet adresini** hem kendi telefonunuzda hem arkadaşlarınızın telefonlarında açın.
5. Ev sahibi: **ONLINE → ARKADAŞLARIMLA OYNA → ODA OLUŞTUR**; kişi sayısını 2–12 arasında `+`/`−` ile ayarlasın. Arkadaşlar aynı bağlantıdan **ODAYA KATIL** ve altı karakterli kodu kullanıp avatar seçsinler.
6. Herkes **HAZIRIM** deyince kurucu **OYUNU BAŞLAT** der. Herkes aynı soruları aynı anda görür ve sonuçlar senkronize gösterilir.

**Önemli sınırlar:** Bu bir *geçici test linkidir*, kalıcı web sitesi değil. Bilgisayarın açık, internetin bağlı ve siyah pencerenin açık olması gerekir. Her çalıştırmada `trycloudflare.com` adresi değişebilir. Cloudflare Quick Tunnel, üretim sistemi veya kalıcı kullanıcı verisi için önerilmez. Oyunlar RAM'de, KP ise yerel SQLite dosyasında tutulur; yedek alınmadığında veriler kaybolabilir. Bu sürümde üyelik güvenliği, moderasyon ve otomatik ölçeklendirme üretim düzeyinde değildir.

Cloudflare bağlantısı için `cloudflared` resmi indirme adresi: `https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-windows-amd64.exe` (GitHub hesabı gerekmez). Ağ/antivirüs programınız indirmeyi engelleyebilir; sadece güvendiğiniz yazılımları çalıştırın.

## Uzun süre açık kalacak gerçek internet adresi (Railway — GitHub gerektirmez)

Bu pakette Dockerfile da hazırdır. Kendi Railway hesabınızda uygulamayı yayınlayıp sabit HTTPS adresi alabilirsiniz.

1. Bilgisayarınıza **Node.js** yükleyin: https://nodejs.org/
2. ZIP'i açtığınız klasörde Windows Terminal / PowerShell açın.
3. `npm install -g @railway/cli` komutunu çalıştırın.
4. `railway up` çalıştırın ve Railway oturum açma / proje oluşturma adımlarını izleyin. Bu komut dosyalarınızı Railway'e yükler.
5. `railway domain` çalıştırarak herkese açık `https://...up.railway.app` alan adını oluşturun.
6. Yeni alan adının sonuna `/health` ekleyip **status: ok** çıktısını doğrulayın. Sonra ana alan adını arkadaşlarınızla paylaşın.

**Not:** Railway hesabı, plan/ücretlendirme onayı ve dağıtım ayarları size aittir. Bu ortamdan sizin adınıza yayın yapılamadı. Paket herhangi bir barındırma hesabını içermiyor. Dockerfile tek çalışan süreç kullanır. Bulut sunucusu yeniden başladığında RAM'deki odalar silinir; kalıcı KP için ayrıca kalıcı veritabanı gerekir.

## Hata giderme

- `Python bulunamadı`: Python 3.10+ kurun ve yeniden çalıştırın.
- `Cloudflare aracı indirilemedi`: Ağ bağlantısını kontrol edin, gerekirse exe'yi yukarıdaki resmi bağlantıdan indirip `tools\cloudflared.exe` adıyla yerleştirin.
- `Port kullanılıyor`: Diğer Bestie? başlatıcı pencerelerini kapatıp tekrar çalıştırın.
- `Arkadaş bağlantı kuramıyor`: Herkesin **localhost yerine aynı https://trycloudflare.com** bağlantısını açtığından emin olun. Kod doğru olmalı ve oda açık olmalı.
- `Kod bulunamadı`: Ev sahibinin sunucusu ya da tunnel kapandıysa yeniden oda oluşturun.
- `Rastgele eşleşme`: İki gerçek kullanıcı, aynı oyun ve kategoriyi aynı anda aramalıdır; bot eklenmez.

## Kontrol edilmiş gerçek zamanlı oyun işlevleri

- 2 farklı WebSocket bağlantısıyla oda oluşturma, katılma, hazır olma, başlama ve anonim oy senkronizasyonu
- Bağlantı kesilince aynı tarayıcıyla yeniden katılma
- Sunucu kontrollü zaman ve sonuç
- 2 gerçek istemciyle rastgele eşleştirme
- 10 tur sonrasında birikimli KP / Level hesabı

**Çevrimiçi testin kapsamı:** Bu işlevler yerel sunucuda test edilmiştir. Cloudflare test bağlantısını veya Railway dağıtımını bu çalışma ortamından açıp dış ağ üzerinden uçtan uca test etmek mümkün olmamıştır.
