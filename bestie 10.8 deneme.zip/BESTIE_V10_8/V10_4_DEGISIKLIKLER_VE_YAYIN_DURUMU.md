# BESTIE? V10.4 — Sorular hariç geliştirmeler

## Gerçekten yapılan ve test edilenler

1. **SQLite sağlık kontrolü:** `/health` sadece bağlantıyı değil, `BEGIN IMMEDIATE` içinde yazma işleminin mümkün olduğunu da kontrol eder; işlem `ROLLBACK` ile geri alınır. Kalıcı dosya yazılamazsa veya kilitliyse HTTP 503 döner. `/live` ayrılmıştır.
2. **SQLite güvenilirliği:** 5 saniyelik bağlantı bekleme ayarı ve WAL günlükleme etkinleştirildi (tek sunucu, kalıcı disk için).
3. **Yedekleme ve geri yükleme:** `backup_db.py` üzerine yazmayı engeller, bütünlük kontrolünü değerlendirir. Yeni `restore_db.py` yedek bütünlüğünü kontrol eder ve var olan veritabanını ezmez. Geri yükleme için sunucu durdurulmalıdır.
4. **Mobil uygulama metaverisi:** `static/manifest.webmanifest`, ana ekrana ekleme bağlantısı ve mevcut yerel logoyla uygulama simgesi tanımı eklendi. Gerçek iOS/Android cihaz testi yapılmadı. App Store uygulaması teslimi değildir.
5. **Sürekli kalite kontrolü:** `.github/workflows/quality.yml` eklendi. GitHub reposuna aktarıldığında her push/PR için otomatik regresyon ve WebSocket testlerini çalıştıracak şekilde yapılandırıldı. Bu ortamda CI'nın GitHub üzerinde koştuğu iddia edilmemektedir.
6. **WebSocket test portu:** `test_realtime.py` artık `BESTIE_TEST_WS_URL` çevre değişkenini kabul eder; mevcut sunucuyla çakışmadan test yapılabilir.

## Test kaydı

- Önceki 11 Python regresyon test dosyası: geçti.
- `test_v104_operations.py`: kilitli veritabanı HTTP 503; açık veritabanı HTTP 200; otomatik yedekleme/geri yükleme bütünlüğü; var olan dosyanın üzerine yazma engeli; manifest: geçti.
- Gerçek çalışan yerel sunucuda `test_realtime.py`: oda kurma, katılım, oy verme, yeniden bağlanma, otomatik eşleşme: geçti.
- `test_v104_concurrency.py`: aynı anda 24 istemciyle 24 ayrı oda açma: geçti. Bu bir **yerel küçük çaplı duman testidir**, 100–500 oyunculu kapasite testi değildir.
- Node.js JavaScript söz dizimi: geçti.

## Kullanım

```bash
python -m pip install -r requirements.txt
python -m uvicorn server:app --host 127.0.0.1 --port 8000 --workers 1
```

### Veri yedeği

```bash
BESTIE_DB_PATH=/app/data/bestie.sqlite3 python backup_db.py /secure/backups/bestie-2026-11-20.sqlite3
```

Geri yüklemeden önce uygulamayı durdurun; hedefte henüz var olmayan yeni bir dosya seçin:

```bash
python restore_db.py /secure/backups/bestie-2026-11-20.sqlite3 /app/data/restored.sqlite3
```

Geri yüklenen veritabanını kullanacak şekilde `BESTIE_DB_PATH` değerini değiştirip uygulamayı tekrar başlatın. Yedekleri erişim kontrollü tutun: kişisel veri içerirler.

## Halen yayımdan önce gerçek ortamda gerekenler

- Canlı HTTPS/WSS kurulumu; persistent disk gerçekten bağlı mı kontrolü; kalıcı veritabanı üzerinde yeniden başlatma, yedek ve geri yükleme tatbikatı.
- Gerçek iPhone ve Android'lerde dokunmatik kullanım, tarayıcı izinleri, kesintili bağlantı ve paylaşım akışı testleri.
- Gerçek kullanıcı sayısıyla yük/kapasite ölçümü; birden fazla sunucu/worker kullanılacaksa Redis/PostgreSQL tabanlı mimari dönüşümü.
- E-posta/Passkey sağlayıcısı üzerinden doğrulanmış hesap sistemi (mevcut anonim oturum + tek kullanımlık kurtarma kodu yerine).
- KVKK, yaşa uygunluk, telif ve içerik moderasyonu konularında uygulamanın gerçek hizmet modeline göre hukuki/operasyonel inceleme.
- **Soru bankası ayrı kapsam:** 3.500 soru kartından 3.320'sinin bağımsız kaynak doğrulaması devam ediyor. Bu sürüm soru dosyasına dokunmaz.

Bu dosya **yayın onayı** değildir. V10.4 yerel testleri geçen tek sunuculu prototip paketidir.
