# BESTIE? V9.5 — Sağlamlaştırma ve sosyal paylaşım

## Gerçekten uygulanan kod değişiklikleri
1. **Maç sonu paylaşımı**: Sonuç ekranına `SONUCU PAYLAŞ` ve `SONUCU KOPYALA` eklendi. Oyuncuların ilk üç sıralaması ve kişinin kazandığı KP metin olarak yer alır. Web Share API varsa sistem paylaşım sayfası açılır; yoksa panoya kopyalanır. İzin olmayan durumda kullanıcı uyarılır. Bu, resimli sosyal paylaşım kartı veya otomatik Instagram paylaşımı değildir.
2. **WebSocket origin kontrolü**: Browser'ın gönderdiği `Origin` değerinin `Host` ile aynı olması beklenir; farklı web sitelerinden bağlantı 1008 koduyla kapatılır. Origin belirtmeyen komut satırı istemcileri test ve API desteği için engellenmez. Ters proxy ve özel domain yapılandırmalarında test edilmelidir.
3. **Oda açma sınırlaması**: Kimlik başına saatte 20 yeni oda ve aynı anda toplam 500 oda varsayılan sınırı eklendi (`BESTIE_MAX_NEW_ROOMS_PER_HOUR`, `BESTIE_MAX_ACTIVE_ROOMS`). Sınırlar tek worker belleğinde tutulur ve yeniden başlatmayla sıfırlanır; büyük ölçekli saldırı koruması değildir.
4. **Süresi dolan oda düzeltmesi**: 2 saattir kullanılmayan odalar kapandığında oyuncunun WebSocket bağlantısındaki oda üyeliği temizlenir ve `left` olayı gönderilir. Önceki sürümde oyuncu kaybolan odada takılı kalabiliyordu.
5. **Güvenlik uyarısı**: Çevrimiçi giriş ekranına özel bilgi paylaşmama, rahatsız eden oyundan çıkma ve 18+ kullanımı hakkında kısa açıklama eklendi.
6. **Yeni regresyon testi**: `test_v95_hardening.py` origin, oda sınırı ve oda zaman aşımı davranışlarını kontrol eder.

## Testler (19 Kasım 2026, yerel ortam)
- `python test_rules.py`: 3 oyun türünde 10 tur, KP ve tekrar ödüllendirmeme — GEÇTİ
- `python test_hint_budget.py`: beş hak/100-70-40 — GEÇTİ
- `python test_content_quality.py`: 11 kategoride toplam 1.650 simülasyon, soru tekrarları ve görsel sınırı — GEÇTİ
- `python test_v95_hardening.py`: origin, yaratma sınırı, süre aşımı — GEÇTİ
- `python test_realtime.py` (yerel uvicorn ile): oda/oy/yeniden bağlanma/rastgele eşleşme — GEÇTİ
- HTML içi JavaScript: Node.js sözdizimi — GEÇTİ

## Yayına hazır olmayan alanlar (kritik)
1. Tek worker RAM tabanlı odalar: yeniden başlatmada oyunlar kaybolur. Kalıcı oda state'i, ölçeklenebilir pub/sub ve ayrı Postgres profilleri yok.
2. SQLite kalıcılığı Render Free geçici disk üzerinde garanti edilmez. Hesap doğrulama, kurtarma ve kullanıcı verisi silme akışı yok.
3. **Soru kalitesi**: 3.500 trivia kartı, yalnızca 743 kategori/cevap çifti. Otomatik varyantlar tam anlamıyla bağımsız soru değildir. 1.442 resimli kartın çoğu SVG ipucu tasarımıdır; görsel tahmin bulmacası sayılmaz. Her sorunun kaynakla birebir doğrulandığı iddia edilemez.
4. Moderasyon, engelleme, içerik şikâyeti, riskli isim denetimi ve çocuk koruma/ebeveyn süreçleri eksik. 18+ sadece kullanıcı beyanı.
5. KVKK aydınlatma metni, saklama/silme prosedürleri, telif/lisans incelemesi ve hizmet şartları uzman kontrolünden geçmedi.
6. WebSocket origin kontrolü CSWSH riskini azaltır; kimlik yerine geçmez. Profil token'ı localStorage'dadır. Rate limit bellektedir, IP/hesap doğrulaması yoktur.
7. Gerçek cihaz performansı, erişilebilirlik, yük testi, canlı domain, uygulama mağazası uyumluluğu ve kullanıcı beta metrikleri doğrulanmadı.
8. Çevrimdışı sayfa eski V6 prototipidir ve yeni oyun kalite/maç sonu özellikleriyle birebir eşleşmez.

## Öncelikli sonraki geliştirmeler
**P0:** Kalıcı sunucu altyapısı + kimlik doğrulama, moderasyon/şikâyet, güvenli yaş politikası, içerik editoryal onayı.
**P1:** Telif/lisans denetimli özgün görsel bulmacalar, gerçek mobil testler, 100–300 kişilik kapalı beta, güvenli paylaşılabilir sonuç kartı.
**P2:** D1/D7 geri dönüş, davet dönüşümü ve tekrar oynama ölçümü sonrası oyun tasarımı iterasyonları.

Bu paket test edilmiş bir prototip güncellemesidir, bitmiş ticari üretim sistemi değildir.
