# BESTIE? V9.4 — 3.500 kart ve görselli varyant paketi

## Yapılanlar
- V9.3'teki 2.088 trivia kartı korundu.
- 1.412 yeni **görselli kart varyantı** eklendi: 200 futbolcu, 200 futbol kulübü, 120 basketbolcu, 120 basketbol kulübü, 120 voleybolcu, 120 voleybol kulübü, 130 tarih, 180 coğrafya, 120 film/dizi, 102 müzik.
- Her ek kart için ayrı, özgün olarak kodla çizilmiş SVG görsel var: `static/trivia-img/generated_v94/`.
- SVG dosyalarında üçüncü kişilere ait fotoğraf, gerçek kişi portresi, kulüp logosu, film afişi, albüm kapağı veya marka varlığı **kopyalanmadı**. Bunlar özgün çizimli tipografik/ikonografik bilgi kartlarıdır; fotoğraf/portre değildir.
- 10 soruluk turlarda en çok 3 görsel, 5 ek ipucu hakkı, soruda en fazla 2 ek ipucu ve 100/70/40 puan kuralları korundu.

## ÖNEMLİ kalite ve hukuk sınırları
- **3.500 kart = 3.500 ayrı doğrulanmış olgu değildir.** 1.412 görselli kart V9.3'teki kaynak soruların tekrar formüle edilmiş, görselleştirilmiş varyantlarıdır. Temeldeki özgün kategori–cevap çeşitliliği 743'tür.
- 1.412 yeni kartın `editorial_status` alanı, bunların dış kaynak teyidi ve editoryal onay BEKLEYEN taslaklar olduğunu belirtir; `review_required=true` olarak işaretlidir.
- Script ile şık sayısı, cevap eşleşmesi, ipucu uzunluğu, SVG dosyası, doğrudan ipucunda cevap sızması ve kimlik benzersizliği denetlendi. Bu **olgusal doğruluk veya telif hukuku onayı değildir**.
- Görsellerin özgün çizilmiş olması tek başına bütün ürünün fikrî mülkiyet, kişilik hakkı, reklam, marka, KVKK ve diğer yükümlülükleri karşıladığını ispatlamaz. Türkiye ve dağıtılacak ülkelerde ticari yayından önce profesyonel hukuk kontrolü önerilir.
- `image_alt` metinleri ilk bilgiyle aynı veriyi içerir; erişilebilirlik için görseldeki bilgiye erişim sağlar.
- Statik çevrimdışı HTML V6 prototipi güncel veri bankasına bağlı değildir. V9.4 soruları sunuculu modda çalışır.
- Gerçek internet canlı yayını ve 1.412 sorunun tek tek bağımsız kaynak kontrolü yapılmadı.

## Tekrar oluşturma
Script **yalnızca temiz V9.3 bankası üzerinde tek defa çalıştırılmak üzere hazırlanmıştır**: `python build_illustrated_3500.py`.

## Testler
- `python quality_guard.py`: yapısal sorun yok.
- `python test_rules.py`: başarılı.
- `python test_hint_budget.py`: başarılı.
- `python test_content_quality.py`: 11 kategori/karışık seçenek × 150 = 1.650 deneme maçı başarılı; aynı maçta doğru cevap tekrarı yok, en çok 3 resim.

## Başlatma
`pip install -r requirements.txt` ardından `uvicorn server:app --host 0.0.0.0 --port 8000`.
