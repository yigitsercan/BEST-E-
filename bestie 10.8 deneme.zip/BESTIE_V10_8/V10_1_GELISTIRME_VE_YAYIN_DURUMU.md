# BESTIE? V10.1 — Geliştirme, test ve yayın durumu

## Bu sürümde uygulananlar
- Bir oyuncu profilinden **tek kullanımlık kurtarma kodu** oluşturabilir. Kod 256-bit kriptografik rastgelelikten üretilir, SHA-256 özeti SQLite'da saklanır; kullanıcıya bir kere TXT olarak sunulur. Yeni kod eski kodu iptal eder.
- Kurtarma işlemi yeni, rastgele bir oturum anahtarı oluşturur; eski tokenı iptal eder ve aynı kullanıcının diğer aktif WebSocket oturumlarını kapatır.
- Profil silinince kurtarma kodu kaydı da silinir. Kod ile hesap taşıma, e-posta doğrulaması veya tam kimlik sağlayıcı entegrasyonu değildir; koda erişen herkes hesabı devralabilir. Güvenli saklama gerekir.
- 3.500 kartlık `CONTENT_REVIEW_QUEUE.csv` editoryal denetim listesi, `CONTENT_REVIEW_SUMMARY.json` özeti ve otomatik tekrar/şık/ipucu/görsel kontrolleri oluşturuldu. **Tek tek kaynak doğrulaması yapılmadı**.
- `preflight.py` yayın öncesi kontrol aracı ve `PREFLIGHT_REPORT.json` eklendi.
- V10 özellikleri, 20 oda/saat kuralı, 5 ipucu, puan kuralları, offline sürüm, moderasyon ve profil dışa aktarımı korundu.

## Gerçekleştirilen testler
`test_rules.py`, `test_hint_budget.py`, `test_content_quality.py`, `test_v95_hardening.py`, `test_v97_privacy_reports.py`, `test_v98_blocking.py`, `test_v99_features.py`, `test_v100_recovery_privacy.py`, `test_v101_recovery.py`, `test_offline_v10.js`; ayrıca `test_realtime.py` çalışan uvicorn sunucusuyla geçti. Python derleme ve tarayıcı JavaScript sözdizimi kontrol edildi.

## Halka açık yayın önündeki engeller
1. **Gerçek çok sunuculu altyapı yok**. Odalar ve WebSocket oturumları Python bellek sözlüğünde; SQLite snapshotları yalnızca tek süreç geri yüklemesi sağlar. En azından ortak ilişkisel veritabanı, atomik oda geçişleri, Redis pub/sub/queue ve dağıtık yetkilendirme; otomasyon, stres ve kesinti testleri gerekir. V10.1 yalnızca **tek süreç** içindir.
2. **Tam kalıcı kimlik sistemi yok**. Tek kullanımlık manuel kurtarma kodu, onaylı e-posta/Passkey/OIDC sağlayıcısı, oturum iptali/yenileme politikası, kötüye kullanım önleme ve kullanıcı destek sürecinin yerini tutmaz. Mevcut tarayıcıdaki gizli profil anahtarı yerel depolamadadır; XSS riskine karşı CSP ve ek tarayıcı güvenlik kontrolü gerekir.
3. **3.500 sorunun tek tek kaynak doğrulaması ve hak kontrolü yapılmadı**. 743 farklı kategori–cevap eşleşmesi bulunuyor; çok sayıda varyant var. `CONTENT_REVIEW_QUEUE.csv` içindeki `human_fact_check`, `human_visual_rights_check`, `sources` alanları gerçek editör tarafından doldurulmalıdır. Otomatik denetim olgusal doğruluğu kanıtlamaz.
4. **Hukuki inceleme yapılmadı**. KVKK/GDPR uygulanabilirliği, yaşa uygunluk, yetişkin içerikleri, telif/lisans ve mağaza koşulları için hukuk uzmanı incelemesi gereklidir.
5. **Gerçek cihaz ve gerçek kullanıcı beta testi yapılmadı**. iOS Safari/Android Chrome, düşük ağ bağlantısı, erişilebilirlik, dosya indirme/paylaşma, moderasyon ve yük testleri yapılmalıdır.
6. **Canlı üretim kurulumu yapılmadı**. Render ücretsiz planında disk kalıcılığı varsayılmamalıdır. Tek süreç, kalıcı disk, TLS, yedekleme/geri yükleme ve log/uyarılar doğrulanmalıdır. `preflight.py` operatör kontrol listesini sunar.

## Yayın kararı
**V10.1 test edilen geliştirme paketidir, halka açık yayına hazır değildir.** `PREFLIGHT_REPORT.json` içindeki `ready_for_public_launch` yalnızca kontrol bayrakları gerçekten onaylandığında doğru olabilir; bu işaretler kendi başına dış doğrulama yerine geçmez.
