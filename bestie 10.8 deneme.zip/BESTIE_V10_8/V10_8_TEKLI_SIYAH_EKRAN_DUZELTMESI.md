# BESTIE? V10.8 – Tekli Oyun Siyah Ekran Düzeltmesi

## Sorunun kökü
V10.7'de `/offline` sayfası açılıyordu, fakat içindeki 2+ MB JavaScript kodu HTML içinde `<script>` olarak gömülüydü. Sunucu `Content-Security-Policy: script-src 'self'` gönderdiğinden modern tarayıcılar bu kodu çalıştırmıyordu. `<main id="root">` boş kaldığı için oyuncu siyah ekran görüyordu. Önceki `node --check` ve oyun kuralı testleri tarayıcının CSP uygulamasını test etmediğinden hatayı yakalayamamıştı.

## Düzeltme
- `/offline` ve `/static/Bestie_V10_Cevrimdisi.html` sayfalarında *yalnızca mevcut tekli oyun inline JavaScript'inin* SHA-256 CSP karması için istisna eklendi.
- Diğer bütün sayfalarda `script-src 'self'` koruması korunuyor. `unsafe-inline` JavaScript izni verilmedi.
- CSP karması paket açılışında gerçek HTML içeriğinden hesaplanıyor. Tekli HTML değişirse karman da değişiyor.
- `/offline` yanıtı önbelleğe alınmıyor.
- `test_v108_single_screen.py` dosyası HTML script karmasıyla CSP'yi gerçek ASGI yanıtında karşılaştırıyor; ayrıca ana sayfada istisnanın bulunmadığını doğruluyor.
- Önceki dağıtım testinin sabit kaynak-kod string kontrolü yeni CSP yapısına uyumlu hale getirildi.

## Testler
`python run_tests.py` → 16/16 dosya başarılı. `node test_offline_v10.js` → Kim Daha?, Doğruluk mu Cesaret mi? ve Tahmin Et! tekli akışları başarılı. `python test_v108_single_screen.py` → `/offline`, doğrudan HTML yolu, CSP karma eşleşmesi, ana sayfa kısıtlaması başarılı.

Bu ortamda otomatik Chromium navigasyonu yönetim politikasıyla engellendiğinden gerçek Windows/iPhone/Android tarayıcı ekran testi burada yapılmadı. Kullanıcının cihazında doğrulanmalıdır.

## Kullanım
1. V10.7 sunucusunu kapatın.
2. V10.8 ZIP paketini **ayrı bir klasöre** çıkarın.
3. `BASLAT_WINDOWS.bat` çalıştırın.
4. Tarayıcıdan `http://127.0.0.1:8000` açın, **Tekli Oyna** seçin. Gerekirse `Ctrl+Shift+R` ile önbelleksiz yenileyin.
5. Doğrudan `http://127.0.0.1:8000/offline` adresini de test edin.

Not: Bu düzeltme 3.500 sorunun bağımsız bilgi doğrulamasının yerini tutmaz.
