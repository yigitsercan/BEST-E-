"""Block controls: persistent DB, future room exclusion, safe matchmaking, deletion."""
import asyncio, os, tempfile
from pathlib import Path

async def run():
    with tempfile.TemporaryDirectory() as tmp:
        os.environ['BESTIE_DB_PATH']=str(Path(tmp)/'bestie.sqlite3')
        import server
        class WS:
            def __init__(self): self.sent=[]
            async def send_json(self,value): self.sent.append(value)
            async def close(self,**kwargs): pass
        first,second,third=WS(),WS(),WS()
        for ws,n in [(first,'Birinci'),(second,'İkinci'),(third,'Üçüncü')]:
            await server.process(ws,{'action':'init','data':{'nickname':n}})
        a=server.SOCKETS[first]['player'];b=server.SOCKETS[second]['player'];c=server.SOCKETS[third]['player']
        await server.process(first,{'action':'create','data':{'mode':'trivia','category':'history'}})
        room=server.SOCKETS[first]['room']
        await server.process(second,{'action':'join','data':{'code':room}})
        await server.process(first,{'action':'block_player','data':{'target':b}})
        assert server.mutually_blocked(a,b) and not server.mutually_blocked(a,c)
        assert first.sent[-1]['type']=='block_received'
        await server.process(second,{'action':'leave'})
        await server.process(first,{'action':'leave'})
        await server.process(second,{'action':'create','data':{'mode':'trivia','category':'history'}})
        second_room=server.SOCKETS[second]['room']
        try:
            await server.process(first,{'action':'join','data':{'code':second_room}})
        except ValueError as e: assert 'engelle' in str(e)
        else: raise AssertionError('blocked room join was allowed')
        await server.process(third,{'action':'join','data':{'code':second_room}})
        await server.process(second,{'action':'leave'})
        await server.process(third,{'action':'leave'})
        # Queued blocked player cannot be matched to blocker; a third candidate can.
        await server.process(second,{'action':'matchmake','data':{'mode':'trivia','category':'history'}})
        await server.process(first,{'action':'matchmake','data':{'mode':'trivia','category':'history'}})
        assert server.SOCKETS[first]['room'] is None and server.SOCKETS[second]['room'] is None
        await server.process(third,{'action':'matchmake','data':{'mode':'trivia','category':'history'}})
        assert server.SOCKETS[third]['room']==server.SOCKETS[second]['room']
        assert server.SOCKETS[first]['room'] is None
        await server.process(first,{'action':'delete_profile'})
        assert not server.mutually_blocked(a,b)
        print('PASS V9.8: persistent player blocking, room join, safe matchmaking, deletion')

if __name__=='__main__':asyncio.run(run())
