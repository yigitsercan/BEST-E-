"""V9.9 admin authentication, persistent creation limit, daily challenge & leaderboard."""
import asyncio
import os
import tempfile
import time
from pathlib import Path

async def main():
    with tempfile.TemporaryDirectory() as root:
        os.environ['BESTIE_DB_PATH']=str(Path(root)/'bestie.sqlite3')
        os.environ['BESTIE_ADMIN_TOKEN']='test-only-admin-token-with-32-plus-chars'
        import server
        import httpx
        class WS:
            def __init__(self):self.sent=[]
            async def send_json(self,obj):self.sent.append(obj)
            async def close(self,**kwargs):pass
        a,b=WS(),WS()
        await server.process(a,{'action':'init','data':{'nickname':'Kullanıcı A'}})
        await server.process(b,{'action':'init','data':{'nickname':'Kullanıcı B'}})
        pa=server.SOCKETS[a]['profile']['id'];pb=server.SOCKETS[b]['profile']['id']
        # Persistent count, no longer just an in-memory list.
        with server.sqlite3.connect(server.DB_PATH) as db:
            for i in range(20):db.execute('INSERT INTO room_creation_events VALUES (?,?)',(pa,time.time()))
        assert not server.creation_allowed(pa)
        server.ROOM_CREATIONS.clear()
        assert not server.creation_allowed(pa)
        # Daily: no replay / no extra award, answers absent from published question.
        await server.process(a,{'action':'daily','data':{}})
        payload=a.sent[-1]['data']
        assert 'answer' not in payload['question'] and payload['total']==5
        correct=server.daily_deck(payload['day'])[0]['answer']
        await server.process(a,{'action':'daily_answer','data':{'answer':correct}})
        assert a.sent[-1]['data']['correct']
        await server.process(a,{'action':'daily','data':{}})
        assert a.sent[-1]['data']['index']==1 and a.sent[-1]['data']['score']==100
        # Leaderboard defaults to private and lists only opted-in profiles.
        await server.process(a,{'action':'leaderboard','data':{}})
        assert a.sent[-1]['data']['players']==[]
        await server.process(a,{'action':'leaderboard_optin','data':{'enabled':True}})
        with server.sqlite3.connect(server.DB_PATH) as db:
            db.execute('INSERT INTO kp_ledger VALUES (?,?,?,?,?)',('test-ledger',pa,'TESTROOM',15,time.time()))
            db.execute('INSERT INTO kp_ledger VALUES (?,?,?,?,?)',('test-ledger-b',pb,'OTHER',100,time.time()))
        await server.process(a,{'action':'leaderboard','data':{}})
        assert len(a.sent[-1]['data']['players'])==1 and a.sent[-1]['data']['players'][0]['points']==15
        transport=httpx.ASGITransport(app=server.app)
        async with httpx.AsyncClient(transport=transport,base_url='http://test') as client:
            assert (await client.get('/api/admin/reports')).status_code==401
            assert (await client.get('/api/admin/reports',headers={'Authorization':'Bearer wrong'})).status_code==401
            auth={'Authorization':'Bearer '+server.ADMIN_TOKEN}
            r=await client.get('/api/admin/reports',headers=auth)
            assert r.status_code==200
            await server.process(b,{'action':'create','data':{'mode':'trivia','category':'history','max_players':2}})
            code=server.SOCKETS[b]['room']
            # a has hit room create limit but may join normally
            await server.process(a,{'action':'join','data':{'code':code}})
            await server.process(a,{'action':'report_player','data':{'target':pb,'reason':'hile'}})
            report=(await client.get('/api/admin/reports',headers=auth)).json()['reports'][0]
            assert report['reason']=='hile' and report['status']=='pending'
            assert (await client.post('/api/admin/reports/'+report['id']+'/review',headers=auth,json={'status':'reviewed','note':'Manuel incelendi'})).status_code==200
            assert (await client.post('/api/admin/sanctions',headers=auth,json={'profile_id':pb,'hours':24,'reason':'Test'})).status_code==200
            assert server.is_sanctioned(pb)
            assert (await client.delete('/api/admin/sanctions/'+pb,headers=auth)).status_code==200
            assert not server.is_sanctioned(pb)
            assert (await client.get('/moderasyon')).status_code==200
        print('PASS V9.9: persistent rate limit, daily quiz, leaderboard opt-in, admin authentication, review, sanction/unban')

if __name__=='__main__':asyncio.run(main())
