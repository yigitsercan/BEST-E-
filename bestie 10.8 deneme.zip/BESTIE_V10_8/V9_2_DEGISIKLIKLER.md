# BESTIE? V9.2 — Doğrulanmış kısmi iyileştirme

V9.1 kaynak paketi temel alınarak oluşturulmuştur. Bu sürüm, 7.500 soruluk veya 2.500 görsellik bitmiş bir içerik paketi **değildir**.

## Bu güncellemede değişenler

- `quality_guard.py`: tüm Tahmin Et! kartlarında 4 farklı seçenek, doğru yanıtın seçeneklerde bulunması, 3 ipucu, görsel dosyasının bulunması, doğrudan cevabı açıklayan ipucu, aynı soru kimliğinin tekrar kullanılması ve tekrar eden yanıtları raporlar.
- `data/questions.json`: ilk taramada doğrudan yanıt metni içeren **141 ipucu** düzeltildi. Bu değişiklikler otomatik düzeltmedir: bazıları daha genel ifadeye dönüştüğü için yayın öncesi editoryal yeniden yazım ve doğrulama gerektirir. Hata bildiren editoryal durum alanları korunmuştur.
- `server.py`: 10 soruluk bir maçta aynı cevabı tekrar etmez; aynı cevaba ait alternatif kartları farklı maçlarda rastgele kullanır; resimli sorular en fazla 3 olur. Başlangıçtaki 5 ek ipucu, dört şık, 100/70/40 maç puanı mantığı korunmuştur.
- `test_content_quality.py`: tüm 10 kategori ve karışık mod için 150'şer rastgele maç üretip kartların yapısını ve tekrar kısıtlarını test eder.
- `KALITE_KONTROL_V9_2.json`: önce/sonra kalite denetimi ve içerik sayıları.

## Açık işler — tamamlandı denemez

- Mevcut **1.960** Tahmin Et! kartı, yalnızca **625 kategori-cevap eşleşmesini** kapsıyor. Cevap varyasyonlarıyla sayıyı şişirmek yerine **5.540 yeni, özgün, bilgi doğrulaması yapılmış** soru yazılmalıdır.
- **30** resimli kart var; **2.470** resimli kart daha hazırlanmalıdır. Mevcut görseller tematik tasarımlardır, gerçek kişi ve takım görselleri değildir.
- Kaynaklar internette/uzman editörce tek tek olgusal doğrulamadan geçmedi. İçerik denetimi sadece yapısal sorunlara odaklandı.
- Çevrimdışı HTML (`static/Bestie_V6_Cevrimdisi.html`) eski gömülü içerik içeriyor; V9.2 JSON düzeltmeleri o HTML'ye henüz taşınmadı. Bu pakette güncel veri **sunuculu modda** yüklenir.
- Kalıcı sunucu/veritabanı, üretim güvenliği ve canlı site dağıtımı yapılmadı. Yereldeki WebSocket testleri gerçek internet üzerinden dağıtımı kanıtlamaz.

## Test komutları

```bash
python quality_guard.py
python test_content_quality.py
python test_rules.py
python test_hint_budget.py
uvicorn server:app --host 127.0.0.1 --port 8899
# ayrı terminalde:
python test_realtime.py
```
