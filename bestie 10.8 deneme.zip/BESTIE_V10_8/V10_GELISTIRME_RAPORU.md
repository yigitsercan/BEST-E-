# BESTIE? V10 — Gerçekleştirilen işler ve yayın engelleri

**Tarih:** 20 Kasım 2026. Bu paket kod ve yerel test teslimidir; gerçek mağaza yayını, hukuk onayı veya yayında ölçeklenme garantisi değildir.

## Bu sürümde uygulananlar

1. **Tek sunucuda oda durumunu kurtarma:** `active_room_snapshots` SQLite tablosu, `save_room`, `restore_rooms`. Oda oluşturma/katılma, oy/hint değişikliği, yeniden eşleşme ve tur ilerleyişi kaydedilir. WebSocket nesneleri kaydedilmez; sunucu açılırken oyuncular çevrimdışı durumuyla geri yüklenir ve eski profil anahtarıyla yeniden katılabilir. 2 saatlik hareketsizlik sınırı korunur. Sunucu kaynaklı elektrik/disk kaybında son işlemlerin kalıcı olduğu garanti edilmez.
2. **Hesap verilerini dışa aktarma:** Profil sayfasında JSON dışa aktarma düğmesi; takma ad/avatar/KP, kendi şikâyetleri, KP işlem geçmişi, engelleri ve itirazlarını döndürür. Gizli profil erişim anahtarı dışa aktarılmaz.
3. **Moderasyon denetim izi:** Yönetici şikâyet kararları, geçici kısıtlama ve kaldırma işlemleri SQLite'a yazılır, sadece yönetici anahtarıyla `/api/admin/audit` üzerinden okunur.
4. **Kısıtlama itirazları:** Kısıtlı oyuncu profilinden 15–500 karakterli, 7 günde en çok bir itiraz oluşturabilir. Yönetici `/moderasyon` ekranından itirazları inceler ve kaydeder. **İtiraz kararı kısıtlamayı kendiliğinden kaldırmaz**; yetkili ayrıca kaldırmalıdır.
5. **Güncellenmiş çevrimdışı arayüz:** `/offline` eski V6 yerine `static/Bestie_V10_Cevrimdisi.html` sunar. Üç temel mod ve mevcut soru bankası tek cihazda çalışır; görseller `static/trivia-img/` içindedir. 18+ içerik kullanılmaz. Yerel KP çevrimiçi hesaba eşitlenmez; çevrimiçi oda, oylama, oyuncu hesaplarıyla tam eşdeğer değildir.
6. **Tutarlı veritabanı yedeği:** `python backup_db.py /guvenli/yedek.sqlite3`.
7. **İçerik risk dökümü:** `V10_ICERIK_RISK_RAPORU.json`. Otomatik yapısal kontroller gerçek kaynak doğrulaması değildir.
8. **Geriye dönük özellikler korundu:** Oyuncu başına son 60 dakikada en fazla 20 yeni oda, 500 aktif oda, 5 ipucu/10 soru, 100/70/40 yarış puanı, görsel sonuç kartı, engelleme, şikâyet, günlük görev, sıralama opt-in.

## Test kapsamı

- `python test_v100_recovery_privacy.py`: oda snapshot/recovery, ipucu sayacı ve reconnect, eski oda temizleme, veri dışa aktarma, yönetici audit, itiraz ve tekrar sınırı.
- `node test_offline_v10.js`: güncel veriyle çevrimdışı üç oyun modunun 10 soruluk akışı, cevap çeşitliliği, görsel üst sınırı, ipucu.
- Önceki `test_rules.py`, `test_hint_budget.py`, `test_content_quality.py`, `test_v95_hardening.py`, `test_v97_privacy_reports.py`, `test_v98_blocking.py`, `test_v99_features.py` ve yerel WebSocket `test_realtime.py` tekrar çalıştırıldı.
- Tarayıcı JS sözdizimi kontrol edildi. Gerçek Android/iOS cihazında otomatik/manuel test **yapılmadı**.

## Hâlâ yayın öncesi ENGEL olan işler

1. **Gerçek yatay ölçekleme ve dayanıklılık:** Şu an odaların kalıcı kopyası tek SQLite dosyasında, aktif RAM durumu tek süreçte. Çok sunuculu dağıtım için PostgreSQL + Redis/dağıtık event bus + atomik oyun durum geçişleri + yük/failover testleri gerekir. Uygulama hâlâ tek worker ile çalıştırılmalı.
2. **Kalıcı güvenli hesap ve kurtarma:** Hâlâ localStorage'da bearer profili ve SQLite'da düz saklanan profil erişim sırrı var. HTTPS/WSS, yönetilen kimlik sağlayıcısı (OAuth/e-posta linki), güvenli oturum, token rotasyonu, cihazlar arası hesap kurtarma, yedekleme ve izin kayıtları gereklidir.
3. **3.500 sorunun tek tek doğrulanması:** 743 benzersiz kategori–cevap eşleşmesi, 1.442 görselli kart. Editoryal onay, iki taraflı doğrulanabilir olgusal kaynak, çeldirici mantığı, tekrar/çeşitlilik ve telif/marka hakları incelenmedi.
4. **Yaş güvenliği ve hukuk:** Yaş beyanı kimlik doğrulaması değildir. Çocuklarla ilgili risk analizi, KVKK aydınlatma metni, veri saklama ve silme süreleri, çerez analizi, telif ve marka incelemesi, Apple/Google mağaza kuralları için uzman onayı yok.
5. **Gizlilik işlemleri:** Profil silmede oyun tablosu/şikâyet gibi satırlar silinir; fakat yedeklerde veri kalabilir. Saklama politikaları, silme süresi, itirazların bağımsız kayıt saklanması ve kayıt talepleri için açık süreç belirlenmeli. Audit kayıtları kullanıcı kimlikleri tutabilir; politikaya bağlanmalı.
6. **Gerçek cihaz ve beta:** iPhone/Android, erişilebilirlik, ağ kesintisi ve yük testi, gerçek kullanıcı retention/viral ölçümü yapılmadı. Kesintisiz internet olmadan offline yerel medya dosyaları cihazda mevcut olmalı.
7. **İçerik üretim kalite kapısı:** Yeni sorular için yayımlamadan önce kayıt bazında kaynak, son kontrol tarihi ve lisans kaydı zorunlu kılınmalı. Mevcut 3.500 kart otomatik olarak yayıma uygun değildir.

## Çalıştırma

```sh
python -m pip install -r requirements.txt
export BESTIE_DB_PATH=/kalici/birim/bestie.sqlite3
export BESTIE_ADMIN_TOKEN='en-az-24-karakterlik-rastgele-gizli-deger'
uvicorn server:app --host 127.0.0.1 --port 8899 --workers 1
```

- `/` canlı WebSocket oyunu, `/offline` tek cihaz V10, `/moderasyon` yönetici ekranı.
- Kalıcı depolaması olmayan ücretsiz barındırma planlarında SQLite verileri silinebilir. Üretim için yönetilen DB gereklidir.
- `BESTIE_ADMIN_TOKEN` istemciye, GitHub'a veya ekran görüntüsüne asla konulmamalı. Public production ortamında yalnız HTTPS/WSS ve güçlü ters proxy kullanılmalı.
- Bu belge hukuki görüş değildir.
