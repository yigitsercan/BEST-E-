"""V10.4 operational regressions: backup/restore, readiness, install metadata."""
from pathlib import Path
import tempfile
import sqlite3
import os
import subprocess
import sys
import json
import asyncio

root=Path(__file__).resolve().parent
assert (root/'static'/'manifest.webmanifest').is_file()
manifest=json.loads((root/'static'/'manifest.webmanifest').read_text())
assert manifest['display']=='standalone' and manifest['scope']=='/'
assert manifest['icons'] and (root/'static'/'bestie-logo.webp').exists()
assert 'rel="manifest"' in (root/'static'/'index.html').read_text()
with tempfile.TemporaryDirectory() as temp:
    base=Path(temp)
    db_path=base/'bestie.sqlite3'
    env=dict(os.environ,BESTIE_DB_PATH=str(db_path),BESTIE_QUESTIONS_PATH=str(root/'data'/'questions.json'))
    # Import once under isolated storage, perform readiness and verify no permanent probe rows.
    code='''
import asyncio, sqlite3, server
assert asyncio.run(server.health()).status_code == 200
with sqlite3.connect(server.DB_PATH) as db:
    assert db.execute('SELECT count(*) FROM health_probe').fetchone()[0] == 0
    db.execute('BEGIN EXCLUSIVE')
    # A second connection should not be able to reserve a write transaction.
    response = asyncio.run(server.health())
    assert response.status_code == 503, response.status_code
    db.rollback()
assert asyncio.run(server.health()).status_code == 200
print('PASS readiness catches locked or unwritable DB')
'''
    r=subprocess.run([sys.executable,'-c',code],cwd=root,env=env,text=True,capture_output=True,timeout=30)
    assert r.returncode==0,r.stdout+r.stderr
    print(r.stdout.strip())
    backup=base/'backup.sqlite3'; restored=base/'restored.sqlite3'
    with sqlite3.connect(db_path) as db:
        db.execute("INSERT INTO profiles VALUES ('p1','super-long-test-secret','Oyuncu','😎',93)")
    for cmd in ([sys.executable,str(root/'backup_db.py'),str(backup)],
                [sys.executable,str(root/'restore_db.py'),str(backup),str(restored)]):
        r=subprocess.run(cmd,cwd=root,env=env,text=True,capture_output=True,timeout=20)
        assert r.returncode==0,r.stdout+r.stderr
    duplicate=subprocess.run([sys.executable,str(root/'backup_db.py'),str(backup)],cwd=root,env=env,capture_output=True)
    assert duplicate.returncode!=0, 'backup must not overwrite existing backup'
    with sqlite3.connect(restored) as db:
        assert db.execute("SELECT kp FROM profiles WHERE id='p1'").fetchone()[0]==93
        assert db.execute('PRAGMA integrity_check').fetchone()[0]=='ok'
    r=subprocess.run([sys.executable,str(root/'restore_db.py'),str(backup),str(restored)],cwd=root,env=env,capture_output=True)
    assert r.returncode!=0,'restore must not overwrite existing DB'
print('PASS backup/restore integrity and overwrite prevention')
print('PASS mobile manifest and icon path')
