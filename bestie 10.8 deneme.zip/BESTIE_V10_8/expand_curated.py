"""Small, explicitly curated content expansion. Not a claim of source verification."""
import json, random
from pathlib import Path
p=Path(__file__).parent/'data/questions.json'
d=json.loads(p.read_text('utf-8'))
random.seed(20261119)
# Format: country, capital, geography region, distinguishing geographical/cultural clue.
capitals=[
('Norveç','Oslo','Kuzey Avrupa','Oslo Fiyordu kıyısında bulunur.'),('İsveç','Stockholm','Kuzey Avrupa','Çok sayıda ada üzerine kurulmuştur.'),('Finlandiya','Helsinki','Kuzey Avrupa','Baltık Denizi kıyısındadır.'),('Danimarka','Kopenhag','Kuzey Avrupa','Zealand Adası üzerinde geniş bir bölümü bulunur.'),('İzlanda','Reykjavík','Kuzey Avrupa','Atlantik Okyanusu kıyısındadır.'),('Estonya','Tallinn','Kuzey Avrupa','Baltık Denizi kıyısında tarihî bir eski kent merkezine sahiptir.'),('Letonya','Riga','Kuzey Avrupa','Daugava Nehri kıyısında bulunur.'),('Litvanya','Vilnius','Kuzey Avrupa','Neris ve Vilnia nehirlerinin birleştiği bölgede bulunur.'),
('İrlanda','Dublin','Batı Avrupa','Liffey Nehri kenti iki yakaya ayırır.'),('Portekiz','Lizbon','Güney Avrupa','Tejo Nehri ağzına yakın bir konumdadır.'),('İspanya','Madrid','Güney Avrupa','İber Yarımadası’nın iç kesimlerinde yer alır.'),('İtalya','Roma','Güney Avrupa','Tiber Nehri kıyısında kurulmuştur.'),('Yunanistan','Atina','Güney Avrupa','Akropolis bu şehirde bulunur.'),('Avusturya','Viyana','Orta Avrupa','Tuna Nehri bu şehirden geçer.'),('Macaristan','Budapeşte','Orta Avrupa','Tuna tarafından iki yakaya ayrılır.'),('Çekya','Prag','Orta Avrupa','Vltava Nehri kıyısındadır.'),('Slovakya','Bratislava','Orta Avrupa','Tuna Nehri kıyısındadır.'),('Polonya','Varşova','Orta Avrupa','Vistül Nehri kıyısında bulunur.'),('Romanya','Bükreş','Doğu Avrupa','Dâmbovița Nehri kentten geçer.'),('Bulgaristan','Sofya','Güneydoğu Avrupa','Vitoşa Dağı eteklerine yakın konumdadır.'),('Sırbistan','Belgrad','Güneydoğu Avrupa','Sava ve Tuna nehirleri burada birleşir.'),('Hırvatistan','Zagreb','Güneydoğu Avrupa','Sava Nehri yakınında yer alır.'),('Slovenya','Ljubljana','Orta Avrupa','Ljubljanica Nehri kent merkezinden geçer.'),('Arnavutluk','Tiran','Güneydoğu Avrupa','Dajti Dağı yakınlarında bulunur.'),('Karadağ','Podgorica','Güneydoğu Avrupa','Morača Nehri kıyısındadır.'),('Kuzey Makedonya','Üsküp','Güneydoğu Avrupa','Vardar Nehri kentin içinden geçer.'),('Bosna-Hersek','Saraybosna','Güneydoğu Avrupa','Miljacka Nehri şehrin içinden geçer.'),('Almanya','Berlin','Orta Avrupa','Spree Nehri bu şehirden geçer.'),('Fransa','Paris','Batı Avrupa','Sen Nehri kıyısındadır.'),('Belçika','Brüksel','Batı Avrupa','Avrupa Birliği kurumlarının önemli merkezlerinden biridir.'),('Hollanda','Amsterdam','Batı Avrupa','Çok sayıda kanalı ve tarihî köprüsü vardır.'),('Lüksemburg','Lüksemburg','Batı Avrupa','Alzette ve Pétrusse vadilerinin çevresindedir.'),('İsviçre','Bern','Orta Avrupa','Aare Nehri tarihî merkezini çevreler.'),
('Kanada','Ottawa','Kuzey Amerika','Ottawa Nehri kıyısındadır.'),('ABD','Washington, D.C.','Kuzey Amerika','Potomac Nehri kıyısındadır.'),('Meksika','Meksiko','Kuzey Amerika','Meksika Vadisi’nde yüksek bir platoda bulunur.'),('Küba','Havana','Karayipler','Karayipler’de kuzeye bakan bir körfez kıyısındadır.'),('Kosta Rika','San José','Orta Amerika','Merkez Vadi bölgesinde bulunur.'),('Panama','Panama City','Orta Amerika','Panama Kanalı’nın Pasifik girişine yakındır.'),('Kolombiya','Bogotá','Güney Amerika','And Dağları üzerindeki yüksek bir platoda bulunur.'),('Peru','Lima','Güney Amerika','Pasifik Okyanusu kıyısındadır.'),('Şili','Santiago','Güney Amerika','And Dağları’nın batı eteklerine yakın bir vadidedir.'),('Arjantin','Buenos Aires','Güney Amerika','Río de la Plata kıyısındadır.'),('Uruguay','Montevideo','Güney Amerika','Río de la Plata’nın kuzey kıyısındadır.'),('Brezilya','Brasília','Güney Amerika','1960 yılında başkent oldu.'),('Ekvador','Quito','Güney Amerika','And Dağları’nda ekvatora yakın bir yüksek kenttir.'),('Paraguay','Asunción','Güney Amerika','Paraguay Nehri kıyısındadır.'),
('Japonya','Tokyo','Doğu Asya','Honşu Adası’nın doğusunda yer alır.'),('Güney Kore','Seul','Doğu Asya','Han Nehri kentten geçer.'),('Çin','Pekin','Doğu Asya','Yasak Şehir burada bulunur.'),('Tayland','Bangkok','Güneydoğu Asya','Chao Phraya Nehri kıyısında yer alır.'),('Vietnam','Hanoi','Güneydoğu Asya','Kızıl Nehir Deltası bölgesindedir.'),('Filipinler','Manila','Güneydoğu Asya','Luzon Adası’nda Manila Körfezi kıyısındadır.'),('Singapur','Singapur','Güneydoğu Asya','Bir ada şehir devletidir.'),('Malezya','Kuala Lumpur','Güneydoğu Asya','Petronas İkiz Kuleleri burada bulunur.'),('Hindistan','Yeni Delhi','Güney Asya','Delhi metropol alanının bir parçasıdır.'),('Nepal','Katmandu','Güney Asya','Himalayalar yakınındaki Katmandu Vadisi’ndedir.'),('Bangladeş','Dakka','Güney Asya','Buriganga Nehri yakınına kurulmuştur.'),('Pakistan','İslamabad','Güney Asya','Margalla Tepeleri’nin eteklerinde yer alır.'),('Moğolistan','Ulan Batur','Doğu Asya','Tuul Nehri vadisinde yer alır.'),('Kazakistan','Astana','Orta Asya','İşim Nehri kıyısında yer alır.'),
('Mısır','Kahire','Kuzey Afrika','Nil Nehri kıyısındadır.'),('Fas','Rabat','Kuzey Afrika','Bou Regreg Nehri ağzında bulunur.'),('Tunus','Tunus','Kuzey Afrika','Tunus Körfezi yakınındadır.'),('Cezayir','Cezayir','Kuzey Afrika','Akdeniz kıyısında bulunur.'),('Kenya','Nairobi','Doğu Afrika','Nairobi Ulusal Parkı kente yakındır.'),('Etiyopya','Addis Ababa','Doğu Afrika','Etiyopya Yaylası üzerinde yer alır.'),('Gana','Akra','Batı Afrika','Gine Körfezi kıyısında bulunur.'),('Senegal','Dakar','Batı Afrika','Cap-Vert Yarımadası’nda bulunur.'),('Nijerya','Abuja','Batı Afrika','1991 yılında ülkenin başkenti olmuştur.'),('Uganda','Kampala','Doğu Afrika','Victoria Gölü yakınında yer alır.'),('Ruanda','Kigali','Doğu Afrika','Ülkenin merkezine yakın tepeler üzerinde yer alır.'),('Zambiya','Lusaka','Güney Afrika bölgesi','İç kesimlerde yüksek bir plato üzerinde yer alır.'),('Zimbabve','Harare','Güney Afrika bölgesi','Ülkenin kuzeydoğusundaki yüksek platodadır.'),('Avustralya','Canberra','Okyanusya','Sydney ve Melbourne arasında iç kesimlerde planlanmıştır.'),('Yeni Zelanda','Wellington','Okyanusya','Kuzey Adası’nın güney ucunda yer alır.'),('Fiji','Suva','Okyanusya','Viti Levu Adası’nın güneydoğusunda yer alır.')]
# Historical events and the associated year, with date-independent valid contextual clues.
history=[
('Berlin Duvarı’nın yıkılması','1989','20. yüzyıl sonlarında Avrupa’da gerçekleşti.','Doğu ve Batı Almanya arasındaki ayrılığı simgeleyen sınır yapısıyla ilgilidir.'),
('Amerikan Bağımsızlık Bildirgesi','1776','18. yüzyılda Kuzey Amerika’da kabul edildi.','On üç koloninin Britanya’dan ayrılma iradesini duyurdu.'),
('Ay’a ilk insanlı iniş','1969','Soğuk Savaş döneminde gerçekleşen uzay başarısıdır.','Apollo 11 görevi kapsamında gerçekleşti.'),
('İlk modern Olimpiyat Oyunları','1896','19. yüzyıl sonunda uluslararası bir spor etkinliğidir.','Atina’da düzenlendi.'),
('Titanic gemisinin batışı','1912','20. yüzyıl başlarında yaşanan deniz faciasıdır.','Atlantik’te buzdağına çarpan yolcu gemisiyle ilgilidir.'),
('Birinci Dünya Savaşı’nın başlaması','1914','20. yüzyılın başında gerçekleşti.','Saraybosna suikastının ardından Avrupa’da savaş büyüdü.'),
('İkinci Dünya Savaşı’nın sona ermesi','1945','20. yüzyıl ortasında küresel bir dönüm noktasıdır.','Avrupa’da mayısta, Pasifik’te eylülde sona erdi.'),
('Birleşmiş Milletler’in kurulması','1945','İkinci Dünya Savaşı sonrasında gerçekleşti.','Uluslararası barış ve güvenlik için oluşturulmuş bir örgütle ilgilidir.'),
('Türkiye Cumhuriyeti’nin ilanı','1923','20. yüzyılın ilk çeyreğinde gerçekleşti.','Ankara merkezli yeni devlet rejiminin resmen ilanıdır.'),
('Lozan Barış Antlaşması','1923','Birinci Dünya Savaşı sonrasındaki diplomatik anlaşmadır.','İsviçre’de müzakere edilen Türkiye ile ilgili antlaşmadır.'),
('Süveyş Kanalı’nın açılışı','1869','19. yüzyılda ulaşımı dönüştüren gelişmedir.','Akdeniz ile Kızıldeniz arasında gemi geçişini mümkün kıldı.'),
('Panama Kanalı’nın açılışı','1914','20. yüzyıl başlarında deniz ticaretini etkiledi.','Atlantik ile Pasifik arasında Orta Amerika üzerinden geçiş sağladı.'),
('Wright kardeşlerin motorlu uçuşu','1903','20. yüzyıl başlarında havacılık tarihindeki bir gelişmedir.','Kuzey Karolina’daki Kitty Hawk yakınlarında gerçekleşti.'),
('İlk yapay uydu Sputnik 1’in fırlatılması','1957','Soğuk Savaş dönemindeki uzay yarışının önemli adımıdır.','Sovyetler Birliği’nin uzaya gönderdiği uyduyla ilgilidir.'),
('İlk insanın uzaya çıkması','1961','Uzay yarışının dönüm noktalarından biridir.','Yuri Gagarin’in Vostok 1 uçuşuyla gerçekleşti.'),
('Çernobil nükleer kazası','1986','20. yüzyıl sonlarında yaşanan nükleer kazadır.','Ukrayna’da, o dönemde Sovyetler Birliği’ndeki santralde gerçekleşti.'),
('Hindistan’ın bağımsızlığı','1947','20. yüzyıl ortalarında sömürge yönetiminden ayrılmadır.','Britanya yönetiminden bağımsızlık kazanılmasıyla ilgilidir.'),
('Güney Afrika’da ilk genel oy hakkına dayalı ulusal seçim','1994','20. yüzyıl sonlarında yaşanan siyasi dönüm noktasıdır.','Apartheid sonrası Nelson Mandela’nın cumhurbaşkanlığına uzanan seçimdir.'),
('Avro banknot ve madeni paralarının dolaşıma girişi','2002','21. yüzyıl başlarında Avrupa’daki parasal dönüşümdür.','Birçok Avrupa ülkesinde ortak fiziksel para kullanımı başladı.'),
('Hubble Uzay Teleskobu’nun fırlatılması','1990','20. yüzyıl sonunda astronomiyi etkileyen görevdir.','NASA ve ESA’nın yörüngedeki uzay teleskobuyla ilgilidir.')]
# Films: director answers (distinct from films already used as answers in this category).
films=[
('Jaws','Steven Spielberg','1975','Köpekbalığı gerilimi'),('Pulp Fiction','Quentin Tarantino','1994','Suç ve çok katmanlı anlatı'),('Spirited Away','Hayao Miyazaki','2001','Japon animasyonu'),('Parasite','Bong Joon-ho','2019','Güney Kore gerilimi'),('The Grand Budapest Hotel','Wes Anderson','2014','Stilize komedi-drama'),('Interstellar','Christopher Nolan','2014','Bilimkurgu'),('Titanic','James Cameron','1997','Romantik felaket filmi'),('The Godfather','Francis Ford Coppola','1972','Suç draması'),('The Shape of Water','Guillermo del Toro','2017','Fantastik dram'),('La La Land','Damien Chazelle','2016','Müzikal'),('The Piano','Jane Campion','1993','Dönem draması'),('Lost in Translation','Sofia Coppola','2003','Dram'),('Nomadland','Chloé Zhao','2020','Yol draması'),('Get Out','Jordan Peele','2017','Korku-gerilim'),('The Favourite','Yorgos Lanthimos','2018','Tarihî kara komedi')]
# Music: performers on specific notable compositions, not broad guess-the-artist cards.
music=[('Bohemian Rhapsody','Queen','1975','Rock'),('Dancing Queen','ABBA','1976','Pop'),('Smells Like Teen Spirit','Nirvana','1991','Grunge'),('Billie Jean','Michael Jackson','1982','Pop'),('Like a Prayer','Madonna','1989','Pop'),('Rolling in the Deep','Adele','2010','Soul-pop'),('Blinding Lights','The Weeknd','2019','Synth-pop'),('Bad Romance','Lady Gaga','2009','Dance-pop'),('Back to Black','Amy Winehouse','2006','Soul'),('Shape of You','Ed Sheeran','2017','Pop'),('Crazy in Love','Beyoncé','2003','R&B'),('Wonderwall','Oasis','1995','Britpop'),('Nothing Else Matters','Metallica','1991','Rock'),('Imagine','John Lennon','1971','Rock-pop'),('Hallelujah','Leonard Cohen','1984','Folk-rock'),('Get Lucky','Daft Punk','2013','Disco-funk'),('Take On Me','a-ha','1984','Synth-pop'),('Africa','Toto','1982','Rock'),('Zombie','The Cranberries','1994','Alternatif rock'),('Lose Yourself','Eminem','2002','Hip-hop')]

def add(cat, cards):
    existing=d['trivia'][cat]
    ids={q['id'] for q in existing}
    seen={(q['text'].casefold(),q['answer'].casefold()) for q in existing}
    n=0
    for q in cards:
        if (q['text'].casefold(),q['answer'].casefold()) in seen:continue
        i=1
        while f'TE-NEW-{cat.upper()}-{i:04d}' in ids:i+=1
        q['id']=f'TE-NEW-{cat.upper()}-{i:04d}'
        q['entity']=q['answer'] # Match selection uniqueness by answer
        q['difficulty']='orta'
        q['editorial_status']='yeni kürasyon - dış kaynak ve uzman doğrulaması gerekli'
        existing.append(q);ids.add(q['id']);seen.add((q['text'].casefold(),q['answer'].casefold()));n+=1
    return n

def options(a,pool,i):
    others=list(dict.fromkeys(x for x in pool if x!=a))
    r=random.Random(8001+i)
    return r.sample(others,min(3,len(others)))+[a]

def shuffled(o,i):
    r=random.Random(8021+i);r.shuffle(o);return o

geo=[]
for i,(country,city,region,feature) in enumerate(capitals):
    if country in {'Lüksemburg','Singapur','Tunus','Cezayir'}: continue  # City-country name reveals the answer in prompt.
    feature={'Oslo':'Başkent, ülkenin güneydoğusundaki bir fiyordun sonunda kurulmuştur.','Ottawa':'Ontario eyaletinin doğusunda, Quebec sınırı yakınlarında bulunur.','Manila':'Luzon Adası’nda geniş bir körfez kıyısındadır.','Katmandu':'Himalayalar yakınındaki yüksek bir vadide kurulmuştur.','Nairobi':'Büyük bir ulusal park, kentin hemen güneyindedir.'}.get(city,feature)
    # Familiar geography and capital city, with factual regional clue and a distinctive additional landmark.
    candidate=[v[1] for v in capitals if v[2]==region and v[1]!=city]
    if len(candidate)<3:candidate=[v[1] for v in capitals if v[1]!=city]
    choices=shuffled(options(city,candidate,i),i)
    geo.append({'text':f'{country} ülkesinin başkenti hangi şehirdir?', 'hints':[f'{region} bölgesindeki bir başkenttir.',f'{country} ülkesinin yönetim merkezidir.',feature], 'options':choices,'answer':city})
# In geography, 3 hints should provide information without directly naming capital; the country is in the prompt.
print('geography',add('geography',geo))
hst=[]
for i,(event,year,era,detail) in enumerate(history):
    # Correct response is the event, not a date; answer unique from other events.
    others=[e[0] for e in history if e[0]!=event]
    hst.append({'text':f'{year} yılında gerçekleşen tarihî gelişme hangisidir?', 'hints':[era,detail,'Olayı verilen tarihle birlikte düşün.'], 'options':shuffled(options(event,others,i),i),'answer':event})
print('history',add('history',hst))
fil=[]
for i,(film,director,year,genre) in enumerate(films):
    fil.append({'text':f'{film} ({year}) filminin yönetmeni kimdir?', 'hints':[f'{genre} türünde bir yapımdır.',f'{year} yılında gösterime girmiştir.','Yönetmen filmografisiyle ilgili bir sorudur.'], 'options':shuffled(options(director,[x[1] for x in films],i),i),'answer':director})
print('movie',add('movie',fil))
mus=[]
for i,(song,artist,year,genre) in enumerate(music):
    mus.append({'text':f'"{song}" ({year}) şarkısını hangi sanatçı veya grup seslendirdi?', 'hints':[f'{genre} türünde tanınan bir eserdir.',f'{year} yılında yayımlandı.','Şarkıyı seslendiren ismi seç.'], 'options':shuffled(options(artist,[x[1] for x in music],i),i),'answer':artist})
print('music',add('music',mus))
p.write_text(json.dumps(d,ensure_ascii=False,indent=2),'utf-8')
