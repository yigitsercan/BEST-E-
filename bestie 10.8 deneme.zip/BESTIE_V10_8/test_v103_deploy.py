"""Deployment regressions: asset storage is separated from persistent SQLite disk."""
from pathlib import Path
import os
import subprocess
import sys
import tempfile
import json
import yaml

ROOT=Path(__file__).resolve().parent
config=yaml.safe_load((ROOT/'render.yaml').read_text(encoding='utf-8'))
service=config['services'][0]
assert service['numInstances']==1
assert service['disk']['mountPath']=='/app/data'
settings={e['key']:e.get('value') for e in service['envVars']}
assert settings['BESTIE_DB_PATH']=='/app/data/bestie.sqlite3'
assert settings['BESTIE_QUESTIONS_PATH']=='/app/content/questions.json'
assert settings['BESTIE_MAX_NEW_ROOMS_PER_HOUR']=='20'
assert 'COPY data/questions.json ./content/questions.json' in (ROOT/'Dockerfile').read_text()
assert "script_policy = \"script-src 'self'\"" in (ROOT/'server.py').read_text()
for doc in ('index.html','moderasyon.html'):
    html=(ROOT/'static'/doc).read_text()
    assert '<script src="/static/' in html
    assert '<script>' not in html
for js in ('bestie.js','moderasyon.js'):
    subprocess.run(['node','--check',str(ROOT/'static'/js)],check=True,capture_output=True)
with tempfile.TemporaryDirectory() as tmp:
    base=Path(tmp)
    (base/'content').mkdir()
    (base/'data').mkdir()
    # Mimics a deployment where /app/data is a fresh, empty mounted disk.
    (base/'content'/'questions.json').write_bytes((ROOT/'data'/'questions.json').read_bytes())
    env=os.environ.copy()
    env.update(BESTIE_DB_PATH=str(base/'data'/'bestie.sqlite3'), BESTIE_QUESTIONS_PATH=str(base/'content'/'questions.json'))
    result=subprocess.run([sys.executable,'-c',
        "import server; assert len(server.QUESTIONS['trivia']['footballer'])==700; print('volume-separated startup passed')"],
        cwd=ROOT,env=env,capture_output=True,text=True,timeout=25)
    assert result.returncode==0, result.stderr
    assert (base/'data'/'bestie.sqlite3').is_file()
    print(result.stdout.strip())
print('PASS V10.3: render disk mount layout, clean disk bootstrap, CSP JS separation, 20 rooms/hour')
