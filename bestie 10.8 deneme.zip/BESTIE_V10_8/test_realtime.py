import asyncio,json,websockets,urllib.request,random,string,os
URL=os.environ.get('BESTIE_TEST_WS_URL','ws://127.0.0.1:8899/ws')
async def recv_type(w,kind='room',timeout=5):
 while True:
  d=json.loads(await asyncio.wait_for(w.recv(),timeout))
  if d['type']=='error':raise Exception('Server error: '+d['message'])
  if d['type']==kind:return d['data']
async def send(w,a,d={}):await w.send(json.dumps({'action':a,'data':d}))
async def main():
 async with websockets.connect(URL) as w1,websockets.connect(URL) as w2:
  await send(w1,'init',{'nickname':'Online Oyuncu A','avatar':'😎'})
  p1=await recv_type(w1,'profile')
  await send(w2,'init',{'nickname':'Online Oyuncu B','avatar':'💀'})
  p2=await recv_type(w2,'profile')
  await send(w1,'create',{'mode':'kim_daha','category':'KIM_DAHA','max_players':2})
  a=await recv_type(w1);code=a['code'];assert len(code)==6 and a['phase']=='lobby'
  await send(w2,'join',{'code':code})
  a=await recv_type(w1);b=await recv_type(w2)
  assert a['code']==b['code'] and len(a['players'])==2
  await send(w1,'ready',{'ready':True});a=await recv_type(w1);b=await recv_type(w2)
  await send(w2,'ready',{'ready':True});a=await recv_type(w1);b=await recv_type(w2)
  await send(w1,'start');a=await recv_type(w1);b=await recv_type(w2)
  assert a['phase']==b['phase']=='question' and a['question']['id']==b['question']['id']
  await send(w1,'answer',{'answer':p2['id']})
  a=await recv_type(w1);b=await recv_type(w2)
  assert a['answered_count']==1 and not a.get('results') and not b.get('results')
  await send(w2,'answer',{'answer':p1['id']})
  a=await recv_type(w1);b=await recv_type(w2)
  assert a['phase']==b['phase']=='result'
  assert a['results']['votes']=={p2['id']:1,p1['id']:1}
  print('PASS: create/join/ready/start/vote sync/result; room',code)
  # Reconnect from a new socket using the server-issued profile secret.
  await w2.close()
  b=await recv_type(w1)
  assert not [p for p in b['players'] if p['id']==p2['id']][0]['online']
  async with websockets.connect(URL) as w3:
   await send(w3,'init',{'secret':p2['secret']})
   p3=await recv_type(w3,'profile');assert p3['id']==p2['id']
   await send(w3,'join',{'code':code})
   a=await recv_type(w1);b=await recv_type(w3)
   assert len(b['players'])==2 and all(p['online'] for p in b['players'])
   print('PASS: reconnect preserved room identity and game state')
 async with websockets.connect(URL) as w4,websockets.connect(URL) as w5:
  await send(w4,'init',{'nickname':'Random One'});r1=await recv_type(w4,'profile')
  await send(w5,'init',{'nickname':'Random Two'});r2=await recv_type(w5,'profile')
  await send(w4,'matchmake',{'mode':'trivia','category':'footballer'})
  m=await recv_type(w4,'matching');assert m['waiting']
  await send(w5,'matchmake',{'mode':'trivia','category':'footballer'})
  a=await recv_type(w4);b=await recv_type(w5)
  assert a['phase']==b['phase']=='question' and a['code']==b['code']
  assert len(a['question']['hints'])==1
  assert 'correct_answer' not in a['question']
  print('PASS: real queue, random pair, hidden trivia answer')
asyncio.run(main())
