# BESTIE? V9.3 — Kaynak paketinde doğrulanmış ilerleme

## Gerçekte uygulanan
- V9.2'nin sunucusu, beş ipucu bütçesi, oyun akışları, KP/Level hesapları ve 30 görseli korundu.
- `expand_curated.py` ile **128 ek taslak bilgi sorusu** eklendi: Coğrafya **73** (başkentler); Tarih **20** (olay-yıl); Film & Dizi **15** (yönetmenler); Müzik & Sanatçı **20** (şarkı-sanatçı). Diğer 6 kategoriye bu turda yeni içerik eklenmedi.
- Toplam `trivia`: **1.960 → 2.088**. Benzersiz kategori-cevap eşleşmesi **625 → 743**. Önemli: bu 743 sayısı benzersiz soru sayısı değildir; aynı kişi/takım adına birden çok kart olabilir.
- Coğrafyada cevabı soru metninden açık eden şehir-devlet adları ayıklandı. Yeni sorulardaki doğrudan cevabı gösteren ipucu ifadeleri temizlendi.
- Soru seçimi, maç başına aynı doğru cevabı tekrarlamıyor; görsel kartlar maksimum 3; ipucu puanları 100/70/40, hak sayısı 5.
- Yeni içeriğin tekrar çalıştırıldığında kopyalanmasını engelleyen idempotent üretim betiği korundu.

## Testler
- `python quality_guard.py`: 4 seçenek, doğru cevabın seçeneklerde olması, 3 ipucu, görsel dosyası bulunması, cevap sızıntısı, yinelenen kart ID denetimi — **sıfır yapısal sorun**.
- `python test_content_quality.py`: 10 kategori + karışık modda toplam 1.650 rastgele maç — **geçti**.
- `python test_rules.py` — **geçti**.
- `python test_hint_budget.py` — **geçti**.
- `uvicorn server:app --host 127.0.0.1 --port 8899` ile sunucu çalışırken `python test_realtime.py` — **geçti**. Bu test gerçek internet/dağıtım testi değildir.

## Açık işler
- 7.500 hedefine **5.412 yeni kart**, resimli 2.500 hedefine **2.470 resimli kart** daha gereklidir.
- Yeni 128 sorunun bilgileri elle kürasyonla hazırlanmış ancak **bağımsız kaynak kontrolü ve insan editör onayı yapılmamıştır**. `editorial_status` alanlarında bu açıkça işaretlidir. Özellikle dönem, sanatçı ve başkent bilgileri yayımdan önce doğrulanmalı.
- 141 eski otomatik değiştirilmiş ipucunun bir kısmı hâlâ geneldir; editoryal özgünleştirme gerektirir.
- V9.1'den kalan `static/Bestie_V6_Cevrimdisi.html` dosyası gömülü eski soru bankasını taşımaktadır: yeni sorular **sunuculu modda** çalışır, eski çevrimdışı dosyaya otomatik yansımaz.
- Bazı eski cevaplar farklı kart varyasyonlarıyla tekrar edilir; 2.088 rakamı 2.088 ayrı konu değildir.
- Canlı dağıtım, üretim güvenliği, kalıcı sunucu doğrulaması ve gerçekte farklı cihazlardan uzun süreli yük testi bu teslimde yapılmadı.
- Bu sürümü **7.500 soru tamamlandı** veya **2.500 resim tamamlandı** olarak göstermeyin.

## Çalıştırma
```bash
pip install -r requirements.txt
uvicorn server:app --host 0.0.0.0 --port 8000
```
Uygulama yerel makinede `http://localhost:8000` adresinden açılır. Çevrimiçi kullanım için ayrı sunucu barındırma ve güvenlik yapılandırması gerekir.
