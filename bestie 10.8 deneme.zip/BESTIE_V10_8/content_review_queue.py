"""Create an editor-facing review queue. This is NOT a factual verification service."""
import csv
import json
import re
from collections import Counter
from pathlib import Path

ROOT=Path(__file__).resolve().parent
cards=json.loads((ROOT/'data/questions.json').read_text(encoding='utf-8'))['trivia']
counts=Counter((cat,c.get('answer','').strip().casefold()) for cat,rows in cards.items() for c in rows)
out=ROOT/'CONTENT_REVIEW_QUEUE.csv'
summary=Counter()
with out.open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.writer(f)
    w.writerow(['id','category','question','answer','repeats_of_same_answer','image','image_exists','visual_rights','editorial_status','structural_issues','human_fact_check','human_visual_rights_check','sources'])
    for cat,rows in cards.items():
        for c in rows:
            answer=c.get('answer','').strip()
            issues=[]
            if len(c.get('options',[]))!=4 or len(set(c.get('options',[])))!=4 or answer not in c.get('options',[]):issues.append('answer/options mismatch')
            if len(c.get('hints',[]))!=3:issues.append('hint count')
            for hint in c.get('hints',[]):
                if re.search(r'(?<!\w)'+re.escape(answer)+r'(?!\w)',hint,flags=re.IGNORECASE):
                    issues.append('answer appears in hint');break
            img=c.get('image') or ''
            exists=not img or (ROOT/img.lstrip('/').replace('static/','static/',1)).exists()
            if not exists:issues.append('missing image')
            if counts[(cat,answer.casefold())]>1:summary['cards_with_repeated_answer']+=1
            if issues:summary['cards_with_structural_flags']+=1
            summary['total_cards']+=1
            if img:summary['image_cards']+=1
            w.writerow([c.get('id'),cat,c.get('text'),answer,counts[(cat,answer.casefold())],img,exists,c.get('visual_rights',''),c.get('editorial_status',''),'; '.join(issues),'PENDING','PENDING',''])
(ROOT/'CONTENT_REVIEW_SUMMARY.json').write_text(json.dumps({**dict(summary), 'distinct_answer_category_pairs':len(counts),
 'verified_fact_cards':0,'rights_review_complete':False,
 'note':'Review queue is structural only; human editors must provide authoritative source and approve each question and image.'},ensure_ascii=False,indent=2),encoding='utf-8')
print('Review queue generated:',summary)
