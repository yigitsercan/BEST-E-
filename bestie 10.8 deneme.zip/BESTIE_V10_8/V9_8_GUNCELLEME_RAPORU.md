# BESTIE? V9.8 — Oyuncu engelleme ve paylaşılabilir görsel sonuç

## V9.7'ye göre yapılan değişiklikler

1. **Oyuncu engelleme:** Mevcut odada başka oyuncu engellenebilir; SQLite `player_blocks` tablosunda kaydedilir. Engel karşılıklıdır: yeni odalara katılma ve rastgele eşleşme sırasında engelleyen/engellenen aynı maça düşmez. Halihazırda devam eden oyun bölünmez.
2. **Engel yönetimi:** Profil ekranındaki `ENGELLEDİĞİM OYUNCULAR` seçeneğiyle listeleme ve engel kaldırma. Hesap silinince ilgili blok kayıtları da silinir.
3. **Görsel maç özeti:** Biten maçtan kullanıcı onayıyla 1080x1350 PNG skor kartı oluşturulur. Desteklenen mobil cihazlarda yerel paylaşım menüsü, diğerlerinde PNG indirme kullanılır. Kullanıcı onayı olmadan paylaşılmaz.
4. **Korunan mevcut özellikler:** 3.500 kart, 1.442 görsel, maçta en fazla 3 resimli soru, 5 ek ipucu, 100/70/40 puan, saatlik 20 oda, 500 aktif oda sınırı, şikâyet ve hesap silme sistemi.

## Testler

- `test_realtime.py`: gerçek WebSocket create/join/vote/reconnect/matchmake — geçti (yerel sunucuda).
- `test_rules.py`, `test_hint_budget.py` — geçti.
- `test_v95_hardening.py`, `test_v97_privacy_reports.py` — geçti.
- `test_v98_blocking.py` — kalıcı engel, oda katılımını reddetme, rastgele eşleşme ayrıştırma, hesap silince temizlik — geçti.
- `test_content_quality.py`: 1.650 simülasyon maçı ve yapısal soru kontrolü — geçti.
- `static/index.html` iç JavaScript sözdizimi Node.js ile kontrol edildi — geçti.

## Yayın öncesi **halen açık** işler

- Tek işlem belleğine bağlı odalar, kuyruk ve oda limiti: çoklu sunucu ve yeniden başlatma dayanıklılığı için kalıcı/dağıtık state (Redis ve/veya PostgreSQL) gerekiyor.
- SQLite profiller geçici disk üzerinde kaybolabilir; kalıcı güvenli hesap, kurtarma, veri yedekleme ve barındırma yapılandırması yok.
- Şikâyetleri gözden geçiren yönetici paneli, içerik moderasyonu, yaptırım ve itiraz süreçleri henüz yok. Kullanıcı engellemesi yönetici banının yerini almaz.
- Yaşa uygun içerik, KVKK aydınlatma, veri saklama süreleri, başvuru ve telif incelemesi tamamlanmadı.
- 3.500 trivia kartı yalnızca 743 kategori/cevap eşleşmesi içeriyor; tüm olguların kaynağa dayalı editoryal denetimi yapılmadı.
- `/offline` eski prototip; V9.8 ile eşitlenmedi. Günlük görev/arkadaş sıralaması ve ürün analitiği henüz eklenmedi.
- Gerçek cihazlarda PNG paylaşımı, erişilebilirlik, performans, güvenlik ve kapalı beta testleri gerçekleştirilmedi.

**Önemli:** Bu sürüm yerelde test edilmiş bir prototiptir; canlı hizmete otomatik dağıtılmadı, hukukî onay veya ticari yayın uygunluğu garantisi yoktur.
