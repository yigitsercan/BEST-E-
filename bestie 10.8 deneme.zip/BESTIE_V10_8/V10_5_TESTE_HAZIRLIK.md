# BESTIE? V10.5 — Test teslim raporu

**Tarih:** 2026-11-20

## Düzeltmeler
- V10.4'te eski V8/ücretsiz Render adımlarını anlatan README güncel V10.5 tek-worker/kalıcı disk kurulumu olarak yeniden yazıldı.
- Mobil PWA tanımı için gerçek 192x192 ve 512x512 PNG ikonlar eklendi, Apple dokunma ikonu belirtildi.
- `preflight.py` Docker içerik yolunu ve yerel yolu ayırarak kontrol eder; mobil ikonları doğrular ve hiçbir ortam değişkeniyle hukuk/içerik/cihaz onaylarını taklit etmez.
- Tek komutluk otomatik regresyon test çalıştırıcısı (`run_tests.py`) ve Windows/Mac-Linux başlatma dosyaları eklendi.
- ZIP'te örnek sunucu veritabanı, Python önbelleği, `.env` ve gerçek kullanıcı sırları yer almaz.
- Soru bankası ve mevcut oyun mekanikleri değiştirilmedi.

## Doğrulanan sonuçlar
- **13/13** yerel test dosyası geçti (`python run_tests.py`). `test_realtime.py` ve `test_v104_concurrency.py` sunucu gerektirdiği için ayrı çalıştırıldı.
- Gerçek yerel WebSocket üzerinden oda oluşturma, odaya katılma, hazır olma, oylama, sonuç, yeniden bağlanma ve rastgele eşleştirme **geçti** (ayrı 8897 portunda temiz sunucu).
- **24 bağlantı / 24 oda** küçük eşzamanlılık denemesi **geçti**; kapasite testi değildir.
- `/health`, web manifest ve iki mobil ikon sunucudan HTTP 200 döndü.
- 3.500 kart ve mevcut 1.442 görselli kart korundu; bilgi kaynakları bağımsız olarak doğrulanmadı.

## Bilinen sınırlamalar / devam eden yayın engelleri
- Gerçek bulut sunucusunda HTTPS/WSS, kalıcı disk yeniden başlatma ve yüksek trafik testleri yapılmadı.
- Gerçek iPhone/Android cihaz testi henüz yapılmadı.
- E-posta/Passkey tabanlı kimlik, çok sunuculu ölçekleme ve üretim kapasite doğrulaması yok.
- 3.500 kartın bağımsız kaynak ve görsel kullanım hakları doğrulaması tamamlanmadı.
- KVKK, yaş güvenliği, mağaza ve telif hukukuna uygunluk için uzman/işletme onayı gerekiyor.

**Karar:** Davetli, kontrollü yerel/özel test için paket hazır. Büyük ölçekli ve herkese açık ticari yayın için henüz doğrulanmış değil.
