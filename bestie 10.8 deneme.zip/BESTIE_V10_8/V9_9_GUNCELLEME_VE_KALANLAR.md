# BESTIE? V9.9 — Uygulananlar, doğrulananlar, kalanlar

Bu sürüm V9.8 üzerine inşa edilmiştir; **ticari yayına uygunluk onayı değildir**.

## Uygulanan kod değişiklikleri

1. **Moderasyon yönetim paneli:** `/moderasyon` üzerinden bekleyen/tamamlanan şikâyetleri görüntüleme, şikâyeti inceledi/reddetti olarak işaretleme ve not ekleme. İlgili uç noktalar `/api/admin/reports` ve `/api/admin/sanctions`. `BESTIE_ADMIN_TOKEN` (en az 24 karakter) tanımlanmadıkça panel kapalıdır. Anahtar tarayıcıda saklanmaz ve son kullanıcı dosyalarına gömülmez. Yetkisiz API erişimleri engellenir.
2. **Geçici oyun kısıtlamaları:** Yetkili yönetici saat cinsinden (1–720 saat) yeni oda oluşturma/odaya katılma/rastgele eşleşme yasağı koyabilir ve kaldırabilir. Devam eden oyunu otomatik sonlandırmaz; itiraz sistemi yoktur.
3. **Oda oluşturma sınırı:** Son 60 dakikada oyuncu başına 20 oda kuralı artık SQLite tablosunda tutulur; aynı kalıcı DB ile tek süreç yeniden başlatıldığında da korunur. **Birden fazla ayrı DB kullanan sunucuya ölçeklenmez.**
4. **Haftalık sıralama:** Oyuncuların açık rızayla dahil olduğu, varsayılan olarak kapalı haftalık KP listesi; yalnızca V9.9'dan itibaren tutulan maç KP kayıtlarını sayar. Mevcut KP geçmişi geriye dönük eklenmez. Hesap silinince kayıtlar temizlenir.
5. **Tekrarlı KP işlemleri:** Her maç/oyuncu için tekil defter kaydı, uygulama tekrarında ikinci KP aktarımını önler. Geçmiş dönem verileri geriye dönük eklenmez.
6. **Günlük meydan okuma:** İstanbul takvim gününe göre aynı 5 soruyu sunan, hesap başına günde bir deneme. Puanı maç KP'si değildir; sınırsız yeniden oynayarak KP çiftleme yoktur. Cevap doğru yanıt verilmeden istemciye gönderilmez. Maçtan bağımsız puan sistemi.
7. **Şeffaf prototip uyarıları:** Çevrimdışı/tekli düğmelerinin henüz V6 prototipe gittiği ve çevrimiçi servis verilerinin barındırmaya bağlı olduğu kullanıcıya belirtilir.

## Testler

- `python test_rules.py`: 3 oyun modunun tur/KP kuralları geçti.
- `python test_hint_budget.py`: 5 ek ipucu ve 100/70/40 geçti.
- `python test_content_quality.py`: 1.650 simülasyon maçı ve yapısal veri taraması geçti; **olgusal doğruluk denetimi değildir**.
- `python test_v95_hardening.py`, `python test_v97_privacy_reports.py`, `python test_v98_blocking.py`: regresyon testleri geçti.
- `python test_v99_features.py`: moderasyon API kimlik doğrulaması, yönetici kararları, kısıtlama, kalıcı oda açma sayacı, sıralama opt-in, günlük soru/tek deneme testi geçti.
- `python test_realtime.py`: çalıştırılan yerel Uvicorn sunucusunda iki WebSocket istemcisiyle oda, sonuç ve yeniden bağlanma geçti.
- `node --check`: tarayıcı JavaScript sözdizimi geçti. **Gerçek telefonlarda kullanım testi yapılmadı.**

## Yayına geçmeden önce tamamlanması gerekenler

1. **Kalıcı oda ve yatay ölçekleme:** ROOMS, SOCKETS, MATCH_QUEUE bellekte; sunucu yeniden başlarsa aktif maç kaybolur. Redis/PostgreSQL, senkron olay kuyruğu ve dağıtık test gerekir.
2. **Kalıcı yönetilen veritabanı / güvenli oturum:** SQLite sunucu diski geçiciyse KP, moderasyon ve kullanıcı verileri kaybolur. Üretimde yönetilen PostgreSQL, kimlik doğrulama, hesap kurtarma, yedek, erişim denetimi, güvenli oturum saklama gerekir. Şimdiki profil anahtarı tarayıcı localStorage'ında bulunur.
3. **Moderasyon süreçleri:** Yönetici paneli temel prototiptir; çoklu yönetici rolleri, denetim izi, itiraz/geri dönüş, rapor saklama ve otomatik veri silme politikaları eksiktir.
4. **İçerik doğruluğu:** 3.500 Tahmin Et! kartının büyük bir kısmı varyant; 743 farklı kategori-cevap eşleşmesi ve 1.442 resimli kart vardır. 1.412 yeni görselin bir kısmı metin temelli SVG ipucu tasarımıdır. Her kartın bilgisi, telif/marka durumu ve kaynak lisansı tek tek onaylanmamıştır.
5. **Çevrimdışı/tekli eşitliği:** `/offline` V6 içeriği kullanır. V9.9 soru bankası, görseller, puanlar ve oyun kuralları ile aynı düzeye getirilmelidir.
6. **Yaş ve hukuki uygunluk:** Yaş beyanı teknik doğrulama değildir. KVKK, çocukların kişisel verileri, veri saklama/silme, kullanım koşulları, açık lisanslar, marka-telif, App Store/Google Play gereklilikleri için hukuk/uzman onayı gerekir.
7. **Beta ve cihaz testleri:** iOS, Android, yavaş bağlantı, uzun süreli oda, bağlantı kaybı, yük testi, gerçek kullanıcı tutma ve viral paylaşım ölçümü eksik.

## Yerel çalıştırma

```bash
pip install -r requirements.txt
export BESTIE_ADMIN_TOKEN='GUCLU_VE_TAHMIN_EDILEMEZ_EN_AZ_24_KARAKTER'
uvicorn server:app --host 127.0.0.1 --port 8899
```

`http://127.0.0.1:8899/` ana oyun; `/moderasyon` moderasyon arayüzü. Gerçek internet ortamında yalnızca HTTPS/WSS ile erişime açılmalı, `BESTIE_DB_PATH` kalıcı diske işaret etmeli. Test/işletim için admin anahtarı sunucu ortamına yazılmalı, kod deposuna yüklenmemeli.
