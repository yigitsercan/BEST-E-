"""Safely restore a stopped Bestie SQLite database from a backup.

Usage: python restore_db.py /path/to/backup.sqlite3 /path/to/new-db.sqlite3
Does NOT overwrite an existing destination. Stop the app during restore.
"""
from pathlib import Path
import sqlite3
import sys

if len(sys.argv)!=3:
    raise SystemExit('Usage: python restore_db.py BACKUP.sqlite3 NEW_DB.sqlite3')
source=Path(sys.argv[1]).expanduser().resolve()
target=Path(sys.argv[2]).expanduser().resolve()
if not source.is_file() or target.exists() or source==target:
    raise SystemExit('Source missing or target exists: refusing restore')
with sqlite3.connect(f'file:{source}?mode=ro',uri=True) as backup:
    if backup.execute('PRAGMA integrity_check').fetchone()[0]!='ok':
        raise SystemExit('Backup integrity check failed')
    target.parent.mkdir(parents=True,exist_ok=True)
    try:
        with sqlite3.connect(target) as restored:
            backup.backup(restored)
            if restored.execute('PRAGMA integrity_check').fetchone()[0]!='ok':
                raise RuntimeError('Restored DB failed integrity check')
    except BaseException:
        target.unlink(missing_ok=True)
        raise
print('Restored to:',target)
