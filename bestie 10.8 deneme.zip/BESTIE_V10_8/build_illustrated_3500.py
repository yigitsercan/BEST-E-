"""Produce one original vector illustrated clue card for each selected existing fact pattern.
These are explicitly editorial drafts/alternate questions, NOT 1,412 independently checked new facts.
No copyrighted third-party visual assets, logos, portraits or artwork are incorporated.
"""
from pathlib import Path
import json, html, hashlib, random, re, textwrap
from collections import Counter
ROOT=Path(__file__).resolve().parent
P=ROOT/'data/questions.json'
D=json.loads(P.read_text('utf-8'))
TARGET={'footballer':200,'footballclub':200,'basketballer':120,'basketballclub':120,'volleyballer':120,'volleyballclub':120,'history':130,'geography':180,'movie':120,'music':102}
assert sum(TARGET.values())==1412
ICONS={'footballer':'⚽','footballclub':'⚽','basketballer':'🏀','basketballclub':'🏀','volleyballer':'🏐','volleyballclub':'🏐','history':'⌛','geography':'🌍','movie':'▣','music':'♫'}
LABELS={'footballer':'FUTBOLCU','footballclub':'FUTBOL KULÜBÜ','basketballer':'BASKETBOLCU','basketballclub':'BASKETBOL KULÜBÜ','volleyballer':'VOLEYBOLCU','volleyballclub':'VOLEYBOL KULÜBÜ','history':'TARİH','geography':'COĞRAFYA','movie':'FİLM & DİZİ','music':'MÜZİK'}
COLOR={'footballer':('#197965','#17384d'),'footballclub':('#3b7755','#28244b'),'basketballer':('#b45429','#3e2239'),'basketballclub':('#915a27','#332645'),'volleyballer':('#287fb0','#24315b'),'volleyballclub':('#3b8d9a','#203445'),'history':('#98733d','#392f53'),'geography':('#2c8b89','#203c4f'),'movie':('#945c9c','#302342'),'music':('#a0478d','#3e245d')}
IMG=ROOT/'static/trivia-img/generated_v94';IMG.mkdir(parents=True,exist_ok=True)
def split_lines(s,width=36,limit=4):
    words=s.split(); out=[]; line=''
    for w in words:
        if len(line+' '+w)>width and line:
            out.append(line);line=w
        else:line=(line+' '+w).strip()
    if line:out.append(line)
    return out[:limit]
def svg_for(cat,first,source_id,n):
    seed=int(hashlib.sha256((source_id+first).encode()).hexdigest()[:8],16)
    rnd=random.Random(seed); light,dark=COLOR[cat]
    bubbles=''.join(f'<circle cx="{rnd.randint(30,650)}" cy="{rnd.randint(50,440)}" r="{rnd.randint(10,65)}" fill="white" opacity="{rnd.uniform(.025,.09):.3f}"/>' for _ in range(20))
    lines=''.join(f'<text x="52" y="{280+47*i}" fill="#fff" font-size="26" font-weight="650">{html.escape(s)}</text>' for i,s in enumerate(split_lines(first)))
    # SVG from our own simple primitives; no portraits / trademark symbols / unlicensed photos.
    if cat in ('footballer','footballclub'):
        draw='<circle cx="555" cy="116" r="63" fill="none" stroke="#ffffff" stroke-width="5"/><path d="M525 106 L548 83 L579 97 L583 130 L552 149 L522 131 Z" fill="none" stroke="white" stroke-width="5"/><path d="M525 106 L497 85 M579 97 L608 78 M552 149 L558 177" stroke="white" stroke-width="5"/>'
    elif cat in ('basketballer','basketballclub'):
        draw='<circle cx="555" cy="120" r="62" fill="none" stroke="white" stroke-width="6"/><path d="M492 120 H618 M555 58 V182 M510 79 Q581 120 510 164 M600 79 Q529 120 600 164" stroke="white" fill="none" stroke-width="5"/>'
    elif cat in ('volleyballer','volleyballclub'):
        draw='<circle cx="555" cy="120" r="62" fill="none" stroke="white" stroke-width="6"/><path d="M510 78 Q555 115 600 82 M492 112 Q550 107 580 176 M515 168 Q560 123 615 125" stroke="white" fill="none" stroke-width="5"/>'
    elif cat=='history':
        draw='<path d="M516 62 H598 M516 178 H598 M530 67 C530 110 582 110 582 134 C582 153 535 150 535 174 M582 67 C582 102 530 105 530 133 C530 152 582 151 582 174" stroke="white" fill="none" stroke-width="7"/>'
    elif cat=='geography':
        draw='<circle cx="555" cy="120" r="63" fill="none" stroke="white" stroke-width="5"/><ellipse cx="555" cy="120" rx="25" ry="63" fill="none" stroke="white" stroke-width="4"/><path d="M493 120 H617 M506 87 H604 M506 153 H604" stroke="white" stroke-width="4"/>'
    elif cat=='movie':
        draw='<rect x="485" y="92" width="135" height="88" rx="10" fill="none" stroke="white" stroke-width="5"/><path d="M485 92 L620 92 L598 61 L469 61 Z M500 61 L520 92 M545 61 L565 92 M588 61 L608 92" stroke="white" fill="none" stroke-width="5"/>'
    else:
        draw='<path d="M568 64 V153 Q566 179 543 170 Q521 158 535 141 Q548 127 568 138 M568 65 L617 58 V143 Q614 168 590 160 Q573 146 594 132 Q610 127 617 134" fill="none" stroke="white" stroke-width="8" stroke-linejoin="round"/>'
    return f'''<svg xmlns="http://www.w3.org/2000/svg" width="700" height="450" viewBox="0 0 700 450" role="img" aria-label="Özgün çizim ve cevap içermeyen ilk bilgi"><defs><linearGradient id="a" x2="1" y2="1"><stop stop-color="{dark}"/><stop offset="1" stop-color="{light}"/></linearGradient></defs><rect width="700" height="450" rx="32" fill="url(#a)"/>{bubbles}<rect x="29" y="25" width="642" height="400" rx="22" fill="none" stroke="white" stroke-opacity=".35" stroke-width="2"/><text x="52" y="87" fill="#ffffff" opacity=".85" font-size="22" font-weight="800" letter-spacing="2">{LABELS[cat]} · GÖRSEL İPUCU</text>{draw}<text x="52" y="225" fill="#fff4cc" font-size="19" font-weight="800">İLK BİLGİ</text>{lines}<text x="52" y="407" fill="white" opacity=".55" font-size="14">BESTIE? · özgün vektör çizimi · #{n:04d}</text></svg>'''
seen=set(); created=[]; totals={}
for cat,count in TARGET.items():
    original=[q for q in D['trivia'][cat] if not q['id'].startswith('TE-V94-')]
    assert len(original)>=count, (cat,len(original),count)
    # Favour diverse underlying answers, not only multiple variants of the first few names.
    grouped={}
    for q in original:
        grouped.setdefault(q['answer'].casefold(),[]).append(q)
    src=[]
    while len(src)<count:
        progressed=False
        for key in sorted(grouped, key=lambda x:hashlib.sha256(x.encode()).hexdigest()):
            if grouped[key]:
                src.append(grouped[key].pop(0)); progressed=True
                if len(src)>=count:break
        if not progressed:break
    assert len(src)==count
    idx=0
    for q in src:
        idx+=1
        nq=dict(q)
        nq['id']=f'TE-V94-{cat.upper()}-{idx:04d}'
        nq['text']=q['text'].rstrip(' ?')+' — görsel bilgi kartını inceleyerek cevapla.'
        nq['hints']=list(q['hints'])
        # the illustration reproduces the first clue, which is already shown in the UI
        svg=svg_for(cat,nq['hints'][0],q['id'],idx)
        path=IMG/(nq['id'].lower()+'.svg')
        path.write_text(svg,'utf-8')
        nq['image']='/static/trivia-img/generated_v94/'+path.name
        nq['image_alt']='Telifli fotoğraf veya logo içermeyen özgün vektör ipucu kartı: '+nq['hints'][0]
        nq['visual_rights']='original_programmatically_drawn_vector'
        nq['visual_source']='BESTIE? V9.4 kaynak koduyla üretilen özgün SVG illüstrasyonu; üçüncü taraf görseli içermez.'
        nq['editorial_status']='TASLAK - V9.3 verisinden uyarlanmış görsel varyant; bağımsız olgusal teyit, özgünlük ve hukuk incelemesi gerekli'
        nq['source_question_id']=q['id']
        nq['review_required']=True
        assert len(nq['options'])==4 and nq['answer'] in nq['options'] and len(nq['hints'])==3
        assert nq['id'] not in seen
        seen.add(nq['id'])
        D['trivia'][cat].append(nq)
        created.append(nq)
    totals[cat]=idx
assert sum(len(v) for v in D['trivia'].values())==3500
P.write_text(json.dumps(D,ensure_ascii=False,indent=2),'utf-8')
(ROOT/'V9_4_URETIM_RAPORU.json').write_text(json.dumps({'total_cards':3500,'new_illustrated_drafts':len(created),'new_football':totals['footballer']+totals['footballclub'],'new_category_counts':totals,'original_svg_assets':len(list(IMG.glob('*.svg'))),'new_cards_editorial_verified':0,'warning':'New cards are source-derived illustrated editorial drafts, NOT 1,412 individually fact-checked original questions. Rights clearance beyond original SVGs (names, trademark usage, etc.) is not legal certification.'},ensure_ascii=False,indent=2),'utf-8')
print('added',len(created),'by_cat',totals,'total',sum(len(v) for v in D['trivia'].values()))
