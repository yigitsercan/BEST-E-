"""Regression checks for offline / online trivia art URLs, including nested SVGs."""
import json
import re
import subprocess
import unittest
from pathlib import Path
from urllib.parse import unquote, urlsplit

ROOT = Path(__file__).parent
HTML = ROOT / 'static' / 'Bestie_V10_Cevrimdisi.html'

class ImagePathTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.questions = json.loads((ROOT/'data'/'questions.json').read_text('utf-8'))['trivia']
        cls.paths = [q['image'] for questions in cls.questions.values() for q in questions if q.get('image')]

    def test_all_art_files_present(self):
        self.assertEqual(len(self.paths), 1442)
        for url in self.paths:
            self.assertTrue(url.startswith('/static/trivia-img/'), url)
            self.assertTrue((ROOT / url.removeprefix('/')).is_file(), url)

    def test_offline_path_mapping(self):
        text = HTML.read_text('utf8')
        match = re.search(r'function imageSrc\(url\)\{[\s\S]*?\n\}', text)
        self.assertIsNotNone(match)
        fn = match.group()
        payload = json.dumps(self.paths, ensure_ascii=False)
        # Browser URL resolution is mocked in Node; every path is checked both
        # for http /offline and local file:// offline mode.
        program = f"""
        const urls={payload};
        const fn=({fn.replace('function imageSrc','function imageSrc')});
        const results=[];
        for(const proto of ['http:','file:']){{
            global.location={{protocol:proto,pathname:proto==='http:'?'/offline':'/tmp/Bestie_V10_Cevrimdisi.html'}};
            for(const url of urls)results.push([proto,url,fn(url)]);
        }}
        console.log(JSON.stringify(results));
        """
        res=subprocess.run(['node','-e',program],capture_output=True,text=True,check=True)
        results=json.loads(res.stdout)
        self.assertEqual(len(results), len(self.paths)*2)
        for proto, raw, mapped in results:
            self.assertTrue(mapped)
            if proto == 'http:':
                self.assertEqual(mapped, raw)
            else:
                self.assertEqual(mapped, raw.removeprefix('/static/'))
            self.assertTrue((ROOT/'static'/unquote(urlsplit(mapped).path).lstrip('/').removeprefix('static/')).is_file(), mapped)

if __name__ == '__main__': unittest.main()
