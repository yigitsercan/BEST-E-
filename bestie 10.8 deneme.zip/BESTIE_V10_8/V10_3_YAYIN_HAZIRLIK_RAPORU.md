# BESTIE? V10.3 — Dağıtımı engelleyen kod hataları için düzeltmeler

## Düzeltilen ve yerel ortamda doğrulanan noktalar

1. **Kritik Render disk çakışması giderildi.** Önceki Dockerfile soru bankasını `/app/data/questions.json` yolunda paketliyordu. Render'ın `/app/data` kalıcı disk bağlaması imajın bu dizindeki dosyalarını gizler. Yeni Docker imajında sabit soru bankası `/app/content/questions.json` yolunda, kullanıcı profilleri/odaları SQLite veritabanı ise `/app/data/bestie.sqlite3` yolunda bulunur.
2. **Yol ayrımı çevre değişkenleriyle desteklendi.** `BESTIE_QUESTIONS_PATH` istenirse özelleştirilebilir; yerel kaynak klasörü önceki gibi çalışır.
3. **/health gerçek veri kaynağını kontrol ediyor.** SQLite sorgusu veya soru bankası bulunamazsa HTTP 503 döner; sağlıklıysa 200.
4. **Gömülü JavaScript ayrı dosyalara taşındı.** Oyun ve moderasyon arayüzü `/static/bestie.js` ve `/static/moderasyon.js` kullanıyor. CSP `script-src 'self'` oldu ve `unsafe-inline` script izni kaldırıldı. (Satır içi stiller uyumluluk için korunuyor.)
5. **Render dağıtım şablonu** tek sunucu (1 instance), kalıcı disk, 20 oda/saat ve doğru soru bankası yoluna göre güncellendi.

## Çalıştırılmış testler

- `python test_v103_deploy.py`: temiz boş disk senaryosuyla sunucu modülünün açılması ve 3.500 sorunun yeni yoldan yüklenmesi BAŞARILI.
- `python test_rules.py`, `test_hint_budget.py`, `test_content_quality.py`, `test_v95_hardening.py`, `test_v97_privacy_reports.py`, `test_v98_blocking.py`, `test_v99_features.py`, `test_v100_recovery_privacy.py`, `test_v101_recovery.py`, `test_v102_release.py`: BAŞARILI.
- `node test_offline_v10.js`, `node --check static/bestie.js`, `node --check static/moderasyon.js`: BAŞARILI.
- Gerçek `uvicorn` süreç/HTTP `/health` ve `/static/bestie.js` kontrolleri: BAŞARILI.
- Sunucu başlatılmış hâlde `python test_realtime.py`: gerçek WebSocket oda/yeniden bağlanma/eşleşme: BAŞARILI.

## Canlı yayına dair dürüst sınır

Bu pakette kod düzeyindeki tespit edilmiş **kalıcı disk nedeniyle soru bankasının kaybolması** sorunu çözülmüştür; yerel yayın testleri geçmiştir. **Gerçek barındırma hesabına deploy yapılmadı** ve Docker engine bu ortamda olmadığı için imaj üretim derlemesi burada çalıştırılamadı. Gerçek mobil cihaz tarayıcı testi de burada yapılamadı (Chromium yürütülebilir dosyası yok). Uygulama mağazası yayını, sözleşmeler/KVKK, resim lisansı ve 3.500 soru için editoryal kaynak denetimi kod testiyle garanti edilemez.

**Kurulum:** GitHub'a bu klasörün içeriğini koyun; Render'da `render.yaml` Blueprint ile tek sunuculu servisi inceleyerek oluşturun. Ücretli kalıcı disk onayını hesap sahibi verir. `BESTIE_ADMIN_TOKEN` için güçlü benzersiz anahtar tanımlayın. İlk kurulumda `/health` 200 ve `/static/bestie.js` 200 olmalı; mobil davet/eşleşme akışını ayrıca kontrol edin.
