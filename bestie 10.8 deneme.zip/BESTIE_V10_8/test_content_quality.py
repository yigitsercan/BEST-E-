"""V9.2 structural QA and randomized deck-selection regression tests."""
import json, os, tempfile
from pathlib import Path
from quality_guard import scan
with tempfile.TemporaryDirectory() as tmp:
    os.environ['BESTIE_DB_PATH']=str(Path(tmp)/'test.sqlite3')
    import server
    result=scan(server.QUESTIONS)
    assert not result['issues'],result['issues']
    for category in [*server.QUESTIONS['trivia'],'MIXED']:
        seen=set()
        for _ in range(150):
            deck=server.choose_deck('trivia',category)
            assert len(deck)==10
            assert len({q['entity'].casefold() for q in deck})==10
            assert len({q['id'] for q in deck})==10
            n=sum(bool(q.get('image')) for q in deck)
            assert n<=3
            assert all(len(q['options'])==4 and q['answer'] in q['options'] and len(q['hints'])==3 for q in deck)
            seen.update(q['id'] for q in deck)
        print('PASS',category, '150 matches, unique answers per match, <=3 images; card variants seen:',len(seen))
    assert result['totals']['cards']>=1960
    assert sum(q['id'].startswith('TE-NEW-') for deck in server.QUESTIONS['trivia'].values() for q in deck)==128
    print('PASS structural scan (without claiming factual verification):',result['totals'])
