> **V10.8 – Tekli Oyna siyah ekran düzeltmesi:** `V10_8_TEKLI_SIYAH_EKRAN_DUZELTMESI.md` dosyasına bakın.

> GÜNCEL TEST SÜRÜMÜ: **BESTIE? V10.7**. Görsel yükleme ve bağlantı güvenilirliği için son değişiklikler `V10_7_TEST_RAPORU.md` dosyasındadır.

# BESTIE? V10.5 — Test sürümü

Bu paket FastAPI/WebSocket tabanlı BESTIE? uygulamasının **test sürümüdür**. Üç oyun modu, 3.500 taslak Tahmin Et! kartı, çevrimdışı oyun, moderasyon ve tek sunucuda kalıcı oda anlık görüntüleri içerir. İçeriğin bağımsız kaynak doğrulaması tamamlanmamıştır; ticari/halkla açık yayın onayı değildir.

## Bilgisayarda çalıştırma

Python 3.12+ ile proje klasöründe:

```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python -m uvicorn server:app --host 127.0.0.1 --port 8000 --workers 1
```

Tarayıcıda `http://127.0.0.1:8000` adresini aç. Sağlık kontrolü: `http://127.0.0.1:8000/health`. Aynı ağdaki telefonlardan erişim için LAN IP'sine bağlanmak ve güvenlik duvarını uygun şekilde ayarlamak gerekir; LAN üzerinden HTTP, internete açık yayına uygun değildir.

## Testleri çalıştırma

```bash
pip install -r requirements-dev.txt
python run_tests.py
```

İstersen `python test_realtime.py` komutunu **sunucuyu ayrıca başlattıktan sonra** çalıştır. Ortam değişkeni ile test hedef portunu ayarlamak için ilgili testin başındaki parametreleri kontrol et.

## Canlı ortam (kurulum değil, şablon)

Render `render.yaml` tek ücretli **starter** instance ve kalıcı diske göre hazırlanmıştır. Sunucu veritabanı diskte (`/app/data`), salt-okunur soru bankası Docker imajında (`/app/content/questions.json`) tutulur. Ücretli hizmet açmadan önce maliyeti kontrol et; bu paket kendi başına canlıya yüklenmez. Yönetici paneli için **sunucu tarafında** `BESTIE_ADMIN_TOKEN` (en az 32 rastgele karakter) tanımla. HTTPS/WSS, kalıcı disk, yedekleme ve güvenilir proxy kontrollerini gerçek ortamda test et.

`python preflight.py` yayın kontrol listesini üretir: tamamlanmamış kaynak/telif, yaş/KVKK ve cihaz testlerini eksik gösterir. `PREFLIGHT_REPORT.json` sürüme hazır sertifikası değildir.

## Sınırlar

- **Tek sunucu/tek worker**: odalar ve kuyruklar RAM içinde senkronize edilir ve SQLite'a anlık görüntü kaydedilir; çoklu instance desteklenmez.
- Hesaplar anonim oturum sırrı ve bir kez kullanılan kurtarma koduyla çalışır; doğrulanmış e-posta/Passkey mevcut değildir.
- İçerik: 3.500 kartın çoğu varyanttır; kaynak, görsel hakları ve yaşa uygunluk açısından editoryal onay beklemektedir.
- Çevrimdışı KP çevrimiçi hesaba senkronize değildir.
- Mobil web uygulaması ana ekrana eklenebilir; gerçek iOS/Android cihaz testi ve mağaza yayını yapılmamıştır.
- 20 yeni oda/60 dakika/oyuncu ve 500 eş zamanlı aktif oda yapılandırma sınırları mevcut; bu sınırlar yüksek yük altında performans garantisi değildir.

Teknik değişiklikler ve test özeti: `V10_5_TESTE_HAZIRLIK.md`.
