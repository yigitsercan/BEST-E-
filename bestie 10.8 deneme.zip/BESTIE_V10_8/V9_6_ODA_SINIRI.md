# BESTIE? V9.6 — Saatlik oda açma sınırı

- Varsayılan limit: oyuncu başına kayan son 60 dakikada **20** oda.
- 21. oda açma denemesi reddedilir.
- Aktif toplam oda sınırı: 500 (değişmedi).
- Ortam değişkeni `BESTIE_MAX_NEW_ROOMS_PER_HOUR` ile farklı değer ayarlanmışsa ortam değişkeni önceliklidir; dağıtım ortamında 10 değeri varsa 20 yapılmalıdır.
- Sınır sunucu belleğinde tutulduğu için çoklu worker ortamında paylaşımlı değildir.
