# BESTIE? V10.6 — Soru Resimlerinin Görünmemesi Düzeltmesi

## Kök neden
Çevrimdışı `Bestie_V10_Cevrimdisi.html` içindeki `imageSrc` fonksiyonu `q.image` adresinden yalnızca dosya adını alıyordu. V9.4'te üretilen 1.412 SVG, `trivia-img/generated_v94/` alt klasöründe durduğu için yanlış `/static/trivia-img/` veya `trivia-img/` yoluna yönleniyordu.

## Düzeltilenler
- Dosya adının yanında güvenli, iç içe klasör yolu artık korunuyor.
- `/offline` sunucu sayfası ile bilgisayarda dosyadan açılan çevrimdışı sayfa doğru yola yönleniyor.
- `build_offline_v10.py` üretici kodu da düzeltildi; yeni dosya üretildiğinde hata geri gelmeyecek.
- `test_image_paths.py` eklendi ve 1.442 görselin hem dosya varlığı hem de iki farklı tarayıcı yolu kontrol edildi.
- Sunucu gerçek HTTP testinde `/offline`, örnek `.webp` ve `generated_v94` içindeki `.svg` için 200 döndürdü.

## Beklenen görünürlük
Tahmin Et! modunda daha önce belirlenen oyun tasarımına göre 10 soruluk maçta yalnızca 2–3 soru görsellidir. Görsel olmayan sorular kasıtlıdır. Tekli/çevrimdışı oyun ve online oda ikisinde de bu kural korunur.

## Yerel testler
- `python test_image_paths.py` — başarılı
- `python test_content_quality.py` — başarılı
- `python test_hint_budget.py` — başarılı
- `python test_rules.py` — başarılı
- `python test_v103_deploy.py` — başarılı
- `python test_v105_package.py` — başarılı
- FastAPI TestClient ile üç HTTP medya rotası — HTTP 200

## Not
Bu sürüm, soru görsellerinin dosya yolu hatasını giderir. Soruların bağımsız olgusal kaynak doğrulamasının tamamlandığı anlamına gelmez.
