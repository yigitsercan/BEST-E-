
'use strict';
const $=(s)=>document.querySelector(s);
const escapeHtml=(s)=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
const avatars=['😎','🥹','💀','🔥','😈','👑','🫠','🤡','👽','🐸','🦆','🐱','🗿','💅','🤠','🧃','✨','🦄','🤖','😭','🦋'];
const categories={kim_daha:[['KIM_DAHA','👀 Klasik Kim Daha?'],['FLORT_RADAR','💘 Flört Radar'],['SOSYAL_MEDYA_DM','📱 Sosyal Medya & DM'],['ARKADASLIK_SADAKAT','💜 Arkadaşlık & Sadakat'],['RED_GREEN_FLAG','🚩 Red / Green Flag'],['ILK_IZLENIM_ITIRAFLAR','🤫 İlk İzlenim'],['GRUP_ICI_EGLENCE','😂 Grup İçi Eğlence'],['OKUL_UNIVERSITE','🎓 Okul & Üniversite'],['GECE_HAYATI','🪩 Gece Hayatı'],['GELECEK_HAYALLER','✨ Gelecek & Hayaller'],['MIXED','🎲 Karışık Sorular']],trivia:[['footballer','⚽ Futbolcu'],['footballclub','🏟️ Futbol Takımı'],['basketballer','🏀 Basketbolcu'],['basketballclub','🏆 Basketbol Takımı'],['volleyballer','🏐 Voleybolcu'],['volleyballclub','🥇 Voleybol Takımı'],['history','🏛️ Tarih'],['geography','🌍 Coğrafya'],['movie','🎬 Film & Dizi'],['music','🎵 Müzik & Sanatçı'],['MIXED','🎲 Karışık Meydan Okuma']],truth_dare:[['truth_dare','😈 Doğruluk mu Cesaret mi?']]};
const gameNames={kim_daha:'👀 Kim Daha?',trivia:'🏆 Tahmin Et!',truth_dare:'😈 Doğruluk mu Cesaret mi?'};
const S={screen:'splash',socket:null,connected:false,profile:null,room:null,resumeRoomCode:null,waitMatch:false,mode:'kim_daha',category:'KIM_DAHA',bottle:'digital',cap:4,selected:'',code:new URLSearchParams(location.search).get('join')||'',name:localStorage.getItem('bestie_nick')||'Bestie',avatar:localStorage.getItem('bestie_avatar')||'😎',offset:0,adult_mode:false};
let reconnectHandle=null,errTimeout=null,lastHeartbeat=0;
function toast(t){const el=$('#toast');el.textContent=t;el.classList.remove('hidden');clearTimeout(errTimeout);errTimeout=setTimeout(()=>el.classList.add('hidden'),4000)}
function send(action,data={}){if(!S.connected){toast('Sunucuya bağlanılıyor.');return}S.socket.send(JSON.stringify({action,data}))}
function connect(){
  if(S.socket&&[0,1].includes(S.socket.readyState))return;
  const protocol=location.protocol==='https:'?'wss:':'ws:';
  const ws=new WebSocket(`${protocol}//${location.host}/ws`);
  S.socket=ws;
  ws.onopen=()=>{S.connected=true;send('init',{secret:localStorage.getItem('bestie_profile_secret'),nickname:S.name,avatar:S.avatar});render()};
  ws.onclose=()=>{S.connected=false;S.waitMatch=false;S.resumeRoomCode=S.room?.code||null;render();clearTimeout(reconnectHandle);reconnectHandle=setTimeout(connect,1800)};
  ws.onmessage=(ev)=>{
   let msg;try{msg=JSON.parse(ev.data)}catch{return}
   if(msg.type==='profile'){
     S.profile=msg.data;localStorage.setItem('bestie_profile_secret',msg.data.secret);
     if(S.resumeRoomCode){const c=S.resumeRoomCode;S.resumeRoomCode=null;send('join',{code:c})}else if(S.screen==='splash'){}else render();
   }else if(msg.type==='room'){
     const oldRoom=S.room;
     S.room=msg.data;S.screen='room';S.waitMatch=false;
     if(!oldRoom||oldRoom.code!==msg.data.code||oldRoom.round!==msg.data.round||oldRoom.phase!==msg.data.phase)S.selected='';
     S.offset=Date.now()/1000-msg.data.server_now;
     if(history.replaceState)history.replaceState({},'',location.pathname+'?join='+encodeURIComponent(msg.data.code));
     render();
   }else if(msg.type==='matching'){S.waitMatch=msg.data.waiting;render()}
   else if(msg.type==='blocked_list'){
     const list=msg.data||[];if(!list.length){toast('Engellediğin oyuncu yok.');return}
     const entry=window.prompt('Engeli kaldırmak için oyuncu numarasını seç, vazgeçmek için İptal:\n'+list.map((p,i)=>`${i+1}. ${p.nickname}`).join('\n'));
     if(entry===null)return;const idx=Number(entry)-1;
     if(!Number.isInteger(idx)||idx<0||idx>=list.length){toast('Geçersiz numara.');return}
     if(window.confirm(`${list[idx].nickname} adlı oyuncunun engelini kaldırmak istiyor musun?`))send('unblock_player',{target:list[idx].id});
   }else if(msg.type==='recovery_code'){
     const code=msg.data?.code; if(code){const blob=new Blob([`BESTIE? hesap kurtarma kodu\n${code}\nTek kullanımlık. Kimseyle paylaşma.\n`],{type:'text/plain'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='bestie-kurtarma-kodu.txt';a.click();setTimeout(()=>URL.revokeObjectURL(url),5000);window.alert('Kurtarma kodun dosya olarak indirildi. Güvenli sakla; bu kod hesabına erişim sağlar.');}
   }else if(msg.type==='recovery_success'){toast(msg.message);S.screen='profile';render();
   }else if(msg.type==='profile_export'){const blob=new Blob([JSON.stringify(msg.data,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='bestie-verilerim.json';document.body.append(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),5000);toast('Verilerin indirildi. Dosyayı güvenli sakla.');
   }else if(msg.type==='daily'){S.daily=msg.data;S.dailySelected='';S.screen='daily';render()
   }else if(msg.type==='daily_answered'){S.dailyFeedback=msg.data;S.dailySelected='';render()
   }else if(msg.type==='leaderboard'){S.leaderboard=msg.data;S.screen='leaderboard';render()
   }else if(msg.type==='leaderboard_saved'){toast(msg.message);send('leaderboard')
   }else if(msg.type==='report_received'||msg.type==='block_received'||msg.type==='block_removed'){toast(msg.message||'İşlem tamamlandı.') }
   else if(msg.type==='appeal_received'){toast(msg.message)}
   else if(msg.type==='profile_deleted'){localStorage.removeItem('bestie_profile_secret');localStorage.removeItem('bestie_nick');localStorage.removeItem('bestie_avatar');S.profile=null;S.name='Bestie';S.avatar='😎';S.screen='home';toast('Hesabın silindi. Yeniden bağlanınca yeni profil oluşturulur.');render();S.socket?.close()}
   else if(msg.type==='left'){S.room=null;S.screen='home';history.replaceState({},'',location.pathname);render()}
   else if(msg.type==='error'){toast(msg.message)}
  };
}
function header(){return `<header class="brand"><div><img src="/static/bestie-logo.webp" alt="Bestie? logo"><span class="brand-name">Bestie?</span></div><button data-action="profile">${escapeHtml(S.profile?.avatar||S.avatar)} LV ${S.profile?level(S.profile.kp):'1'} · ${(S.profile?.kp||0).toLocaleString('tr-TR')} KP</button></header>`}
function level(kp){let l=1;while(250*(l+1)*l<=kp)l++;return l}
function btn(text,act,cls='btn',disabled=false,extra=''){return `<button class="${cls}" data-action="${act}" ${disabled?'disabled':''} ${extra}>${text}</button>`}
function card(title,subtitle,icon,act){return `<button class="choice" data-action="${act}"><span class="emoji">${icon}</span><span><strong>${title}</strong><small>${subtitle}</small></span><span class="right">›</span></button>`}
function back(text='Geri'){return `<button class="btn ghost small" data-action="back">‹ ${text}</button>`}
function headerInfo(title,description){return `<h2>${title}</h2><p>${description}</p>`}
function playerAvatars(){return `<div class="avatars">${avatars.map(a=>`<button class="${S.avatar===a?'sel':''}" data-action="avatar" data-value="${a}">${a}</button>`).join('')}</div>`}
function profileFields(){return `<label class="label">Takma adın</label><input class="field" id="nickname" autocomplete="nickname" maxlength="22" value="${escapeHtml(S.name)}" placeholder="Oyunda görünecek adın"/><div class="gap"></div><label class="label">Avatarını seç</label>${playerAvatars()}`}
function modeChoices(){return `<label class="label">Oyun modu</label><div class="cols3">${Object.keys(gameNames).map(x=>`<button class="choice ${S.mode===x?'chosen':''}" style="display:block;text-align:center;padding:12px 5px;min-height:82px;font-size:12px" data-action="mode" data-value="${x}">${gameNames[x]}</button>`).join('')}</div><label class="label">Kategori</label><select id="category" class="field" data-action="categoryChange">${categories[S.mode].map(([c,t])=>`<option value="${c}" ${S.category===c?'selected':''}>${t}</option>`).join('')}</select>`}
function adultModeChoice(){return S.mode==='truth_dare'?`<div class="gap"></div><button class="choice ${S.adult_mode?'chosen':''}" data-action="adult_toggle" type="button"><span class="emoji">🔞</span><span><strong>Yetişkinlere Özel (18+): ${S.adult_mode?'Açık':'Kapalı'}</strong><small>Gönüllü, imalı sohbet kartları. Yalnızca 18 yaşını dolduranlar seçmelidir.</small></span></button>`:''}
function chooseBottle(){return S.mode==='truth_dare'?`<div class="gap"></div><label class="label">Şişe seçimi</label><div class="cols3">${[['digital','🍾 Dijital'],['physical','🥤 Gerçek'],['none','🚫 Şişesiz']].map(([x,t])=>`<button class="choice ${S.bottle===x?'chosen':''}" style="padding:13px 6px;display:block;text-align:center;font-size:12px" data-action="bottle" data-value="${x}">${t}</button>`).join('')}</div>`:''}
function main(){
 if(S.screen==='splash')return `<div class="splash"><img src="/static/bestie-logo.webp" alt="Bestie? logo"/><h1>BESTİEEEEEE?</h1><div class="loader"><i></i></div><p style="letter-spacing:2px;margin-top:10px;font-size:12px">OYUN YÜKLENİYOR</p></div>`;
 if(S.screen==='home')return `${header()}<main><div class="hero"><img src="/static/bestie-logo.webp" alt="Bestie? logo"><h1>BESTIE?</h1><p>Kankalarını topla, modu seç, eğlence başlasın!</p></div><div class="status ${S.connected?'good':'warn'}"><span class="live-dot ${S.connected?'':'bad'}"></span>${S.connected?'Sunucuya canlı bağlısın · Gerçek zamanlı oyun':'Sunucuya bağlanılıyor...'}</div><div class="gap"></div>${card('ARKADAŞLARLA OYNA','Özel oda, davet kodu ve aynı anda oynama','💜','friends')}${card('TEKLİ OYNA','Güncel 3.500 kartlı tek cihaz oyunu','🎮','offline')}${card('ONLINE','Arkadaşların veya rastgele eşleşme','🌐','online')}${card('HAFTALIK SIRALAMA','İsteğe bağlı arkadaş rekabeti','🏆','leaderboard')}${card('GÜNLÜK MEYDAN OKUMA','Her gün 5 soru · tek deneme','🔥','daily')}${card('ÇEVRİMDIŞI','Güncel soru bankası; çevrimiçi KP eşitlenmez','📴','offline')}<div class="footer">Beta sürüm · Veriler barındırma koşullarına bağlıdır · Soruların bilgi doğrulaması sürüyor</div></main>`;
 if(S.screen==='daily'){
 const d=S.daily||{day:'',index:0,total:5,score:0,question:null};const q=d.question;
 return `${header()}<main>${back()}<h2>🔥 Günlük meydan okuma</h2><p>${escapeHtml(d.day)} · ${d.index}/${d.total} cevaplandı · ${d.score} puan</p><div class="panel">${S.dailyFeedback?`<div class="status">${S.dailyFeedback.correct?'✅ Doğru!':'❌ Yanlış.'} Doğru cevap: ${escapeHtml(S.dailyFeedback.answer)}</div>${btn('SONRAKİ SORU','daily_next','btn')}`:q?`<h3>${escapeHtml(q.text)}</h3>${q.image?`<img style="width:100%;max-height:220px;object-fit:contain" src="${escapeHtml(q.image)}" alt="Görsel ipucu">`:''}<p>💡 ${escapeHtml(q.hints?.[0]||'')}</p>${q.options.map((v,i)=>`<button class="answer ${S.dailySelected===v?'sel':''}" data-action="daily_pick" data-value="${escapeHtml(v)}">${'ABCD'[i]}. ${escapeHtml(v)}</button>`).join('')}${btn('CEVAPLA','daily_answer','btn',!S.dailySelected)}`:'🎉 Bugünün meydan okuması tamamlandı. Yarın yeni sorular seni bekliyor.'}</div></main>`;
 }
 if(S.screen==='leaderboard'){
 const d=S.leaderboard||{players:[],enabled:false,week_start:'-'};
 return `${header()}<main>${back()}<h2>🏆 Haftalık sıralama</h2><p>Başlangıç: ${escapeHtml(d.week_start)} · Yalnızca katılmayı seçen oyuncular görünür. V9.9 sonrası maç KP'leri sayılır.</p><div class="panel">${d.players.length?d.players.map((p,i)=>`<div class="leader"><span>${i+1}. ${escapeHtml(p.avatar)} ${escapeHtml(p.nickname)}</span><b>${p.points} KP</b></div>`).join(''):'Henüz sıralamada oyuncu yok.'}</div>${btn(d.enabled?'SIRALAMADAN ÇIK':'SIRALAMAYA KATIL', 'toggle_leaderboard', 'btn secondary')}</main>`;
 }
 if(S.screen==='online')return `${header()}<main>${back()}<div class="hero"><h1>🌐 ONLINE</h1><p>Gerçek oyuncularla aynı anda oyna!</p></div>${card('ARKADAŞLARIMLA OYNA','Kod oluştur, link paylaş veya odaya gir','💗','friends')}${card('RASTGELE EŞLEŞ','Çevrimiçi bir oyuncuyla 1v1 eşleş','⚡','match_config')}<div class="status">🛡️ Güvenlik: Tanımadığın kişilerle özel bilgi paylaşma. Rahatsız edici içerikte oyundan çıkabilirsin. 18+ seçenekleri yalnızca yetişkinlere yöneliktir.</div><div class="status">Rastgele eşleşmede bot yok. Eşleşmek için aynı kategoride başka bir oyuncunun da aramada olması gerekir.</div></main>`;
 if(S.screen==='friends')return `${header()}<main>${back()}<div class="hero"><h1>💜 ARKADAŞLARLA OYNA</h1><p>Herkes kendi telefonundan katılabilir.</p></div>${card('ODA OLUŞTUR','Oyunu ve kişi sayısını belirle','✨','create_config')}${card('ODAYA KATIL','Arkadaşının verdiği kodu gir','🔑','join_config')}</main>`;
 if(S.screen==='create_config')return `${header()}<main>${back()}${headerInfo('✨ Yeni bir oda kur','Kapasiteyi 2–12 kişi arasında + / − ile ayarla.')}<div class="panel">${profileFields()}<div class="divider"></div>${modeChoices()}${chooseBottle()}${adultModeChoice()}<div class="divider"></div><label class="label">Oda kapasitesi</label><div class="number"><button aria-label="Kişi azalt" data-action="capminus" ${S.cap<=2?'disabled':''}>−</button><strong>${S.cap}</strong><button aria-label="Kişi artır" data-action="capplus" ${S.cap>=12?'disabled':''}>+</button></div></div>${btn('ODA OLUŞTUR ✨','create_room','btn',!S.connected)}</main>`;
 if(S.screen==='join_config')return `${header()}<main>${back()}${headerInfo('🔑 Odaya katıl','Arkadaşının paylaştığı 6 karakterlik kodu yaz.')}<div class="panel">${profileFields()}<div class="divider"></div><label class="label">Oda kodu</label><input class="field" id="room-code" maxlength="6" autocapitalize="characters" style="letter-spacing:3px;text-transform:uppercase" placeholder="ÖRN: H7K4M2" value="${escapeHtml(S.code)}" /></div>${btn('ODAYA KATIL →','join_room','btn',!S.connected)}</main>`;
 if(S.screen==='match_config')return `${header()}<main>${back()}${headerInfo('⚡ Rastgele eşleşme','Aynı kategoride arayan gerçek bir oyuncuyla 1v1 yarış.')}<div class="panel">${profileFields()}<div class="divider"></div>${modeChoices()}${chooseBottle()}</div>${btn('OYUNCU ARA ⚡','match','btn',!S.connected)}</main>`;
 if(S.screen==='match_wait')return `${header()}<main>${back()}<div class="hero" style="padding:55px 0"><div class="spinner">🔎</div><h2 style="margin-top:30px">Oyuncu aranıyor...</h2><p>${escapeHtml(gameNames[S.mode])} · ${escapeHtml(categories[S.mode].find(c=>c[0]===S.category)?.[1]||'')}</p><div class="status">Gerçek kullanıcı bekleniyor. Başka biri aynı modda arama yapınca oyun başlayacak.</div></div>${btn('ARAMAYI İPTAL ET','cancel_match','btn secondary')}</main>`;
 if(S.screen==='profile'){
 const kp=S.profile?.kp||0,l=level(kp),last=250*l*(l-1),next=250*l*(l+1),pct=Math.round((kp-last)/(next-last)*100);
 return `${header()}<main>${back()}${headerInfo('👑 Bestie? profilin','Oyunlardan kazandığın toplam KP burada saklanır.')}<div class="panel" style="text-align:center"><h1 style="font-size:50px;margin:0">${escapeHtml(S.profile?.avatar||'😎')}</h1><h2>${escapeHtml(S.profile?.nickname||S.name)}</h2><div class="badge">LEVEL ${l}</div><h1 style="font-size:36px;color:var(--pink-light);margin:10px 0">${kp.toLocaleString('tr-TR')} KP</h1><div class="progress"><i style="width:${pct}%"></i></div><p class="small spaced">${(next-kp).toLocaleString('tr-TR')} KP sonra Level ${l+1}</p></div><div class="status">Prototip: KP bu sunucunun SQLite dosyasına yazılır. Kalıcı canlı dağıtım için veritabanı bağlanmalıdır.</div><div class="panel"><h3>Gizlilik ve hesap</h3><p>Sunucu üzerinde tutulan takma ad, avatar ve KP hesabını silebilirsin. Silme geri alınamaz.</p>${btn("ENGELLEDİĞİM OYUNCULAR", "list_blocks", "btn secondary")}${btn("VERİLERİMİ İNDİR (JSON)", "export_profile", "btn secondary")}${btn("TEK KULLANIMLIK KURTARMA KODU OLUŞTUR", "create_recovery_code", "btn secondary")}${btn("KURTARMA KODUYLA HESABA GEÇ", "recover_account", "btn outline")}${btn("OYUN KISITLAMASINA İTİRAZ ET","appeal_sanction","btn outline")}${btn("HESABIMI VE KP VERİLERİMİ SİL", "delete_profile", "btn outline")}</div></main>`;
 }
 if(S.screen==='room'&&S.room)return roomScreen();
 return `${header()}<main>${btn('Ana menüye dön','home','btn')}</main>`;
}
function roomScreen(){const r=S.room,my=r.players.find(p=>p.id===r.my_id),host=r.host===r.my_id,cat=escapeHtml(r.category_label),myName=escapeHtml(my?.nickname||S.name);
 const badge=`<div class="flex space"><span class="badge">${escapeHtml(gameNames[r.mode])} · ${cat}</span><span class="badge"><span class="live-dot ${S.connected?'':'bad'}"></span>${r.players.filter(p=>p.online).length} online</span></div>`;
 if(r.phase==='lobby'){
  return `${header()}<main>${badge}<div class="hero"><h2>💗 ARKADAŞ ODASI</h2><div class="code">${escapeHtml(r.code)}</div><p>${r.players.length}/${r.max_players} oyuncu · ${escapeHtml(r.category_label)}</p></div><div class="cols2">${btn('🔗 DAVETİ KOPYALA','copy_invite','btn secondary')}${btn('📲 PAYLAŞ','share_invite','btn outline')}</div><div class="gap"></div><div class="panel"><div class="flex space"><h3>Oyuncular</h3><span class="countPill">${r.players.filter(p=>p.ready).length}/${r.players.length} hazır</span></div><div class="players">${r.players.map(p=>`<div class="player ${p.ready?'ready':''} ${!p.online?'offline':''}"><div class="av">${escapeHtml(p.avatar)}</div><strong>${escapeHtml(p.nickname)}</strong><span>${p.id===r.host?'👑 Kurucu':`Lv ${p.level}`} · ${p.ready?'✅ Hazır':'⏳ Bekliyor'}</span></div>`).join('')}</div></div><div class="panel"><h3>${myName}, oyuna hazır mısın?</h3>${r.adult_mode?'<div class="status warn">🔞 18+ oda: Yetişkin olduğunu beyan ederek ve gönüllü olarak katılabilirsin. Pas geçmek serbesttir.</div>':''}${btn(my?.ready?'HAZIRLIĞI KALDIR':'BEN HAZIRIM ✅','toggle_ready',my?.ready?'btn secondary':'btn')}${host?`<div class="gap"></div>${btn('HERKES HAZIR → OYUNU BAŞLAT','start','btn',!(r.players.length>=2&&r.players.every(p=>p.ready&&p.online)))}`:''}<div class="gap"></div>${btn('OYUNCU BİLDİR','report_player','btn outline')}${btn('OYUNCU ENGELLE','block_player','btn outline')}<div class="gap"></div>${btn('ODADAN AYRIL','leave','btn ghost')}</div><div class="status">Oda kodunu arkadaşlarına gönder. Herkes hazır olunca kurucu başlatır; oylar farklı telefonlarda anlık senkronize olur.</div></main>`;
 }
 if(r.phase==='question'){
  const q=r.question||{},timeLeft=Math.max(0,Math.ceil((r.ends_at-(Date.now()/1000-S.offset)))) , progress=Math.max(0,Math.round(r.round/r.round_total*100));
  let choices='';
  if(r.mode==='kim_daha'){
    choices=r.players.map(p=>`<button class="answer ${(S.selected||r.my_answer)===p.id?'sel':''}" data-action="pick" data-value="${escapeHtml(p.id)}">${escapeHtml(p.avatar)} ${escapeHtml(p.nickname)}${p.id===r.my_id?' (Ben)':''}</button>`).join('')+
    btn(r.my_answer?'OYUMU DEĞİŞTİR':'OYUMU GÖNDER','answer','btn',!(S.selected||r.my_answer));
  }else if(r.mode==='trivia'){
    choices=`<div class="panel"><div class="small" style="color:#f9d2f0">${(q.hints||[]).map((h,i)=>`<div class="quiz-hint">💡 ${i+1}. ipucu: ${escapeHtml(h)}</div>`).join('')}</div><div class="status">💡 Kalan ipucu hakkın: <strong>${r.hint_remaining} / ${r.hint_total}</strong> · 10 soruluk oyun boyunca geçerlidir.</div>${btn((q.hints||[]).length>=3?'BU SORUNUN İPUÇLARI TAMAMLANDI':r.hint_remaining<=0?'İPUCU HAKKIN KALMADI':'💡 İPUCU AL · Yeni bilgi göster','hint','btn secondary',(q.hints||[]).length>=3||r.hint_remaining<=0||!!r.my_answer)}</div><div class="cols2">${(q.options||[]).map((a,i)=>`<button class="answer ${S.selected===a?'sel':''}" data-action="pick" data-value="${escapeHtml(a)}" ${r.my_answer?'disabled':''}><strong>${'ABCD'[i]}.</strong> ${escapeHtml(a)}</button>`).join('')}</div>${btn(r.my_answer?'CEVABIN GÖNDERİLDİ ✓':'CEVABIMI GÖNDER','answer','btn',!S.selected||!!r.my_answer)}`;
  }else{
    const target=r.players.find(p=>p.id===q.target);
    choices=`<div class="panel" style="text-align:center"><div style="font-size:29px">${target?escapeHtml(target.avatar):'🥤'}</div><h3>${target?'Sıra '+escapeHtml(target.nickname)+' adlı oyuncuda':'Gerçek şişeyi çevirip sıradaki kişiyi seçin'}</h3><span class="badge">${q.card_type==='truth'?'💜 DOĞRULUK':'😈 CESARET'}</span></div>`;
    if(r.bottle==='physical'&&host){choices+=`<label class="label">Fizikî şişenin gösterdiği kişiyi seç</label>${r.players.map(p=>`<button class="answer" data-action="target" data-value="${escapeHtml(p.id)}">${escapeHtml(p.avatar)} ${escapeHtml(p.nickname)}</button>`).join('')}`}
    if(host||r.my_id===q.target)choices+=btn('TURU TAMAMLA / PAS GEÇ','complete_round','btn');
    choices+=`<div class="status">Pas geçmek serbesttir. Fizikî şişe modunda seçimi kurucu işaretler.</div>`;
  }
  return `${header()}<main>${badge}<div class="gap"></div><div class="flex space"><span class="small">SORU ${r.round} / ${r.round_total}</span><span class="timer" id="countdown">⏱ ${timeLeft} sn</span></div><div class="progress"><i style="width:${progress}%"></i></div><div class="gap"></div><div class="card"><div class="eyebrow">${r.mode==='kim_daha'?'SENCE KİM?':r.mode==='trivia'?'TAHMİN ET!':'SENİN SIRAN'}</div><h2>${escapeHtml(q.text||'Soru hazırlanıyor...')}</h2>${q.image?`<img class="quiz-art" src="${escapeHtml(q.image)}" alt="${escapeHtml(q.image_alt||'Özgün soru illüstrasyonu')}" loading="eager"/>`:''}</div><div class="gap"></div>${choices}<div class="status spaced">${r.mode==='trivia'?`Yanıt verirsen kazanabileceğin puan: <strong>${escapeHtml(q.available_points||40)}</strong>. Dört şık her zaman görünür; ipucu alırsan yeni bilgi eklenir. `:''}${r.answered_count}/${r.players.length} kişi yanıtladı · Sonuçlar tur bitince açıklanır.</div></main>`;
 }
 if(r.phase==='result'){
  const results=r.results||{};
  let out='';
  if(r.mode==='kim_daha'){
    const items=r.players.map(p=>({p,n:results.votes?.[p.id]||0})).sort((a,b)=>b.n-a.n);
    out=items.map(x=>`<div class="leader"><span>${escapeHtml(x.p.avatar)} ${escapeHtml(x.p.nickname)}</span><strong>${x.n} oy</strong></div>`).join('');
  }else if(r.mode==='trivia'){
    out=`<div class="card"><div class="eyebrow">DOĞRU CEVAP</div><h2>✅ ${escapeHtml(results.correct_answer||'')}</h2></div><div class="gap"></div>`+
      r.players.slice().sort((a,b)=>b.score-a.score).map(p=>`<div class="leader"><span>${escapeHtml(p.avatar)} ${escapeHtml(p.nickname)}</span><strong>${p.score} puan</strong></div>`).join('');
  }else out=`<div class="status">Tur tamamlandı! Sonraki karta geçiliyor.</div>`;
  return `${header()}<main>${badge}<div class="hero"><h1>🎉 TUR SONUCU</h1><p>Tur ${r.round} / ${r.round_total}</p></div>${out}<div class="status spaced">Sonraki tur <b id="resultcount">${Math.max(0,Math.ceil(r.result_until-(Date.now()/1000-S.offset)))}</b> saniye sonra otomatik başlar.</div></main>`;
 }
 if(r.phase==='finished'){
  const ordered=r.players.slice().sort((a,b)=>(r.final_scores[b.id]||0)-(r.final_scores[a.id]||0));
  return `${header()}<main><div class="hero"><h1>🏆 OYUN BİTTİ!</h1><p>Bestie? şampiyonları</p></div><div class="panel">${ordered.map((p,i)=>`<div class="leader"><span>${['🥇','🥈','🥉'][i]||i+1} ${escapeHtml(p.avatar)} ${escapeHtml(p.nickname)}</span><span><b>${r.final_scores[p.id]||0} skor</b><br><small class="muted">+${r.final_kp[p.id]||0} KP</small></span></div>`).join('')}</div><div class="status good">${escapeHtml(myName)} · Bu oyundan +${r.final_kp[r.my_id]||0} KP kazandın!</div><div class="gap"></div>${btn('🖼️ GÖRSEL SONUÇ KARTI','image_result','btn')}${btn('📲 SONUCU PAYLAŞ','share_result','btn secondary')}${btn('📋 SONUCU KOPYALA','copy_result','btn outline')}${btn('OYUNCU BİLDİR','report_player','btn outline')}${btn('OYUNCU ENGELLE','block_player','btn outline')}${btn('YENİ OYUN İÇİN ANA MENÜ','finished_home','btn')}</main>`;
 }
 return `${header()}<main>Oda bekleniyor...</main>`;
}
function resultSummary(){
 const r=S.room;if(!r||r.phase!=='finished')return '';
 const ranked=r.players.slice().sort((a,b)=>(r.final_scores[b.id]||0)-(r.final_scores[a.id]||0));
 const top=ranked.slice(0,3).map((p,i)=>`${i+1}. ${p.nickname} — ${r.final_scores[p.id]||0} puan`).join('\n');
 const me=r.players.find(p=>p.id===r.my_id);
 return `🏆 BESTIE? • ${gameNames[r.mode]}\n${r.category_label}\n${top}\n${me?me.nickname+' bu maçta +'+(r.final_kp[r.my_id]||0)+' KP kazandı.':''}\nSen de arkadaşlarınla oyna: ${location.origin}/`;
}
async function createResultCard(){
 const r=S.room;if(!r||r.phase!=='finished')throw Error('Oyun tamamlanmadı.');
 const canvas=document.createElement('canvas');canvas.width=1080;canvas.height=1350;
 const g=canvas.getContext('2d');if(!g)throw Error('Görsel oluşturulamadı.');
 const bg=g.createLinearGradient(0,0,1080,1350);bg.addColorStop(0,'#250d41');bg.addColorStop(1,'#090619');g.fillStyle=bg;g.fillRect(0,0,1080,1350);
 const glow=g.createRadialGradient(750,90,25,750,90,750);glow.addColorStop(0,'#9d256e66');glow.addColorStop(1,'#12072300');g.fillStyle=glow;g.fillRect(0,0,1080,1000);
 g.textAlign='center';g.fillStyle='#ff99e9';g.font='bold 86px system-ui';g.fillText('BESTIE?',540,155);
 g.fillStyle='#ffffff';g.font='bold 53px system-ui';g.fillText('🏆 MAÇ SONUCU',540,255);
 g.fillStyle='#f6c3f1';g.font='32px system-ui';g.fillText(String(gameNames[r.mode]||'Arkadaş Oyunu').slice(0,28),540,317);
 const ranked=r.players.slice().sort((a,b)=>(r.final_scores[b.id]||0)-(r.final_scores[a.id]||0));
 const count=Math.min(8,ranked.length),height=Math.min(105,Math.floor(765/Math.max(1,count)));
 for(let i=0;i<count;i++){
   const player=ranked[i], y=385+i*height;
   g.fillStyle=i===0?'#792f81':'#39214e';g.beginPath();g.roundRect(95,y,890,height-12,22);g.fill();
   g.textAlign='left';g.fillStyle='#fff';g.font='bold 34px system-ui';
   const name=Array.from(player.nickname||'Oyuncu').slice(0,18).join('');
   g.fillText(`${i+1}. ${name}`,128,y+height/2+9);
   g.textAlign='right';g.fillStyle='#ffdc88';g.font='bold 33px system-ui';
   g.fillText(`${r.final_scores[player.id]||0} puan`,945,y+height/2+9);
 }
 g.textAlign='center';g.fillStyle='#f6c6e8';g.font='bold 35px system-ui';
 g.fillText(`Bu maç: +${r.final_kp[r.my_id]||0} KP`,540,1215);
 g.fillStyle='#cab1df';g.font='30px system-ui';g.fillText('Sen de arkadaşlarınla oyna • BESTIE?',540,1280);
 return new Promise((resolve,reject)=>canvas.toBlob(b=>b?resolve(b):reject(Error('PNG oluşturulamadı.')),'image/png'));
}
function render(){const root=$('#app');root.innerHTML=main();}
function updateCountdown(){const r=S.room;if(!r)return;
 if(r.phase==='question'){const d=$('#countdown');if(d)d.textContent='⏱ '+Math.max(0,Math.ceil(r.ends_at-(Date.now()/1000-S.offset)))+' sn';}
 if(r.phase==='result'){const d=$('#resultcount');if(d)d.textContent=Math.max(0,Math.ceil(r.result_until-(Date.now()/1000-S.offset)));}
}
function readProfileInput(){const inp=$('#nickname');if(inp)S.name=inp.value.trim().slice(0,22)||'Bestie';localStorage.setItem('bestie_nick',S.name);localStorage.setItem('bestie_avatar',S.avatar)}
function commitProfile(){readProfileInput();send('profile_update',{nickname:S.name,avatar:S.avatar})}
function roomParams(){return {mode:S.mode,category:S.category,bottle:S.bottle,max_players:S.cap,adult_mode:S.mode==='truth_dare'&&S.adult_mode}}
function resetAfter(){S.room=null;S.selected='';S.waitMatch=false;S.screen='home';history.replaceState({},'',location.pathname);render()}
function routeBack(){if(S.room){toast('Odadayken lütfen oda menüsünü kullan.');return}if(S.screen==='match_wait'){send('cancel_match');S.waitMatch=false}S.screen=({create_config:'friends',join_config:'friends',friends:'online',match_config:'online',online:'home',profile:'home',leaderboard:'home',daily:'home',match_wait:'online'})[S.screen]||'home';render()}
$('#app').addEventListener('change',e=>{if(e.target.id==='category')S.category=e.target.value});
$('#app').addEventListener('click',async e=>{
 const t=e.target.closest('[data-action]');if(!t||t.disabled)return;
 const a=t.dataset.action,v=t.dataset.value;
 if(a==='adult_toggle'){S.adult_mode=!S.adult_mode;render();return}
 if(['mode','avatar','bottle'].includes(a)){readProfileInput();S[a]=v;if(a==='mode')S.category=categories[S.mode][0][0];render();return}
 if(a==='categoryChange')return;
 if(a==='capminus'){S.cap=Math.max(2,S.cap-1);render();return}
 if(a==='capplus'){S.cap=Math.min(12,S.cap+1);render();return}
 if(a==='back'){routeBack();return}
 if(a==='home'){resetAfter();return}
 if(a==='online'){S.screen='online';render();return}
 if(a==='leaderboard'){send('leaderboard');return}
 if(a==='daily'){S.dailyFeedback=null;send('daily');return}
 if(a==='daily_pick'){S.dailySelected=v;render();return}
 if(a==='daily_answer'){send('daily_answer',{answer:S.dailySelected});return}
 if(a==='daily_next'){S.dailyFeedback=null;send('daily');return}
 if(a==='toggle_leaderboard'){send('leaderboard_optin',{enabled:!S.leaderboard?.enabled});return}
 if(a==='friends'){S.screen='friends';render();return}
 if(a==='offline'){location.href='/offline';return}
 if(a==='create_config'){S.screen='create_config';render();return}
 if(a==='join_config'){S.screen='join_config';render();return}
 if(a==='match_config'){S.screen='match_config';S.mode='trivia';S.category='MIXED';render();return}
 if(a==='profile'){if(S.room){toast('Profilin oda içinde görüntülenebilir.');return}S.screen='profile';render();return}
 if(a==='create_room'){commitProfile();send('create',roomParams());return}
 if(a==='join_room'){commitProfile();S.code=($('#room-code')?.value||'').toUpperCase().replace(/\s/g,'').slice(0,6);if(S.code.length!==6){toast('Lütfen 6 karakterlik oda kodu yaz.');return}send('join',{code:S.code});return}
 if(a==='match'){commitProfile();send('matchmake',roomParams());S.screen='match_wait';render();return}
 if(a==='cancel_match'){send('cancel_match');S.screen='online';render();return}
 if(a==='toggle_ready'){const me=S.room.players.find(p=>p.id===S.room.my_id);send('ready',{ready:!me?.ready,age_confirmed:!me?.ready && S.room.adult_mode?window.confirm('18 yaşını doldurduğunu ve yetişkinlere yönelik sohbet içeriğini gönüllü olarak seçtiğini onaylıyor musun?'):!S.room.adult_mode});return}
 if(a==='start'){send('start');return}
 if(a==='leave'){send('leave');return}
 if(a==='copy_invite'){const url=location.origin+'/?join='+S.room.code;try{await navigator.clipboard.writeText(url);toast('Davet bağlantısı kopyalandı!')}catch{toast(url)}return}
 if(a==='share_invite'){const url=location.origin+'/?join='+S.room.code;try{if(navigator.share)await navigator.share({title:'Bestie? oda daveti',text:'Hadi Bestie? oynayalım! Oda kodum: '+S.room.code,url});else await navigator.clipboard.writeText(url)}catch{}return}
 if(a==='pick'){S.selected=v;render();return}
 if(a==='hint'){send('hint');return}
 if(a==='answer'){if(!S.selected&&!S.room.my_answer)return;send('answer',{answer:S.selected||S.room.my_answer});return}
 if(a==='target'){send('target',{target:v});return}
 if(a==='complete_round'){send('complete_round');return}
 if(a==='image_result'){
   if(!window.confirm('Sonuç görselinde odadaki oyuncuların takma adları ve maç skorları yer alacak. Paylaşmak veya kaydetmek ister misin?'))return;
   try{
     const blob=await createResultCard(),file=new File([blob],'bestie-mac-sonucu.png',{type:'image/png'});
     if(navigator.share&&navigator.canShare?.({files:[file]}))await navigator.share({files:[file],title:'BESTIE? maç sonucu'});
     else {const url=URL.createObjectURL(blob);const link=document.createElement('a');link.href=url;link.download=file.name;document.body.append(link);link.click();link.remove();setTimeout(()=>URL.revokeObjectURL(url),60000);toast('Sonuç kartı PNG olarak kaydedildi.');}
   }catch(e){if(e?.name!=='AbortError')toast('Görsel oluşturulamadı: '+(e?.message||'Hata'));}
   return;
 }
 if(a==='copy_result'){try{await navigator.clipboard.writeText(resultSummary());toast('Sonuç kopyalandı!')}catch{toast('Tarayıcı kopyalamayı engelledi.')}return}
 if(a==='share_result'){
   const text=resultSummary();
   try{if(navigator.share)await navigator.share({title:'BESTIE? Maç Sonucu',text});else{await navigator.clipboard.writeText(text);toast('Sonuç kopyalandı!')}}
   catch(e){if(e?.name!=='AbortError')toast('Paylaşım başarısız. Kopyalama seçeneğini deneyebilirsin.')}
   return;
 }
 if(a==='list_blocks'){send('list_blocks');return}
 if(a==='block_player'){
   const others=(S.room?.players||[]).filter(p=>p.id!==S.room.my_id);
   if(!others.length){toast('Engellenecek oyuncu yok.');return}
   const choice=window.prompt('Engellenecek oyuncunun numarasını gir:\n'+others.map((p,i)=>`${i+1}: ${p.nickname}`).join('\n'));
   if(choice===null)return;
   const idx=Number(choice)-1;
   if(!Number.isInteger(idx)||idx<0||idx>=others.length){toast('Geçersiz seçim.');return}
   if(!window.confirm(`${others[idx].nickname} engellensin mi? Gelecekte aynı oda ve rastgele eşleşmede olmayacaksınız; bu oyun devam eder.`))return;
   send('block_player',{target:others[idx].id});return;
 }
 if(a==='report_player'){
   const others=(S.room?.players||[]).filter(p=>p.id!==S.room.my_id);
   if(!others.length){toast('Bildirilecek oyuncu bulunamadı.');return}
   const labels=others.map((p,i)=>`${i+1}: ${p.nickname}`).join('\n');
   const chosen=window.prompt('Hangi oyuncu? Numara gir:\n'+labels);
   if(chosen===null)return;
   const index=Number(chosen)-1;
   if(!Number.isInteger(index)||index<0||index>=others.length){toast('Oyuncu seçimi geçersiz.');return}
   const codes=['hakaret','taciz','uygunsuz_icerik','hile','diger'];
   const reason=window.prompt('Şikâyet nedeni numarası:\n1. Hakaret\n2. Taciz\n3. Uygunsuz içerik\n4. Hile\n5. Diğer');
   if(reason===null)return;
   const reasonIndex=Number(reason)-1;
   if(!Number.isInteger(reasonIndex)||reasonIndex<0||reasonIndex>=codes.length){toast('Şikâyet nedeni geçersiz.');return}
   send('report_player',{target:others[index].id,reason:codes[reasonIndex]});return;
 }
 if(a==='appeal_sanction'){const reason=window.prompt('Aktif kısıtlaman varsa 15–500 karakter arası itiraz gerekçeni yaz.');if(reason!==null)send('appeal_sanction',{reason});return}
 if(a==='export_profile'){send('export_profile');return}
 if(a==='create_recovery_code'){if(window.confirm('Yeni kod oluşturmak önceki kurtarma kodunu iptal eder. Devam edilsin mi?'))send('create_recovery_code');return}
 if(a==='recover_account'){if(S.room){toast('Önce odadan çıkmalısın.');return}const code=window.prompt('Başka cihazda oluşturduğun tek kullanımlık kurtarma kodunu gir:');if(code)send('recover_account',{code:code.trim()});return}
 if(a==='delete_profile'){
   if(!window.confirm('Hesabın, avatarın ve tüm KP puanların kalıcı olarak silinsin mi?'))return;
   if(!window.confirm('Son onay: Bu işlemin geri dönüşü yok. Silinsin mi?'))return;
   send('delete_profile');return;
 }
 if(a==='finished_home'){send('leave');return}
});
connect();render();
setInterval(updateCountdown,240);
setTimeout(()=>{if(S.screen==='splash'){S.screen=S.code?'join_config':'home';render()}},2100);
